import json, pathlib, subprocess, time, psutil, os, sys
root=pathlib.Path(__file__).resolve().parent
repo=root.parent.parent
mode=sys.argv[1] if len(sys.argv)>1 else 'only'
binary=(root/'probe.exe') if mode in ('sqlite','assembly') else ((root/'model-load.exe') if mode=='load' else repo/'.tmp/startup-capacity-20260916/model.exe')
bundle=repo/'.tmp/work-package-3/release-final/bin/embedding'
env=dict(os.environ,GOMAXPROCS='2')
cmd=[str(binary),str(bundle)]
if mode in ('sqlite','assembly'):cmd.append(str(root/'memory-probe.sqlite'))
if mode=='assembly':cmd.append(str(root/'connector.exe'))
p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,creationflags=subprocess.CREATE_NO_WINDOW)
samples=[];start=time.monotonic()
try:
 while p.poll() is None:
  members=[]
  try:
   proc=psutil.Process(p.pid)
   for child in [proc,*proc.children(recursive=True)]:
    try:
     m=child.memory_info();members.append({'pid':child.pid,'name':child.name(),'rss':m.rss,'peak_rss':getattr(m,'peak_wset',None),'private':getattr(m,'private',None)})
    except psutil.Error:pass
  except psutil.Error:pass
  samples.append({'s':time.monotonic()-start,'rss':sum(x['rss'] for x in members),'processes':members})
  if time.monotonic()-start>60:raise TimeoutError('minimal model probe exceeded 60s')
  time.sleep(.02)
 stdout,stderr=p.communicate()
 scope='Minimal assembly: SQLite three connections, production model adapter, copied production MCP connector with service discovery replaced by isolated endpoint; empty MCP service, no full retrieval or streaming implementation'
 if mode!='assembly':scope='SQLite driver with three connections plus existing model adapter; no MCP connector' if mode=='sqlite' else 'existing model wrapper and its model child only; no connector or SQLite'
 out={'scope':scope,'exit_code':p.returncode,'stdout':stdout.decode(errors='replace'),'stderr':stderr.decode(errors='replace'),'peak':max(samples,key=lambda x:x['rss']) if samples else {},'samples':samples}
 (root/('minimal-assembly.json' if mode=='assembly' else ('sqlite-model.json' if mode=='sqlite' else ('model-load.json' if mode=='load' else 'model-only.json')))).write_text(json.dumps(out,indent=2),encoding='utf-8')
 print(json.dumps({k:v for k,v in out.items() if k!='samples'}))
finally:
 if p.poll() is None:
  for c in psutil.Process(p.pid).children(recursive=True):c.kill()
  p.kill();p.wait()
