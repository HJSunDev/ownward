package main
import("context"; "os")
func main(){if err:=runSharedMCPConnector(context.Background(),os.Args[2],"feasibility","feasibility",os.Stdout,os.Stderr);err!=nil{panic(err)}}
