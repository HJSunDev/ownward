package main

import (
 "bufio"
 "context"
 "io"
 "net"
 "net/http"
 "os/exec"
 "path/filepath"
 "github.com/modelcontextprotocol/go-sdk/mcp"
 "database/sql"
 "encoding/json"
 "fmt"
 "os"
 "strings"
 "time"

 "github.com/HJSunDev/ownward/internal/embedding"
 _ "modernc.org/sqlite"
)

func check(err error) { if err!=nil { panic(err) } }
func event(name string, values map[string]any) { values["stage"]=name; values["at"]=time.Now().Format(time.RFC3339Nano); check(json.NewEncoder(os.Stdout).Encode(values)) }
func main(){
 ctx:=context.Background()
 db,e:=sql.Open("sqlite",os.Args[2]);check(e);defer db.Close();db.SetMaxOpenConns(3)
 var cs []*sql.Conn
 for i:=0;i<3;i++ { c,e:=db.Conn(ctx);check(e);cs=append(cs,c);defer c.Close();cache:=1024;if i==0{cache=2048};for _,s:=range []string{"PRAGMA page_size=16384","PRAGMA auto_vacuum=INCREMENTAL","PRAGMA journal_mode=WAL","PRAGMA synchronous=FULL","PRAGMA mmap_size=0","PRAGMA temp_store=FILE",fmt.Sprintf("PRAGMA cache_size=-%d",cache)} { _,e=c.ExecContext(ctx,s);check(e) } }
 _,e=cs[0].ExecContext(ctx,"CREATE TABLE IF NOT EXISTS samples(id INTEGER PRIMARY KEY, data BLOB)");check(e)
 for i:=0;i<40;i++ { _,e=cs[0].ExecContext(ctx,"INSERT OR REPLACE INTO samples VALUES(?,zeroblob(65536))",i);check(e) }
 event("sqlite_ready",map[string]any{"connections":3})
 if len(os.Args)>3 {
  srv:=mcp.NewServer(&mcp.Implementation{Name:"bounded-probe",Version:"1"},nil)
  handler:=mcp.NewStreamableHTTPHandler(func(*http.Request)*mcp.Server{return srv},&mcp.StreamableHTTPOptions{JSONResponse:true})
  listener,e:=net.Listen("tcp","127.0.0.1:0");check(e)
  server:=&http.Server{Handler:http.HandlerFunc(func(w http.ResponseWriter,r *http.Request){if strings.HasSuffix(r.URL.Path,"identity"){w.Header().Set("Content-Type","application/json");_,_=io.WriteString(w,`{"system_id":"isolated-feasibility"}`);return};handler.ServeHTTP(w,r)})}
  go server.Serve(listener);defer server.Close()
  connector:=exec.Command(os.Args[3],"http://"+listener.Addr().String(),filepath.Dir(os.Args[2]))
  connector.Env=append(os.Environ(),"APPDATA="+filepath.Join(filepath.Dir(os.Args[2]),"isolated-appdata"))
  input,e:=connector.StdinPipe();check(e);output,e:=connector.StdoutPipe();check(e);connector.Stderr=os.Stderr
  check(connector.Start());defer func(){input.Close();connector.Wait()}()
  _,e=io.WriteString(input,`{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-06-18","capabilities":{},"clientInfo":{"name":"isolated-probe","version":"1"}}}`+"\n");check(e)
  line,e:=bufio.NewReader(output).ReadBytes('\n');check(e);var reply map[string]any;check(json.Unmarshal(line,&reply));if reply["error"]!=nil{panic(string(line))}
  event("connector_ready",map[string]any{"pid":connector.Process.Pid})
 }

 m,e:=embedding.OpenManaged(os.Args[1]);check(e);defer m.Close()
 batch:=make([]string,32);for i:=range batch{batch[i]=fmt.Sprintf("fact %02d",i)}
 for _,s:=range []struct{name string;docs []string}{
  {"short_query",nil},
  {"document",[]string{strings.Repeat("A project record describes source evidence, participants, dates, conditions and decisions. ",3)}},
  {"chinese_document",[]string{strings.Repeat("项目资料需要保留来源和适用条件。",6)}},
  {"batch_documents",[]string{"A project record describes source evidence and conditions.", "The person changed plans and recorded the reason and relevant dates.", "A separate source provides supporting observations for the same project."}},
  {"batch32",batch},
 }{
  event(s.name+"_start",map[string]any{});t:=time.Now();n:=0
  if s.docs==nil { v,e:=m.EmbedQuery(ctx,"Which source explains the project conditions?");check(e);n=len(v) } else { v,e:=m.EmbedDocuments(ctx,s.docs);check(e);n=len(v) }
  event(s.name+"_end",map[string]any{"elapsed_ms":time.Since(t).Seconds()*1000,"count":n});time.Sleep(250*time.Millisecond)
 }
 event("complete",map[string]any{});time.Sleep(500*time.Millisecond)
}
