# 单元二验证复现

在证据对应的源码版本、Windows x64、既定EmbeddingGemma模型及单元一正式运行时上执行。无外部AI调用，不迁移用户资料。

1. 全仓验证：`go test -p 2 ./...`、`go vet ./...`。
2. 将本包的 `vectors.bin` 与 `query-cases.json` 解压到独立目录；将其绝对路径设为 `OWNWARD_VECTOR_FIXTURE`，将报告输出的绝对路径设为 `OWNWARD_VECTOR_REPORT`；执行 `go test ./internal/boundedstore -run TestFrozenVectorFixture -count=1 -v`。测试宿主建立旧内存索引用于逐项对照，不计作产品运行内存。
3. 将 `measure.py` 放入仓库的 `.tmp/bounded-unit2/`；按单元一证据的 bundle 命令把同一模型与锁定运行时装配到 `.tmp/bounded-unit1/formal-bundle`。以下PowerShell命令只编译正式命令源码和必要的资源测试入口：

```powershell
$package = go list -json ./cmd/ownward | ConvertFrom-Json
$files = @($package.GoFiles | ForEach-Object { Join-Path $package.Dir $_ })
$files += (Resolve-Path cmd/ownward/bounded_storage_test.go).Path
go test -c -trimpath '-ldflags=-s -w' -o .tmp/bounded-unit2/ownward-test.exe @files
python .tmp/bounded-unit2/measure.py
```

测量器使用已有Python psutil，自己不计入产品进程树。记录服务、连接器及本地模型；服务和连接器采用正式代码的20／12 MiB Go软目标，不设置额外环境内存上限。语义提交使用固定有效组织结果，用于核对存储与检索机制，不代表外部AI语义组织质量或耗时。

4,734条向量及13个查询均为已有前置验证材料。产品测试检查归块前后的候选、原分数与排序逐项相等；初始全量delta仅作无筛选参照，正式发布存在256条触发和1,024条背压。报告的向量读取量是逻辑载荷，不是物理页面或SSD读取量；没有清空操作系统缓存。三种正文规模的端到端测量是单次完整路径验证，不冒充发布p95、长期容量或单元四验收。
