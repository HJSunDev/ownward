import subprocess, pathlib, os, json, time, threading, urllib.request, hashlib, psutil
root=pathlib.Path('.tmp/bounded-unit2').resolve();work=root/('measure-'+str(time.time_ns()));work.mkdir()
exe=root/'ownward-test.exe';env=dict(os.environ,GOMAXPROCS='4',OWNWARD_BOUND_ROLE='service',OWNWARD_BOUND_DIR=str(work),OWNWARD_BOUND_BUNDLE=str(pathlib.Path('.tmp/bounded-unit1/formal-bundle').resolve()),OWNWARD_BOUND_RETRIEVAL='1')
log=(work/'service.log').open('wb');service=subprocess.Popen([str(exe),'-test.run=^TestBoundedStorageProcess$'],stdin=subprocess.PIPE,stdout=log,stderr=log,env=env,creationflags=subprocess.DETACHED_PROCESS)
roots=[service.pid];stop=False;peak=0;private_peak=0;non_model_peak=0;individual={};samples=[]
def monitor():
 global peak, private_peak, non_model_peak
 while not stop:
  total=0;private=0;non_model=0;detail={}
  for pid in list(roots):
   try: allp=[psutil.Process(pid)]+psutil.Process(pid).children(recursive=True)
   except psutil.Error:continue
   for p in allp:
    try:
     mem=p.memory_info();rss=mem.rss;total+=rss;private+=getattr(mem,"private",mem.vms);non_model+=rss if p.name()!="llama-server.exe" else 0;detail[str(p.pid)]=[p.name(),rss];individual[p.name()]=max(individual.get(p.name(),0),rss)
    except psutil.Error:pass
  private_peak=max(private_peak,private);non_model_peak=max(non_model_peak,non_model)
  if total>peak:peak=total;samples.append({'rss':total,'processes':detail})
  time.sleep(.02)
thread=threading.Thread(target=monitor);thread.start();connector=None
try:
 deadline=time.monotonic()+25
 while not (work/'endpoint').exists():
  if service.poll() is not None:raise RuntimeError((work/'service.log').read_text(errors='replace'))
  if time.monotonic()>deadline:raise RuntimeError('service startup timeout')
  time.sleep(.05)
 endpoint=(work/'endpoint').read_text()
 env.update(OWNWARD_BOUND_ROLE='connector',OWNWARD_BOUND_ENDPOINT=endpoint)
 err=(work/'connector.log').open('wb')
 connector=subprocess.Popen([str(exe),'-test.run=^TestBoundedStorageProcess$'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,env=env,creationflags=subprocess.DETACHED_PROCESS);roots.append(connector.pid)
 def send(v):connector.stdin.write(json.dumps(v,ensure_ascii=False,separators=(',',':')).encode()+b'\n');connector.stdin.flush()
 def request(v):
  send(v)
  while True:
   line=connector.stdout.readline()
   if not line:raise RuntimeError('connector ended: '+(work/'connector.log').read_text(errors='replace'))
   result=json.loads(line)
   if result.get('id')==v['id']:return result
 request({'jsonrpc':'2.0','id':1,'method':'initialize','params':{'protocolVersion':'2025-03-26','capabilities':{},'clientInfo':{'name':'external-fixture','version':'1'}}})
 send({'jsonrpc':'2.0','method':'notifications/initialized'})

 metrics=[];counter=2
 def call(name,args):
  global counter
  key=counter;counter+=1
  result=request({'jsonrpc':'2.0','id':key,'method':'tools/call','params':{'name':name,'arguments':args,'_meta':{'ownward/operation':'op-'+str(key),'ownward/generation':1}}})
  if result.get('error') or result.get('result',{}).get('isError'):raise RuntimeError(str(result)[:1600])
  v=result['result']['structuredContent'];assert json.loads(result['result']['content'][0]['text'])==v
  return v
 for size in [4096,1024*1024,8*1024*1024]:
  text='项目负责人是李明。预算三万元。\n\n'+('background record.\n\n'*((size//20)+1))
  start=time.monotonic();created=call('ownward_create',{'content':text});create_time=time.monotonic()-start
  asset=created['result']['information']['id'];assert created['result']['information']['content']==text
  start=time.monotonic();semantic_work=call('ownward_semantic_work',{'asset_ids':[asset]})['work'][0];work_time=time.monotonic()-start
  assert semantic_work['asset']['content']==text
  sub={'schema':semantic_work['schema'].replace('semantic-work','semantic-submission'),'work_id':semantic_work['id'],'asset_id':asset,'asset_revision':1,'capability':{'id':'fixture','version':'1'},'status':'complete','analysis':{'cues':[],'topics':[],'summary':'项目负责人李明，预算三万元。','organization':{'schema':semantic_work['organization_schema'],'units':[{'id':'whole','selector':{'exact':''},'statement':'项目负责人和预算的原始记录。'}],'links':[]}}}
  start=time.monotonic();accepted=call('ownward_semantic_submit',{'submission':sub});submit_time=time.monotonic()-start
  start=time.monotonic();hits=call('ownward_search',{'query':'项目负责人 李明 预算','limit':3})['results'];search_time=time.monotonic()-start
  hit=next(h for h in hits if h['id']==asset);assert hit['evidence']
  start=time.monotonic();ev=call('ownward_evidence_read',{'id':hit['evidence'][0]['id']})['evidence'];evidence_time=time.monotonic()-start
  assert '李明' in ev['content']
  metrics.append({'source_bytes':len(text.encode()),'create_seconds':create_time,'semantic_work_seconds':work_time,'semantic_submit_seconds':submit_time,'search_seconds':search_time,'evidence_seconds':evidence_time,'source_exact':True,'evidence_exact':True,'response_forms_equal':True})
  print(metrics[-1],flush=True)

finally:
 if connector is not None:
  connector.stdin.close()
  try:connector.wait(timeout=8)
  except subprocess.TimeoutExpired:connector.terminate();connector.wait()
 if service.poll() is None:service.stdin.write(b'x');service.stdin.flush();service.wait(timeout=10)
 stop=True;thread.join();log.close()
 evidence={'peak_mib':peak/1048576,'private_commit_peak_mib':private_peak/1048576,'non_model_peak_mib':non_model_peak/1048576,'individual_peak_mib':{k:v/1048576 for k,v in individual.items()},'peak_observations':samples[-5:],'tests':locals().get('metrics',[]),'service_exit':service.returncode,'connector_exit':connector.returncode if connector else None}
 (work/'result.json').write_text(json.dumps(evidence,indent=2),encoding='utf-8');print(json.dumps({'work':str(work),**evidence},ensure_ascii=False),flush=True)
