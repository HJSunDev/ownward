# Unit two review evidence

The archive root preserves the original resource/vector measurement and its source hashes. `review/` contains the later independent findings, repairs and fixed-version checks. Resource measurements are not relabelled as measurements of the repaired version.

## Version boundaries

- Measured implementation: `0e7f9bba8c075985b2fdb98fe17a653444cef04cc79d673494a3adc55196725f`; root `source-sha256.json`, resource/vector results and fixtures.
- First repairs: `80eed860d048ddf4613ae57f64b394908798860f82032ed4de7830d1c12e9054`; `round2-source-hashes.json` and the second complete review.
- Compact string references: `b7039c153806f4bbf44352f4a425238002ae27ad4d0ab60d23dd83fca8dee19c`; `round3-source-hashes.json`, affected-package checks and the third complete review. The final decision is in `b/round3-review.json`.

`measured-source.patch` applies to base commit `24189d425f6ff2df2ba5d4f867f237f227399e37` in a separate checkout to restore the measured Go sources and manifest. Runtime/model artifacts remain those of the unit-one reproduction bundle; they are not copied into this review archive. Source hashes retain the measured byte identities; Git checkout line endings may differ without changing source content.

## Recheck repaired behavior

Use the repository version matching `round3-source-hashes.json`:

```sh
go test -p 2 ./internal/streamjson ./internal/semanticstream ./internal/core ./internal/boundedstore ./internal/adapter/mcpserver
go vet ./internal/streamjson ./internal/semanticstream ./internal/core ./internal/boundedstore ./internal/adapter/mcpserver
go run ./cmd/ownward-composition verify --repository . --manifest manifests/compositions/v1/current-collaborative.json
```

The formal regression tests cover delivery lock ordering, accepted-result recovery without AI redispatch, explicit graph priority, navigation publication order and bounded reference/organization metadata. The organization regression passes the public schema; it intentionally does not assert semantic validity or whole-process RSS. It checks rejection-path retained metadata without shrinking the public item counts.

Historical reviewer probes and outputs remain under `b/`. Overlay paths are machine-specific and must be regenerated for the chosen checkout; formal regression tests above do not require overlays. The exploratory round-two fixture with extra endpoint fields is not public-entry evidence; the schema-validated replacement is identified explicitly in that round's report.

These checks make no new 14/24/500-question score, external-AI latency, complete-product migration or later-unit acceptance claim.
