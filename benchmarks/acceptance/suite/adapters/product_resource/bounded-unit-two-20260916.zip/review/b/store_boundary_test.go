package boundedstore

import (
 "context"
 "database/sql"
 "testing"
 "time"
 "github.com/HJSunDev/ownward/internal/domain"
 "github.com/HJSunDev/ownward/internal/derived"
 "github.com/HJSunDev/ownward/internal/semantics"
)

func TestReviewNavigationOrderAfterUpdatingEarlierSource(t *testing.T){
 s:=retrievalStore(t);ctx:=context.Background()
 if e:=s.CreateGeneration(ctx,"g","space");e!=nil{t.Fatal(e)}
 var records []derived.Record
 for _,id:=range []string{"target","a","b"}{
  putRetrievalAsset(t,s,domain.Information{ID:id,Revision:1,Content:"source "+id})
  r:=derived.Record{AssetID:id,AssetRevision:1,Status:"ready",InputsKnown:true,Analysis:semantics.Analysis{Summary:"source"}}
  if id!="target"{r.Analysis.Relations=[]semantics.Relation{{Type:"supports",TargetID:"target",TargetRevision:1,Confidence:1,Evidence:"source evidence"}}}
  records=append(records,r);putRecord(t,s,r)
 }
 if e:=s.ActivateGeneration(ctx,"g","");e!=nil{t.Fatal(e)}
 old:=derived.NewIndex(append([]derived.Record(nil),records...))
 records[1].AssetRevision=2
 putRetrievalAsset(t,s,domain.Information{ID:"a",Revision:2,Content:"updated source a"})
 putRecord(t,s,records[1]);old.Upsert(records[1])
 want,e:=old.NavigatePage([]string{"target"},nil,1,1);if e!=nil{t.Fatal(e)}
 got,e:=s.NavigatePage(ctx,"g",[]string{"target"},nil,1,1);if e!=nil{t.Fatal(e)}
 if len(got.Edges)!=1||len(want.Edges)!=1{t.Fatalf("unexpected count: got %+v want %+v",got,want)}
 t.Logf("first page after source a update: new=%s old=%s",got.Edges[0].SourceID,want.Edges[0].SourceID)
 if got.Edges[0].SourceID!=want.Edges[0].SourceID{t.Error("navigation first-page candidate changed after source update")}
}

func TestReviewMixedDeliveryChecksMakeProgress(t *testing.T){
 s:=retrievalStore(t);ctx,cancel:=context.WithTimeout(context.Background(),700*time.Millisecond);defer cancel()
 stamp,e:=s.RetrievalStamp(ctx);if e!=nil{t.Fatal(e)}
 held,release:=make(chan struct{}),make(chan struct{})
 writerDone:=make(chan error,1)
 go func(){writerDone<-s.write(ctx,func(tx *sql.Tx)error{close(held);<-release;return nil})}()
 <-held
 savedDone:=make(chan error,1)
 go func(){savedDone<-s.AuthorizeDelivery(ctx,nil)}()
 // Let the saved-result check queue behind the in-flight write before
 // retrieval checks take the two available readers. No source is modified.
 time.Sleep(15*time.Millisecond)
 retrievedDone:=make(chan error,2)
 for i:=0;i<2;i++{go func(){retrievedDone<-s.AuthorizeRetrieval(ctx,stamp)}()}
 deadline:=time.Now().Add(150*time.Millisecond)
 for len(s.readers)!=0&&time.Now().Before(deadline){time.Sleep(time.Millisecond)}
 if len(s.readers)!=0{close(release);t.Fatal("failed to arrange overlapping delivery checks")}
 close(release)
 if e:=<-writerDone;e!=nil{t.Fatal(e)}
 savedErr:=<-savedDone;one,two:=<-retrievedDone,<-retrievedDone
 t.Logf("delivery errors: saved=%v retrieval1=%v retrieval2=%v",savedErr,one,two)
 if savedErr!=nil||one!=nil||two!=nil{t.Error("completed write leaves reader/mutex lock cycle until request deadline")}
}
