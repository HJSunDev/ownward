# 执行单元二：首轮完整独立审查

审查人：B（乔布斯）。日期：2026-09-16。**本轮审查已结束，结论为需要修复，不能关闭单元二。** 以下为一次性交付的完整结论，不是中途发现。

被审对象是包含暂存修改的工作区，composition：`0e7f9bba8c075985b2fdb98fe17a653444cef04cc79d673494a3adc55196725f`。首尾核对固定清单208项均一致；末次校验见 `final-source-check.json`。正式代码、权威文档、暂存区和历史均未修改。新增复现只在本目录，通过Go overlay使用被审源码；未调用外部AI，未启动本地真实模型，未准备资料或运行整套题目。

## 审查覆盖与有效成果

结合产品需求、有界运行架构、执行单元、存入与派生数据说明，检查了保存后组织准备、语义提交与回执、词法和向量候选、融合排序、场景过滤、图导航与依据、世代及依赖有效性、发布事务、向量归块与精确回退、流式接入与交付检查、资源预算及测量代码。

原文分块、持久化索引、有界向量筛选、模型调用不持有查询快照、组织发布时验证修订及依赖等实现成果应保留。本次未重新跑A已保存的全仓测试、4734向量×13查询及完整本地模型资源实验；复用其证据，独立核对实现与适用边界。损坏筛选回退保留原始向量精算，未发现靠近似Top-K放宽质量的行为。

资源压缩包SHA256实核为 `88f9b0adfd2dd8a1fa72e583696af05fd9e93f9bd2f8b5fb9fee4fe7dc00306e`。其211.16 MiB进程树峰值、51.40 MiB非模型峰值支持该串行小样的实测结论；将非模型内部预留调整为56 MiB的算式成立，200+56+8=264 MiB。但该实验没有覆盖下面的并发交付和大引用字段问题，不能以该峰值替代预算边界验证。

## 必须处理的五项

### B1 / P1：保存与检索的交付检查存在锁顺序反转

**场景与影响：** 一次写入结束前，保存结果与两个已生成的检索结果同时进入最后交付核验。预期各自核对当前权限和版本后返回；实际三个检查互相等待，直到请求截止时间才退出。没有截止时间时存在持续等待风险。

**原因：** `internal/boundedstore/access.go:140` 的 `AuthorizeDelivery` 先取 `writeMu` 再取读连接；新增 `internal/boundedstore/retrieval_state.go:38` 的 `AuthorizeRetrieval` 先占读连接再等待 `writeMu`。两个检索检查可占完两条读连接，保存检查持写锁等连接，形成闭环。产品操作的4 MiB额度在返回结果对象时已经释放，后续交付检查没有被该额度串行化。

**证据：** `TestReviewMixedDeliveryChecksMakeProgress` 使用真实Store：先让一次写事务持锁，保存检查先排队，再让两个检索检查占满读连接，释放写事务；三个检查均等到700毫秒截止而报 `context deadline exceeded`。测试只控制重叠顺序，没有改源码或模拟查询返回。见 `store_boundary_test.go`、`delivery-results.jsonl`。

**修复目标：** 各交付检查及持读快照后需要写入的路径采用无环的资源获取顺序；保持最终权限、版本核验和取消能力。这是当前交付路径问题，不能后置到单元三维护。

### B2 / P2：已接受的语义结果因本地向量失败被重新派给外部智能

**场景与影响：** 长资料已完成语义提交，只有本地向量生成暂时失败。预期保留已接受结果，仅恢复向量；实际 `ownward_semantic_work` 再次返回同一个语义工作，宿主可能重复调用外部智能，新的不同结果又会被已存在的回执拒收。

**原因：** `internal/core/streaming_semantic_work.go` 领取工作只根据当前组织 `Status == pending`，没有使用已有的 `HasPendingSemanticWork()` 语义，即工作引用存在且尚无 `SemanticReceipt`。提交阶段将本地向量失败也记为pending，并保留语义回执。

**证据：** `TestReviewAcceptedResultNotRedispatched` 经真实MCP/HTTP入口，在固定向量桩返回失败时接受语义；返回状态pending且无外部工作required_action，但再领取得到1项工作。恢复向量桩后复用原提交可成功ready，证明无需重做语义。旧实现相同“已接受但缺向量”状态领取0项。见 `mcp_boundary_test.go`、`mcp-boundary-results.jsonl`；旧实现观察见 `baseline-results.jsonl` 的首个结果。

**修复目标：** 已接受语义的向量待恢复状态不重新派发AI工作，原回执接续仍可补齐向量；待生成语义、uncertain和真正过期工作保持原合同。

### B3 / P2：反向推导关系绕过用户明确关系的优先规则

**场景与影响：** 用户明确保存A支持B，语义提交又提出B与A矛盾的incoming关系。预期保持用户的明确关系优先；实际导航同时交付A→B supports及B→A contradicts，改变了原有冲突处理合同。

**原因：** `internal/boundedstore/graph.go:88` 的覆盖判断仅比较变换方向后的source/target；incoming交换两端后不会匹配当前资产已声明的目标。流式提交也没有保留 `core/collaboration.go` 对当前资产explicitTargets的incoming抑制。

**证据：** `TestReviewExplicitRelationWinsIncomingInference` 经正式MCP入口复现两条冲突边，见 `mcp-boundary-results.jsonl`。旧实现明确关系优先的两项既有测试独立运行通过，见 `explicit-contract-baseline.jsonl`，包括 `TestExplicitRelationOnCurrentInformationSuppressesReverseInference`。

**修复目标：** 按既有规则处理当前来源和另一端来源的明确关系优先，不能仅修复此测试的一个方向；同时保留允许的incoming推导、更新失效和原文关系本身。

### B4 / P2：更新来源后，图导航的有限页面候选与旧实现不同

**场景与影响：** A、B均指向同一目标，更新较早的A后，按目标导航且只取一条关系。旧实现先返回B，新实现先返回A。有限页的实际候选已经变化，不能表述为仅显示顺序不同或候选预算等价；搜索关系扩展也使用这条导航路径。

**原因：** `internal/boundedstore/navigation.go:44` 固定按方向、owner资产ID、ordinal排序；旧索引更新时删除并重新追加该来源的边。因此新实现没有保存既有运行中邻接枚举顺序。`VisitAdjacent` 同样使用资产ID排序。

**证据：** 三份固定资产、同样两条关系、同样A修订更新，在真实新Store与 `derived.Index.Upsert/NavigatePage` 对照：`new=a old=b`。见 `TestReviewNavigationOrderAfterUpdatingEarlierSource`、`store_boundary_test.go`、`extra-boundary-results.jsonl`。A现有静态小图和链式分页对照没有覆盖这个更新顺序。

**修复目标：** 在当前“候选、顺序和预算等价”的约束下保持更新后的导航及分页结果一致，并检查正反邻接、grounded关系与接续；不能通过放宽验收、扩大结果数量消除差异。

### B5 / P2：语义输入引用按条数限制，仍能越过整操作内存预留

**场景与影响：** 已认证调用提交符合字段类型的大引用数组，即使引用最后会因无效而拒绝，解析阶段也会先把大量身份字符串保留在内存。当前原文流式化并不能约束这部分峰值。

**原因：** `internal/core/streaming_semantic_fields.go:96` 接收最多660项，每项允许64 KiB完整反序列化并追加到切片；所有引用读取结束后，`streaming_submit.go` 才核对当前引用。这些驻留字符串不计入预算。公开Schema没有提前限定引用字符串长度。其他逐项smallField/DecodeSmall与累计保留路径也应按同一责任边界检查，而非只降低该测试条数。

**证据：** 在正式4 MiB子预算下，磁盘输入含96个60 KiB身份字符串，`readSemanticHeader` 成功返回；仅身份正文就保留5,898,240字节，GC后的净堆增量6,299,768字节，子预算Used为0。见 `TestReviewSemanticReferencesStayWithinWholeOperationBytes`、`core_budget_test.go`、`extra-boundary-results.jsonl`。这是预算越界的局部复现，**没有据此声称测得完整产品RSS超过270 MiB**。

**修复目标：** 在累计分配前校验/计量引用身份或流式处理，使不合法引用及时拒绝，合法完整输入遵守共享字节预算；不能把GC软目标当作预先准入的替代。

## 证据边界与收尾安排

- 本轮5个针对新实现的缺陷复现均触发预期问题；另外2项旧实现明确关系合同测试通过。原提交恢复向量的正向控制也通过。完整命令见 round1-review.json，输出见本目录JSONL；overlay未覆盖任何正式源码文件。
- `baseline-results.jsonl` 的合并对照前半证明旧实现不重派已接受工作；后半遇到旧协作路径“输入已变化”的其他验证失败，不能计作反向关系对照通过。因此保留该记录，改用两项既有独立合同测试及真实新入口复现判断B3；没有修改旧实现来制造通过。
- 另观察到NameSource将原NameSearch的100项上限改为400；尚未验证其对最终可见结果的具体影响，不列为第六个已确认缺陷。A处理B4的整体候选预算等价时应一并核对，避免静态小样掩盖预算变化。
- 磁盘维护、长时WAL与回收收敛、遗忘物理清除、迁移启用及完整产品发布仍属于单元三/四，没有作为本轮欠项扩面。真实模型费用、外部AI等待和14/24题成绩没有新增结论。
- 原资源样本4 KiB检索0.187秒、1 MiB 0.938秒、8 MiB 11.031秒，是不同负载的各次测量；不合并为“用户平均等待”，也不代表冷读/p95。落盘向量87.11毫秒为既有温缓存记录，逻辑载荷不能冒充物理I/O。本轮不要求为了重测这些已有效的样本而重新准备语义资料。

**交接：** A收到本完整报告后集中修复、自验并更新权威状态和证据，一次性交付新的固定版本供B复审；在此之前不关闭单元二。B本轮测试资源已释放，审查到此结束，不自行修改正式实现或启动下一单元。
