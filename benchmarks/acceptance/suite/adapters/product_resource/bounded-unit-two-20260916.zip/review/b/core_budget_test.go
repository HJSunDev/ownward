package core

import (
 "context"
 "io"
 "path/filepath"
 "runtime"
 "strings"
 "testing"
 "github.com/HJSunDev/ownward/internal/assetlog"
 "github.com/HJSunDev/ownward/internal/derived"
 "github.com/HJSunDev/ownward/internal/semantics"
 "github.com/HJSunDev/ownward/internal/domain"
 "github.com/HJSunDev/ownward/internal/resourcebudget"
 "github.com/HJSunDev/ownward/internal/streamjson"
)

func TestReviewSemanticReferencesStayWithinWholeOperationBytes(t *testing.T){
 budget,_:=resourcebudget.New(4*resourcebudget.MiB,0)
 ctx:=resourcebudget.WithContext(context.Background(),budget)
 dir:=t.TempDir()
 doc,e:=streamjson.Build(ctx,dir,budget,32*resourcebudget.MiB,func(w io.Writer)error{
  io.WriteString(w,`{"input_assets":[`)
  field:=strings.Repeat("x",60*1024)
  for i:=0;i<96;i++ {if i>0{io.WriteString(w,",")};io.WriteString(w,`{"id":"`+field+`","revision":1}`)}
  _,e:=io.WriteString(w,`],"analysis":{}}`);return e
 });if e!=nil{t.Fatal(e)};defer doc.Close()
 runtime.GC();var before,after runtime.MemStats;runtime.ReadMemStats(&before)
 s:=&StreamingAssets{Budget:budget,Scratch:dir,DiskBytes:32*resourcebudget.MiB}
 sub,_,e:=s.readSemanticHeader(ctx,doc.Root(),domain.Information{})
 if e!=nil{t.Fatal(e)}
 runtime.GC();runtime.ReadMemStats(&after)
 var retained int;for _,r:=range sub.InputAssets{retained+=len(r.ID)}
 t.Logf("references=%d retained_identity_bytes=%d heap_delta=%d budget_used=%d",len(sub.InputAssets),retained,int64(after.HeapAlloc)-int64(before.HeapAlloc),budget.Used())
 runtime.KeepAlive(sub)
 if int64(retained)>4*resourcebudget.MiB{t.Error("reference identities alone exceed the 4 MiB whole-operation reservation before current-reference validation")}
}

func TestReviewBaselineAcceptedAndExplicitContracts(t *testing.T){
 ctx:=context.Background();dir:=t.TempDir()
 assets,e:=assetlog.Open(filepath.Join(dir,"assets"));if e!=nil{t.Fatal(e)}
 state,e:=derived.Open(filepath.Join(dir,"derived"));if e!=nil{t.Fatal(e)}
 vectors:=&boundedSemanticEmbedding{failNext:true}
 old,e:=newTestCollaborative(t,assets,state,vectors);if e!=nil{t.Fatal(e)};defer old.Close()
 first,e:=old.Create(ctx,CreateInput{Content:strings.Repeat("long source. ",40)});if e!=nil{t.Fatal(e)}
 work,e:=old.SemanticWorkFor(ctx,[]string{first.Information.ID});if e!=nil||len(work)!=1{t.Fatal("work",e,len(work))}
 sub:=semanticSubmission(work[0],semantics.Analysis{Summary:"Fixed source summary."})
 accepted,e:=old.SubmitSemantic(ctx,sub);if e!=nil||accepted.Status!="pending"{t.Fatal("accepted",e,accepted)}
 after,e:=old.SemanticWorkFor(ctx,[]string{first.Information.ID});if e!=nil||len(after)!=0{t.Fatal("already accepted redispatched",e,len(after))}
 t.Logf("baseline after accepted result/local-vector failure: work_count=%d",len(after))
 b,e:=old.Create(ctx,CreateInput{Content:"Budget document."});if e!=nil{t.Fatal(e)}
 a,e:=old.Create(ctx,CreateInput{Content:"Budget explanation.",Relations:[]domain.ExplicitRelation{{Type:"supports",TargetID:b.Information.ID}}});if e!=nil{t.Fatal(e)}
 aw,e:=old.SemanticWorkFor(ctx,[]string{a.Information.ID});if e!=nil||len(aw)!=1{t.Fatal("a work",e,len(aw))}
 incoming:=semanticSubmission(aw[0],semantics.Analysis{Summary:"Fixed source summary.",Relations:[]semantics.Relation{{Type:"contradicts",TargetID:b.Information.ID,TargetRevision:1,Confidence:1,Direction:"incoming",Evidence:"Budget evidence."}}})
 if _,e=old.SubmitSemantic(ctx,incoming);e!=nil{t.Fatal(e)}
 nav,e:=old.Navigate(ctx,[]string{a.Information.ID},nil,1,20);if e!=nil{t.Fatal(e)}
 t.Logf("baseline explicit-priority navigation: %+v",nav.Edges)
 for _,edge:=range nav.Edges{if edge.Type=="contradicts"{t.Error("baseline did not enforce explicit priority")}}
}
