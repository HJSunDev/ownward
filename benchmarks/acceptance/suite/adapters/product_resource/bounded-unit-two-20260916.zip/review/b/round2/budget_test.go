package core

import (
 "context"
 "fmt"
 "io"
 "runtime"
 "strings"
 "testing"
 "github.com/HJSunDev/ownward/internal/domain"
 "github.com/HJSunDev/ownward/internal/resourcebudget"
 "github.com/HJSunDev/ownward/internal/semanticstream"
 "github.com/HJSunDev/ownward/internal/streamjson"
)

func TestReview2ReferenceRejectsBeforeAccumulation(t *testing.T){
 budget,_:=resourcebudget.New(4*resourcebudget.MiB,0);ctx:=resourcebudget.WithContext(context.Background(),budget);dir:=t.TempDir()
 s:=&StreamingAssets{Budget:budget,Scratch:dir,DiskBytes:32*resourcebudget.MiB}
 for _,test:=range []struct{count,size int;valid bool}{{96,60*1024,false},{660,256,true}}{
  doc,e:=streamjson.Build(ctx,dir,budget,32*resourcebudget.MiB,func(w io.Writer)error{
   io.WriteString(w,`{"input_assets":[`)
   for i:=0;i<test.count;i++{if i>0{io.WriteString(w,",")};fmt.Fprintf(w,`{"id":"%03d%s","revision":1,"organization_snapshot":"org_%s"}`,i,strings.Repeat("x",test.size-3),strings.Repeat("a",64))}
   _,e:=io.WriteString(w,`],"analysis":{}}`);return e
  });if e!=nil{t.Fatal(e)}
  sub,_,e:=s.readSemanticHeader(ctx,doc.Root(),domain.Information{})
  if test.valid {if e!=nil||len(sub.InputAssets)!=test.count{t.Errorf("valid references lost: count=%d err=%v",len(sub.InputAssets),e)}} else if e==nil||len(sub.InputAssets)!=0{t.Errorf("oversized identity retained: count=%d err=%v",len(sub.InputAssets),e)}
  t.Logf("size=%d count=%d retained=%d error=%v",test.size,test.count,len(sub.InputAssets),e);doc.Close()
 }
}

func TestReview2OrganizationAggregateWorkingSet(t *testing.T){
 budget,_:=resourcebudget.New(4*resourcebudget.MiB,0);ctx:=resourcebudget.WithContext(context.Background(),budget);dir:=t.TempDir()
 doc,e:=streamjson.Build(ctx,dir,budget,32*resourcebudget.MiB,func(w io.Writer)error{
  io.WriteString(w,`{"schema":"ownward.organization/v2","units":[`)
  selector:=`{"exact":"Alice","prefix":"","suffix":""}`
  for u:=0;u<128;u++{if u>0{io.WriteString(w,",")};fmt.Fprintf(w,`{"id":"u%d","statement":"Alice","selector":%s,"context":[`,u,selector)
   for c:=0;c<16;c++{if c>0{io.WriteString(w,",")};io.WriteString(w,selector)};io.WriteString(w,`],"mentions":[`)
   for m:=0;m<32;m++{if m>0{io.WriteString(w,",")};fmt.Fprintf(w,`{"id":"m%d","name":"Alice","role":"person","selector":%s}`,m,selector)};io.WriteString(w,`]}`)
  };io.WriteString(w,`],"links":[`)
  endpoint:=`{"asset_id":"a","unit_id":"u0","mention_id":"m0","object_name":"","object_role":"","selector":`+selector+`}`
  for l:=0;l<128;l++{if l>0{io.WriteString(w,",")};fmt.Fprintf(w,`{"type":"supports","meaning":"Alice","source":%s,"target":%s,"conditions":[`,endpoint,endpoint)
   for c:=0;c<16;c++{if c>0{io.WriteString(w,",")};io.WriteString(w,endpoint)};io.WriteString(w,`]}`)
  };_,e:=io.WriteString(w,`]}`);return e
 });if e!=nil{t.Fatal(e)};defer doc.Close()
 runtime.GC();var before,after runtime.MemStats;runtime.ReadMemStats(&before)
 org,e:=semanticstream.ReadOrganization(doc.Root());if e!=nil{t.Fatal(e)}
 runtime.GC();runtime.ReadMemStats(&after)
 delta:=int64(after.HeapAlloc)-int64(before.HeapAlloc)
 t.Logf("units=%d links=%d heap_delta=%d child_budget_used=%d",len(org.Units),len(org.Links),delta,budget.Used());runtime.KeepAlive(org)
 if delta>4*resourcebudget.MiB{t.Errorf("organization metadata alone exceeds 4 MiB whole-operation reservation before semantic validation")}
}
