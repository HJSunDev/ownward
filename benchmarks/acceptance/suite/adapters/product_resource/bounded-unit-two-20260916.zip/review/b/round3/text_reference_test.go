package streamjson

import (
 "bytes"
 "context"
 "encoding/json"
 "errors"
 "io"
 "strings"
 "testing"

 "github.com/HJSunDev/ownward/internal/resourcebudget"
)

func TestReview3CompactReferenceBytesAndLifetime(t *testing.T) {
 budget, _ := resourcebudget.New(4*resourcebudget.MiB, 0)
 for _, tc := range []struct{name, raw string}{
  {"empty", `""`},
  {"escapes", `"quote\" slash\\ /\/ \n\t\r\b\f 中文"`},
  {"surrogates", `"\u4e2d\u6587\ud83d\ude80\ud800x\udc00"`},
  {"buffer_boundaries", `"`+strings.Repeat("a", BufferBytes-7)+`\ud83d\ude80`+strings.Repeat("中", BufferBytes/3)+`\nend"`},
 } {
  t.Run(tc.name, func(t *testing.T) {
   var want string
   if err:=json.Unmarshal([]byte(tc.raw), &want);err!=nil {t.Fatal(err)}
   doc,err:=Parse(context.Background(),t.TempDir(),strings.NewReader(`{"before":"left","text":`+tc.raw+`,"after":"right"}`),budget,8*resourcebudget.MiB)
   if err!=nil {t.Fatal(err)}
   defer doc.Close()
   node,ok,err:=doc.Root().Field("text"); if err!=nil||!ok {t.Fatal(ok,err)}
   ref:=node.TextReference()
   // Compact references remain usable after traversal moves to other fields.
   if _,ok,err=doc.Root().Field("after");err!=nil||!ok {t.Fatal(ok,err)}
   read:=func(ctx context.Context,source interface{Open(context.Context)(io.ReadCloser,error)}) ([]byte,error) {
    r,err:=source.Open(ctx);if err!=nil{return nil,err};defer r.Close()
    var out bytes.Buffer
    _,err=io.CopyBuffer(&out,readerOnly{r},make([]byte,3))
    return out.Bytes(),err
   }
   got,err:=read(context.Background(),ref);if err!=nil||string(got)!=want {t.Fatalf("compact bytes differ: got=%d want=%d err=%v",len(got),len(want),err)}
   original,err:=read(context.Background(),node);if err!=nil||!bytes.Equal(original,got){t.Fatal("original Node parity",err)}
   // Reader closure must not close the owning document or prevent reopening.
   again,err:=read(context.Background(),ref);if err!=nil||!bytes.Equal(again,got){t.Fatal("reopen",err)}
   cancelled,cancel:=context.WithCancel(context.Background());cancel()
   if _,err=read(cancelled,ref);!errors.Is(err,context.Canceled){t.Fatalf("cancellation lost: %v",err)}
   if err=doc.Close();err!=nil {t.Fatal(err)}
   if _,err=read(context.Background(),ref);err==nil {t.Fatal("compact reference silently read a closed document")}
   if _,err=read(context.Background(),node);err==nil {t.Fatal("original Node unexpectedly read a closed document")}
  })
 }
}

type readerOnly struct{io.Reader}
