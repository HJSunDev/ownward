import subprocess, pathlib, os, json, time, threading, urllib.request, hashlib, psutil
import argparse
p=argparse.ArgumentParser()
p.add_argument('--binary',required=True,type=pathlib.Path)
p.add_argument('--bundle',required=True,type=pathlib.Path)
p.add_argument('--output',required=True,type=pathlib.Path)
a=p.parse_args();work=a.output.resolve();work.mkdir(parents=True,exist_ok=False)
exe=a.binary.resolve();env=dict(os.environ,GOMAXPROCS='4',OWNWARD_BOUND_ROLE='service',OWNWARD_BOUND_DIR=str(work),OWNWARD_BOUND_BUNDLE=str(a.bundle.resolve()))
log=(work/'service.log').open('wb');service=subprocess.Popen([str(exe),'-test.run=^TestBoundedStorageProcess$'],stdin=subprocess.PIPE,stdout=log,stderr=log,env=env,creationflags=subprocess.DETACHED_PROCESS)
roots=[service.pid];stop=False;peak=0;individual={};samples=[]
def monitor():
 global peak
 while not stop:
  total=0;detail={}
  for pid in list(roots):
   try: allp=[psutil.Process(pid)]+psutil.Process(pid).children(recursive=True)
   except psutil.Error:continue
   for p in allp:
    try:
     rss=p.memory_info().rss;total+=rss;detail[str(p.pid)]=[p.name(),rss];individual[p.name()]=max(individual.get(p.name(),0),rss)
    except psutil.Error:pass
  if total>peak:peak=total;samples.append({'rss':total,'processes':detail})
  time.sleep(.02)
thread=threading.Thread(target=monitor);thread.start();connector=None
try:
 deadline=time.monotonic()+25
 while not (work/'endpoint').exists():
  if service.poll() is not None:raise RuntimeError((work/'service.log').read_text(errors='replace'))
  if time.monotonic()>deadline:raise RuntimeError('service startup timeout')
  time.sleep(.05)
 endpoint=(work/'endpoint').read_text()
 env.update(OWNWARD_BOUND_ROLE='connector',OWNWARD_BOUND_ENDPOINT=endpoint)
 err=(work/'connector.log').open('wb')
 connector=subprocess.Popen([str(exe),'-test.run=^TestBoundedStorageProcess$'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,env=env,creationflags=subprocess.DETACHED_PROCESS);roots.append(connector.pid)
 def send(v):connector.stdin.write(json.dumps(v,ensure_ascii=False,separators=(',',':')).encode()+b'\n');connector.stdin.flush()
 def request(v):
  send(v)
  while True:
   line=connector.stdout.readline()
   if not line:raise RuntimeError('connector ended: '+(work/'connector.log').read_text(errors='replace'))
   result=json.loads(line)
   if result.get('id')==v['id']:return result
 request({'jsonrpc':'2.0','id':1,'method':'initialize','params':{'protocolVersion':'2025-03-26','capabilities':{},'clientInfo':{'name':'external-fixture','version':'1'}}})
 send({'jsonrpc':'2.0','method':'notifications/initialized'})
 metrics=[];counter=2
 for size in [4096,1024*1024,16*1024*1024]:
  text=('中文😀<&>"\\\n'*((size//25)+1))[:size//2]
  # The response must restore both public forms, byte for byte after JSON decoding.
  payload={'jsonrpc':'2.0','id':counter,'method':'tools/call','params':{'name':'ownward_create','arguments':{'content':text},'_meta':{'ownward/operation':'op-'+str(counter),'ownward/generation':1}}};counter+=1
  start=time.monotonic();result=request(payload);elapsed=time.monotonic()-start
  if result.get('error') or result.get('result',{}).get('isError'):raise RuntimeError(str(result)[:1000])
  value=result['result']['structuredContent'];assert value['result']['information']['content']==text
  assert json.loads(result['result']['content'][0]['text'])==value
  asset=value['result']['information']['id']
  payload['id']=counter;counter+=1;repeat=request(payload);assert repeat['result']['structuredContent']['result']['information']['id']==asset
  read=request({'jsonrpc':'2.0','id':counter,'method':'tools/call','params':{'name':'ownward_read','arguments':{'id':asset}}});counter+=1
  assert read['result']['structuredContent']['information']['content']==text
  metrics.append({'source_bytes':len(text.encode()),'request_bytes':len(json.dumps(payload,ensure_ascii=False).encode()),'create_seconds':elapsed,'byte_exact':True,'replay_exact':True,'read_exact':True})
  print(metrics[-1],flush=True)
  assert urllib.request.build_opener(urllib.request.ProxyHandler({})).open(endpoint+'/vectors',timeout=40).read()==b'ok'
 # Update preserves id/revision and subsequent retrieval.
 result=request({'jsonrpc':'2.0','id':counter,'method':'tools/call','params':{'name':'ownward_update','arguments':{'id':asset,'expected_revision':1,'content':'更新：全新正文'},'_meta':{'ownward/operation':'update-final','ownward/generation':1}}})
 assert result['result']['structuredContent']['result']['information']['revision']==2
finally:
 if connector is not None:
  connector.stdin.close()
  try:connector.wait(timeout=8)
  except subprocess.TimeoutExpired:connector.terminate();connector.wait()
 if service.poll() is None:service.stdin.write(b'x');service.stdin.flush();service.wait(timeout=10)
 stop=True;thread.join();log.close()
 evidence={'peak_mib':peak/1048576,'individual_peak_mib':{k:v/1048576 for k,v in individual.items()},'peak_observations':samples[-5:],'tests':locals().get('metrics',[]),'service_exit':service.returncode,'connector_exit':connector.returncode if connector else None}
 (work/'result.json').write_text(json.dumps(evidence,indent=2),encoding='utf-8');print(json.dumps({'work':str(work),**evidence},ensure_ascii=False),flush=True)
