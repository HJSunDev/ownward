package main
import("context";"crypto/sha256";"encoding/binary";"encoding/json";"fmt";"math";"os";"path/filepath";"strings";"time";"github.com/HJSunDev/ownward/internal/embedding")
func check(e error){if e!=nil{panic(e)}}
func main(){
 original:=os.Args[1];out:=os.Args[2];root:=filepath.Dir(out)
 raw,e:=os.ReadFile(filepath.Join(original,"manifest.json"));check(e);var m embedding.Manifest;check(json.Unmarshal(raw,&m))
 check(os.MkdirAll(filepath.Join(out,"model"),0700));target:=filepath.Join(out,m.Model.Path);if _,e=os.Stat(target);os.IsNotExist(e){check(os.Link(filepath.Join(original,m.Model.Path),target))}
 check(os.MkdirAll(filepath.Join(out,"runtime"),0700));entries,e:=os.ReadDir(filepath.Join(root,"runtime"));check(e);m.Runtime.Files=map[string]string{}
 for _,f:=range entries{p:=filepath.Join(root,"runtime",f.Name());b,e:=os.ReadFile(p);check(e);check(os.WriteFile(filepath.Join(out,"runtime",f.Name()),b,0700));m.Runtime.Files["runtime/"+f.Name()]=fmt.Sprintf("%x",sha256.Sum256(b))}
 archive,e:=os.ReadFile(filepath.Join(root,"llama-b10488-ownward-windows-x64.zip"));check(e);m.Runtime.SourceArchiveSHA256=fmt.Sprintf("%x",sha256.Sum256(archive));m.Capability="embeddinggemma-300m-qat-q8_0-llamacpp-b10488-bounded"
 m.Space.ID,e=embedding.ComputeSpaceID(m);check(e);raw,e=json.MarshalIndent(m,"","  ");check(e);check(os.WriteFile(filepath.Join(out,"manifest.json"),raw,0600))
 for _,bundle:=range []string{original,out}{model,e:=embedding.OpenManaged(bundle);check(e);batch:=make([]string,32);for i:=range batch{batch[i]=fmt.Sprintf("fact %02d",i)}
  for _,c:=range []struct{Name string;Docs []string}{{"short_query",nil},{"long_query",nil},{"document",[]string{strings.Repeat("A project record describes source evidence, participants, dates, conditions and decisions. ",3)}},{"chinese_document",[]string{strings.Repeat("项目资料需要保留来源和适用条件。",6)}},{"batch_documents",[]string{"A project record describes source evidence and conditions.","The person changed plans and recorded the reason and relevant dates.","A separate source provides supporting observations for the same project."}},{"batch32",batch}}{
   start:=time.Now();var vectors [][]float32
   if c.Docs==nil{query:="Which source explains the project conditions?";if c.Name=="long_query"{query=strings.Repeat("reason ",450)};v,e:=model.EmbedQuery(context.Background(),query);check(e);vectors=[][]float32{v}}else{vectors,e=model.EmbedDocuments(context.Background(),c.Docs);check(e)}
   h:=sha256.New();var bits [4]byte;for _,v:=range vectors{for _,f:=range v{binary.LittleEndian.PutUint32(bits[:],math.Float32bits(f));h.Write(bits[:])}}
   check(json.NewEncoder(os.Stdout).Encode(map[string]any{"bundle":bundle,"case":c.Name,"vectors":len(vectors),"sha256":fmt.Sprintf("%x",h.Sum(nil)),"elapsed_ms":time.Since(start).Milliseconds()}))
  };check(model.Close())
 }
}
