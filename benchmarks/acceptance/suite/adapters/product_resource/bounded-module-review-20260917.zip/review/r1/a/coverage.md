# Module requirements and evidence audit

Frozen source: commit 01f89d47e2f11331107b0ae817686fb88dade4ba; composition 52797ade3d38c1dd4ce6a25436653734552a893265a9d9e0b7efcf3cc583dd94. Production files remain unchanged during independent review.

| Requirement | Implementation and existing evidence | Assessment |
| --- | --- | --- |
| Durable original content, revisions and retry identity | boundedstore stage/publish/receipts; core streaming create/update; RPC projection; unit-one full stdio/HTTP checks and atomic visibility tests | Covered; no model or information-contract change. |
| Exact lexical/vector/graph/evidence behavior | persistent projections, conservative vector filters and exact fallback; unit-two parity; unit-four 407 recorded tool calls | Covered under recorded materials and original identities; not a new natural-language success rate. |
| Updates, publication, invalidation and retirement | organization CAS, dependency checks, revision-specific reclaim; maintenance regression tests | Existing cross-path tests cover stale/late results and publication/reclaim races. |
| Authorization, forgetting, backup and handoff | selected control authority, final delivery check, durable forget barrier, snapshot deletion ledger, service handoff | Database paths covered. Temporary data lifecycle requires the additional check below. |
| Bounded startup, transport and maintenance | fixed connections/cache, admitted workspaces, streamed IO, persistent queues, WAL thresholds | Resource measurements keep their source identities. 210.52 MiB / 547 ms / 312 ms refer to frozen small workload; not a guarantee for arbitrary GB-size corpus. |
| Migration and continued use | shared legacy lock, retired marker, activation decision, format-3 upgrade, current unit-four review fixes | Unit-four tests cover durable boundaries and continued control/retrieval. No user library has been migrated. |

All four main evidence ZIP hashes and CRCs verified; see archive-integrity.json. Current source can be reconstructed from the fixed Git commit. Original 11/14 and 24/24 evaluations are tied to 4e7a236f; later deterministic parity is separately identified.

## Additional cross-unit concern to verify after independent review

An interrupted streaming request can leave temporary files containing original text. `resourcebudget.TempFile`/`File.spill` create named files, and only `File.Close` removes them. Formal assembly merely creates `<data>/scratch` with MkdirAll, without cleanup of files left by an earlier process. `StreamingAssets.CleanForgotten` only drains database maintenance. There is no scratch-directory cleanup in the formal assembly or database forgetting path found by source search.

This suggests a reachable violation of design sections 4.3 and 6: after a process crash, a user can reopen the service and complete forgetting while a controlled temporary copy survives. Requires a minimal isolated startup/forget test, not a benchmark or new AI work. No repair has been made while B is reviewing. Any accepted fix must preserve live requests, durable operation receipts and source files; it must not delete arbitrary directory contents or introduce whole-corpus startup scans.
