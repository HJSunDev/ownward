//go:build windows

package main

import (
	"os/exec"
	"syscall"
)

func configureSharedServiceProcess(command *exec.Cmd) {
	command.SysProcAttr = &syscall.SysProcAttr{CreationFlags: syscall.CREATE_NEW_PROCESS_GROUP | 0x00000008}
}
