package derived

import (
	"crypto/sha256"
	"encoding/base64"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"errors"
	"strings"
	"unicode"
	"unicode/utf8"

	"github.com/HJSunDev/ownward/internal/domain"
)

const (
	EvidenceUnitSchema       = "ownward.derived-evidence-unit/v1"
	DefaultEvidenceUnitRunes = 384
	minimumEvidenceUnitRunes = DefaultEvidenceUnitRunes / 2
	evidenceIDPrefix         = "e1-"
	compactEvidenceIDPrefix  = "e2-"
)

// EvidenceUnit is an ephemeral, rebuildable source-range identity. It is
// generated only for already-retrieved assets and is never persisted.
type EvidenceUnit struct {
	Schema         string `json:"schema"`
	ID             string `json:"id"`
	SourceID       string `json:"source_id"`
	SourceRevision uint64 `json:"source_revision"`
	StartRune      int    `json:"start_rune"`
	EndRune        int    `json:"end_rune"`
	StartByte      int    `json:"-"`
	EndByte        int    `json:"-"`
	Content        string `json:"-"`
}

type evidenceIdentity struct {
	SourceID       string `json:"s"`
	SourceRevision uint64 `json:"r"`
	StartRune      int    `json:"b"`
	EndRune        int    `json:"e"`
	StartByte      int    `json:"i"`
	EndByte        int    `json:"j"`
	ContentSHA256  string `json:"h"`
}

func (u EvidenceUnit) Reference() domain.EvidenceReference {
	return domain.EvidenceReference{
		Schema: domain.EvidenceSchema, ID: u.ID, SourceID: u.SourceID, SourceRevision: u.SourceRevision,
		StartRune: u.StartRune, EndRune: u.EndRune, ContentRunes: u.EndRune - u.StartRune,
	}
}

// EvidenceRanges deterministically partitions a long asset at natural text
// boundaries without hashing every range. Call MaterializeEvidenceUnit only
// for query-selected ranges; neither representation is persisted.
func EvidenceRanges(value domain.Information) []EvidenceUnit {
	runeCount := utf8.RuneCountInString(value.Content)
	if runeCount <= DefaultEvidenceUnitRunes {
		return nil
	}
	units := make([]EvidenceUnit, 0, runeCount/DefaultEvidenceUnitRunes+1)
	for startRune, startByte := 0, 0; startByte < len(value.Content); {
		endRune, endByte := nextEvidenceBoundary(value.Content, startRune, startByte)
		unit := EvidenceUnit{
			Schema: EvidenceUnitSchema, SourceID: value.ID, SourceRevision: value.Revision,
			StartRune: startRune, EndRune: endRune, StartByte: startByte, EndByte: endByte,
			Content: value.Content[startByte:endByte],
		}
		units = append(units, unit)
		startRune, startByte = endRune, endByte
	}
	return units
}

func BuildEvidenceUnits(value domain.Information) []EvidenceUnit {
	units := EvidenceRanges(value)
	for index := range units {
		materialized, err := MaterializeEvidenceUnit(value, units[index])
		if err != nil {
			return nil
		}
		units[index] = materialized
	}
	return units
}

func EvidenceUnitText(value domain.Information, unit EvidenceUnit) (string, error) {
	if unit.Schema != EvidenceUnitSchema || unit.SourceID != value.ID || unit.SourceRevision != value.Revision {
		return "", errors.New("证据单元与当前来源资产不一致")
	}
	if unit.StartRune < 0 || unit.EndRune <= unit.StartRune || unit.StartByte < 0 || unit.EndByte <= unit.StartByte || unit.EndByte > len(value.Content) {
		return "", errors.New("证据单元来源区间无效")
	}
	content := value.Content[unit.StartByte:unit.EndByte]
	if !utf8.ValidString(content) || utf8.RuneCountInString(content) != unit.EndRune-unit.StartRune {
		return "", errors.New("证据单元来源区间无效")
	}
	if unit.Content != "" {
		if unit.Content != content {
			return "", errors.New("证据单元来源内容无效")
		}
	} else if utf8.RuneCountInString(value.Content[:unit.StartByte]) != unit.StartRune {
		return "", errors.New("证据单元来源区间无效")
	}
	return content, nil
}

func MaterializeEvidenceUnit(value domain.Information, unit EvidenceUnit) (EvidenceUnit, error) {
	content, err := EvidenceUnitText(value, unit)
	if err != nil {
		return EvidenceUnit{}, err
	}
	unit.ID = evidenceUnitID(unit, content)
	return unit, nil
}

func nextEvidenceBoundary(content string, startRune, startByte int) (int, int) {
	minimum := startRune + minimumEvidenceUnitRunes
	maximum := startRune + DefaultEvidenceUnitRunes
	lastNaturalRune, lastNaturalByte := 0, 0
	currentRune := startRune
	for relativeByte, current := range content[startByte:] {
		currentRune++
		nextByte := startByte + relativeByte + utf8.RuneLen(current)
		if currentRune > minimum && naturalBoundary(current) {
			lastNaturalRune, lastNaturalByte = currentRune, nextByte
		}
		if currentRune == maximum {
			if lastNaturalRune > 0 {
				return lastNaturalRune, lastNaturalByte
			}
			return currentRune, nextByte
		}
	}
	return currentRune, len(content)
}

func naturalBoundary(value rune) bool {
	switch value {
	case '\n', '\r', '。', '！', '？', '；', '.', '!', '?', ';':
		return true
	default:
		return unicode.IsSpace(value)
	}
}

func evidenceUnitID(unit EvidenceUnit, content string) string {
	// EvidenceUnitText has already proved that content is valid UTF-8. Hash its
	// authoritative bytes directly; converting a long passage to []rune and
	// immediately back to the same bytes only adds allocation and query latency.
	digest := sha256.Sum256([]byte(content))
	identity := evidenceIdentity{
		SourceID: unit.SourceID, SourceRevision: unit.SourceRevision,
		StartRune: unit.StartRune, EndRune: unit.EndRune, StartByte: unit.StartByte, EndByte: unit.EndByte,
		ContentSHA256: hex.EncodeToString(digest[:]),
	}
	return encodeEvidenceIdentity(identity, strings.HasPrefix(unit.ID, evidenceIDPrefix))
}

// StreamEvidenceReference 接受流式原文读取已经验证的区间及摘要，保持既有证据身份格式。
func StreamEvidenceReference(id string, revision uint64, start, end, startByte, endByte int, digest string) (domain.EvidenceReference, error) {
	ref := domain.EvidenceReference{Schema: domain.EvidenceSchema, SourceID: id, SourceRevision: revision, StartRune: start, EndRune: end, ContentRunes: end - start}
	decoded, err := hex.DecodeString(digest)
	if err != nil || len(decoded) != sha256.Size || startByte < 0 || endByte <= startByte {
		return ref, errors.New("证据区间或摘要无效")
	}
	ref.ID = encodeEvidenceIdentity(evidenceIdentity{SourceID: id, SourceRevision: revision, StartRune: start, EndRune: end, StartByte: startByte, EndByte: endByte, ContentSHA256: digest}, false)
	return ref, ref.Validate()
}

func encodeEvidenceIdentity(identity evidenceIdentity, legacy bool) string {
	if legacy {
		payload, _ := json.Marshal(identity)
		return evidenceIDPrefix + base64.RawURLEncoding.EncodeToString(payload)
	}
	payload := binary.AppendUvarint(nil, uint64(len(identity.SourceID)))
	payload = append(payload, []byte(identity.SourceID)...)
	for _, value := range []uint64{identity.SourceRevision, uint64(identity.StartRune), uint64(identity.EndRune), uint64(identity.StartByte), uint64(identity.EndByte)} {
		payload = binary.AppendUvarint(payload, value)
	}
	digest, _ := hex.DecodeString(identity.ContentSHA256)
	payload = append(payload, digest...)
	return compactEvidenceIDPrefix + base64.RawURLEncoding.EncodeToString(payload)
}

func decodeCompactEvidence(payload []byte) (evidenceIdentity, error) {
	invalid := errors.New("证据单元身份无效")
	length, n := binary.Uvarint(payload)
	if n <= 0 || length > uint64(len(payload)-n) {
		return evidenceIdentity{}, invalid
	}
	identity := evidenceIdentity{SourceID: string(payload[n : n+int(length)])}
	payload = payload[n+int(length):]
	values := make([]uint64, 5)
	for index := range values {
		value, n := binary.Uvarint(payload)
		if n <= 0 {
			return evidenceIdentity{}, invalid
		}
		values[index], payload = value, payload[n:]
	}
	if len(payload) != sha256.Size {
		return evidenceIdentity{}, invalid
	}
	identity.SourceRevision = values[0]
	identity.StartRune, identity.EndRune = int(values[1]), int(values[2])
	identity.StartByte, identity.EndByte = int(values[3]), int(values[4])
	identity.ContentSHA256 = hex.EncodeToString(payload)
	return identity, nil
}

// ParseEvidenceUnitID restores a source range without a persisted lookup
// table. ResolveEvidence still validates it against the current source bytes.
func ParseEvidenceUnitID(id string) (EvidenceUnit, error) {
	legacy := strings.HasPrefix(id, evidenceIDPrefix)
	if (!legacy && !strings.HasPrefix(id, compactEvidenceIDPrefix)) || len(id) > 4096 {
		return EvidenceUnit{}, errors.New("证据单元身份无效")
	}
	payload, err := base64.RawURLEncoding.DecodeString(id[3:])
	if err != nil {
		return EvidenceUnit{}, errors.New("证据单元身份无效")
	}
	var identity evidenceIdentity
	if legacy {
		err = json.Unmarshal(payload, &identity)
	} else {
		identity, err = decodeCompactEvidence(payload)
	}
	if err != nil || strings.TrimSpace(identity.SourceID) == "" || !utf8.ValidString(identity.SourceID) || identity.SourceRevision == 0 ||
		identity.StartRune < 0 || identity.EndRune <= identity.StartRune || identity.StartByte < 0 || identity.EndByte <= identity.StartByte || len(identity.ContentSHA256) != sha256.Size*2 {
		return EvidenceUnit{}, errors.New("证据单元身份无效")
	}
	if encodeEvidenceIdentity(identity, legacy) != id {
		return EvidenceUnit{}, errors.New("证据单元身份非规范")
	}
	return EvidenceUnit{
		Schema: EvidenceUnitSchema, ID: id, SourceID: identity.SourceID, SourceRevision: identity.SourceRevision,
		StartRune: identity.StartRune, EndRune: identity.EndRune, StartByte: identity.StartByte, EndByte: identity.EndByte,
	}, nil
}

func ResolveEvidence(value domain.Information, unit EvidenceUnit) (domain.Evidence, error) {
	content, err := EvidenceUnitText(value, unit)
	if err != nil {
		return domain.Evidence{}, err
	}
	if evidenceUnitID(unit, content) != unit.ID {
		return domain.Evidence{}, errors.New("证据单元身份与来源内容不一致")
	}
	evidence := domain.Evidence{
		Schema: domain.EvidenceSchema, ID: unit.ID, SourceID: value.ID, SourceRevision: value.Revision,
		StartRune: unit.StartRune, EndRune: unit.EndRune, Content: content,
	}
	return evidence, evidence.Validate()
}
