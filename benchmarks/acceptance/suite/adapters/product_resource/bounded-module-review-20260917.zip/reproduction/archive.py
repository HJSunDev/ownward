from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / '.tmp/bounded-module-review'
DEST = ROOT / 'benchmarks/acceptance/suite/adapters/product_resource'
STEM = 'bounded-module-review-20260917'

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def archive(round_name, conclusion):
    review = WORK / round_name / 'b/review.json'
    if not review.is_file():
        raise SystemExit('Independent complete review is required before archival.')
    identity = read(WORK / round_name / 'source-identity.json')
    permitted_closeout = {'docs/tasks/bounded-storage-implementation.md',
                          'docs/workbench/ingestion-latency-collaboration.md'}
    unexpected = [name for name, digest in identity['files'].items()
                  if sha(ROOT / name) != digest and name not in permitted_closeout]
    if unexpected:
        raise SystemExit('Reviewed implementation changed: ' + ', '.join(unexpected))
    # Caller checks the complete independent conclusion; never infer approval
    # from a partial report or the absence of a file.
    paths = {}
    for name in identity['files']:
        p = ROOT / name
        if p.is_file() and not name.endswith('.zip'):
            paths['repository/' + name] = p
    for r in ['r1', 'r2', 'r3']:
        base = WORK / r
        for name in ['source-identity.json', 'a/coverage.md', 'a/archive-integrity.json',
                     'a/verification.json', 'a/fix-summary.json', 'a/go-test.jsonl',
                     'a/go-vet.txt', 'a/original-probe.jsonl', 'a/precopy-boundaries.jsonl',
                     'b/review.md', 'b/review.json',
                     'b/initial-identity.json', 'b/final-identity.json',
                     'b/test-summary.json', 'b/probe-results.jsonl',
                     'b/supplemental-probe-results.jsonl', 'b/integration-results.jsonl',
                     'b/lifecycle_probe_test.go', 'b/recheck_test.go', 'b/probe-plan.md',
                     'b/transport-probe-results.jsonl', 'b/regression-results.jsonl',
                     'b/review-tests.jsonl', 'b/original-r2-probe.go',
                     'b/original-probe-identity.json']:
            p = base / name
            if p.is_file():
                paths['review/' + r + '/' + name] = p
    paths['reproduction/archive.py'] = Path(__file__)
    archive_path = DEST / (STEM + '.zip')
    with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, p in sorted(paths.items()):
            z.writestr(name, p.read_bytes())
    with zipfile.ZipFile(archive_path) as z:
        if z.testzip() is not None:
            raise SystemExit('Archive integrity check failed.')
    evidence = {
        'schema': 'ownward.bounded-storage-module-review/v1',
        'date': '2026-09-17', 'status': 'module_review_closed',
        'base_commit': identity['base_commit'],
        'composition_identity': identity['composition'],
        'scope': 'Whole-module integration review and confirmed cross-unit lifecycle repairs.',
        'conclusion': conclusion,
        'verification': {
            'r2_full_repository': read(WORK / 'r2/a/verification.json'),
            'r3_affected_paths': read(WORK / 'r3/a/verification.json'),
            'boundary': 'The final R3 production delta is RPC copy ownership only; R2 full-suite results retain their own version. R3 affected packages and new boundary tests are independently listed.'
        },
        'independent_review': read(review),
        'inherited_evidence': {
            'path': 'bounded-unit-four-20260917.json',
            'sha256': sha(DEST / 'bounded-unit-four-20260917.json'),
            'boundary': 'Original identified memory, performance and AI-quality observations retain their own versions and conditions; this review adds no AI score or new full resource measurement.'
        },
        'source_hashes': {name: sha(ROOT / name) for name in identity['files'] if (ROOT / name).is_file()},
        'reviewed_source_hashes': identity['files'],
        'reproduction_archive': archive_path.name,
        'reproduction_archive_sha256': sha(archive_path),
        'reproduction': 'Use base_commit, then overlay repository/ from the archive. Review files identify the measured revisions. Go tests require no external AI. Environment-specific measurements are referenced separately.'
    }
    (DEST / (STEM + '.json')).write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'archive': archive_path.name, 'bytes': archive_path.stat().st_size, 'sha256': sha(archive_path), 'entries': len(paths)}))

if __name__ == '__main__':
    import sys
    archive(sys.argv[1], sys.argv[2])
