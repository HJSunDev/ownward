import json, struct, zlib, hashlib
from pathlib import Path
r=Path(__file__).resolve().parent
src=r.parent/'startup-capacity-20260916/history-4734/state/organization.binlog'
query=r.parent/'evidence-answer-collab-a-20260913/passage-embedding-probe/vectors.json'
latest={}
with src.open('rb') as f:
    while h:=f.read(16):
        magic,mn,vn,crc=struct.unpack('<4sIII',h);body=f.read(mn+vn)
        assert magic==b'OWD3' and zlib.crc32(body)==crc and f.read(4)==b'DONE'
        m=json.loads(body[:mn])
        if vn==2048: latest[m['asset_id']]=body[mn:]
with (r/'vectors.bin').open('wb') as f:
    f.write(struct.pack('<I',len(latest)))
    for k,v in latest.items():
        b=k.encode();f.write(struct.pack('<I',len(b)));f.write(b);f.write(v)
    f.write(struct.pack('<512f',*json.loads(query.read_text(encoding='utf-8'))['query']))
(r/'input-identity.json').write_text(json.dumps({'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'query_sha256':hashlib.sha256(query.read_bytes()).hexdigest(),'vectors':len(latest)},indent=2))
print('reused',len(latest),'vectors; no model calls')
