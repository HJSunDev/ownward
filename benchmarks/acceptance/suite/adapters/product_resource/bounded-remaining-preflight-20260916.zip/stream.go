package main

import (
	"bufio"
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/modelcontextprotocol/go-sdk/mcp"
)

// Isolated transport mechanism probe, not a product parser or authorization layer.
// Every store belongs to one adapter endpoint; only locally generated refs expand.
type spoolStore struct {
	dir           string
	mu            sync.Mutex
	seq           int
	refs          map[string]string
	bytes         int64
	maxProjection int
}

func newStore(dir string) *spoolStore {
	must(os.MkdirAll(dir, 0700))
	return &spoolStore{dir: dir, refs: map[string]string{}}
}
func (s *spoolStore) put(path string) string {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.seq++
	id := fmt.Sprintf("probe-local-%s-%d", filepath.Base(s.dir), s.seq)
	s.refs[id] = path
	st, e := os.Stat(path)
	must(e)
	s.bytes += st.Size()
	return id
}
func (s *spoolStore) path(id string) string { s.mu.Lock(); defer s.mu.Unlock(); return s.refs[id] }
func (s *spoolStore) size(n int) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.maxProjection = max(s.maxProjection, n)
}
func project(r io.Reader, s *spoolStore) ([]byte, error) {
	br := bufio.NewReaderSize(r, 65536)
	var out bytes.Buffer
	for {
		c, e := br.ReadByte()
		if e == io.EOF {
			break
		}
		if e != nil {
			return nil, e
		}
		if c != '"' {
			out.WriteByte(c)
			if out.Len() > 65536 {
				return nil, fmt.Errorf("envelope limit")
			}
			continue
		}
		small := []byte{'"'}
		var f *os.File
		var w *bufio.Writer
		escaped := false
		for {
			c, e = br.ReadByte()
			if e != nil {
				if f != nil {
					f.Close()
				}
				return nil, e
			}
			if f == nil {
				small = append(small, c)
				if len(small) > 8192 {
					f, e = os.CreateTemp(s.dir, "literal-")
					if e != nil {
						return nil, e
					}
					w = bufio.NewWriterSize(f, 65536)
					w.Write(small)
					small = nil
				}
			} else {
				w.WriteByte(c)
			}
			if escaped {
				escaped = false
				continue
			}
			if c == 92 {
				escaped = true
				continue
			}
			if c == '"' {
				break
			}
			if c < 32 {
				return nil, fmt.Errorf("invalid control")
			}
		}
		if f == nil {
			out.Write(small)
		} else {
			must(w.Flush())
			must(f.Close())
			token, _ := json.Marshal(s.put(f.Name()))
			out.Write(token)
		}
	}
	if out.Len() > 65536 || !json.Valid(out.Bytes()) {
		return nil, fmt.Errorf("invalid projected envelope")
	}
	s.size(out.Len())
	return out.Bytes(), nil
}

func textHash(value string, s *spoolStore) (string, int64) {
	if p := s.path(value); p != "" {
		return logicalHash(p)
	}
	h := sha256.Sum256([]byte(value))
	return fmt.Sprintf("%x", h), int64(len(value))
}

// Only small SDK envelopes reach this function. Large JSON string literals are
// copied from disk without unquoting or re-encoding their full contents.
func expand(w io.Writer, b []byte, s *spoolStore) error {
	for i := 0; i < len(b); {
		if b[i] != '"' {
			j := i + 1
			for j < len(b) && b[j] != '"' {
				j++
			}
			if _, e := w.Write(b[i:j]); e != nil {
				return e
			}
			i = j
			continue
		}
		j := i + 1
		escaped := false
		for j < len(b) {
			c := b[j]
			j++
			if escaped {
				escaped = false
				continue
			}
			if c == '\\' {
				escaped = true
				continue
			}
			if c == '"' {
				break
			}
		}
		var value string
		if e := json.Unmarshal(b[i:j], &value); e != nil {
			return e
		}
		path := s.path(value)
		if path == "" {
			if _, e := w.Write(b[i:j]); e != nil {
				return e
			}
		} else {
			f, e := os.Open(path)
			if e != nil {
				return e
			}
			_, e = io.CopyBuffer(w, f, make([]byte, 65536))
			f.Close()
			if e != nil {
				return e
			}
		}
		i = j
	}
	return nil
}
func expanded(b []byte, s *spoolStore) io.ReadCloser {
	r, w := io.Pipe()
	go func() { w.CloseWithError(expand(w, b, s)) }()
	return r
}

type roundTripper struct{ s *spoolStore }

func (t roundTripper) RoundTrip(req *http.Request) (*http.Response, error) {
	r := req.Clone(req.Context())
	if req.Body != nil {
		b, e := io.ReadAll(io.LimitReader(req.Body, 65537))
		req.Body.Close()
		if e != nil {
			return nil, e
		}
		if len(b) > 65536 {
			return nil, fmt.Errorf("SDK received large request")
		}
		r.Body = expanded(b, t.s)
		r.ContentLength = -1
		r.GetBody = nil
	}
	resp, e := http.DefaultTransport.RoundTrip(r)
	if e != nil {
		return nil, e
	}
	if resp.Body != nil && resp.Header.Get("Content-Type") == "application/json" {
		b, e := project(resp.Body, t.s)
		resp.Body.Close()
		if e != nil {
			return nil, e
		}
		resp.Body = io.NopCloser(bytes.NewReader(b))
		resp.ContentLength = int64(len(b))
		resp.Header.Del("Content-Length")
	}
	return resp, nil
}

type expandingWriter struct {
	http.ResponseWriter
	s *spoolStore
	b bytes.Buffer
}

func (w *expandingWriter) WriteHeader(code int) {
	w.Header().Del("Content-Length")
	w.ResponseWriter.WriteHeader(code)
}
func (w *expandingWriter) Write(b []byte) (int, error) {
	if w.b.Len()+len(b) > 65536 {
		return 0, fmt.Errorf("SDK emitted oversized response")
	}
	return w.b.Write(b)
}
func adaptHTTP(next http.Handler, s *spoolStore) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Body != nil && r.Method == "POST" {
			b, e := project(r.Body, s)
			r.Body.Close()
			if e != nil {
				http.Error(w, e.Error(), 400)
				return
			}
			r.Body = io.NopCloser(bytes.NewReader(b))
			r.ContentLength = int64(len(b))
		}
		ew := &expandingWriter{ResponseWriter: w, s: s}
		next.ServeHTTP(ew, r)
		must(expand(w, ew.b.Bytes(), s))
	})
}

type writeCloser struct{ io.Writer }

func (w writeCloser) Close() error { return nil }

type stdoutWriter struct {
	s   *spoolStore
	out *io.PipeWriter
	buf bytes.Buffer
	mu  sync.Mutex
}

func (w *stdoutWriter) Write(b []byte) (int, error) {
	w.mu.Lock()
	defer w.mu.Unlock()
	w.buf.Write(b)
	for {
		data := w.buf.Bytes()
		at := bytes.IndexByte(data, '\n')
		if at < 0 {
			if len(data) > 65536 {
				return 0, fmt.Errorf("SDK output not bounded")
			}
			return len(b), nil
		}
		frame := append([]byte(nil), data[:at]...)
		w.buf.Next(at + 1)
		if e := expand(w.out, frame, w.s); e != nil {
			return 0, e
		}
		if _, e := w.out.Write([]byte{'\n'}); e != nil {
			return 0, e
		}
	}
}
func (w *stdoutWriter) Close() error { return w.out.Close() }
func schema() map[string]any {
	return map[string]any{"type": "object", "properties": map[string]any{"content": map[string]any{"type": "string"}, "label": map[string]any{"type": "string"}, "revision": map[string]any{"type": "integer"}}, "required": []string{"content", "label", "revision"}}
}

// Hash decoded source content in bounded chunks, including Unicode surrogate pairs.
func logicalHash(path string) (string, int64) {
	f, e := os.Open(path)
	must(e)
	defer f.Close()
	br := bufio.NewReaderSize(f, 65536)
	c, e := br.ReadByte()
	must(e)
	if c != '"' {
		panic("literal missing quote")
	}
	h := sha256.New()
	var total int64
	part := []byte{'"'}
	flush := func() {
		part = append(part, '"')
		var v string
		must(json.Unmarshal(part, &v))
		h.Write([]byte(v))
		total += int64(len(v))
		part = part[:1]
	}
	for {
		c, e = br.ReadByte()
		must(e)
		if c == '"' {
			break
		}
		part = append(part, c)
		if c == '\\' {
			c, e = br.ReadByte()
			must(e)
			part = append(part, c)
			if c == 'u' {
				var hexs [4]byte
				_, e = io.ReadFull(br, hexs[:])
				must(e)
				part = append(part, hexs[:]...)
				n, e := strconv.ParseUint(string(hexs[:]), 16, 16)
				must(e)
				if n >= 0xd800 && n <= 0xdbff {
					var low [6]byte
					_, e = io.ReadFull(br, low[:])
					must(e)
					part = append(part, low[:]...)
				}
			}
		}
		if len(part) > 32768 && br.Buffered() > 0 {
			next, e := br.Peek(1)
			must(e)
			if next[0] < 0x80 || next[0] >= 0xc0 {
				flush()
			}
		}
	}
	flush()
	return hex.EncodeToString(h.Sum(nil)), total
}
func makeLiteral(path string, target int) (string, int64) {
	f, e := os.Create(path)
	must(e)
	w := bufio.NewWriterSize(f, 65536)
	w.WriteByte('"')
	pattern := []byte(`原文\u4e2d\u6587\ud83d\ude80\n\"\\`)
	for n := 0; n < target; n += len(pattern) {
		_, e = w.Write(pattern)
		must(e)
	}
	w.WriteByte('"')
	must(w.Flush())
	must(f.Close())
	return logicalHash(path)
}
func streamMain() {
	size, e := strconv.Atoi(os.Args[2])
	must(e)
	plain := len(os.Args) > 3 && os.Args[3] == "plain"
	base := "stream-" + strconv.Itoa(size)
	if plain {
		base += "-plain"
	}
	must(os.MkdirAll(base, 0700))
	connector := newStore(filepath.Join(base, "connector"))
	backend := newStore(filepath.Join(base, "backend"))
	receiver := newStore(filepath.Join(base, "receiver"))
	literal := filepath.Join(base, "input-literal.json")
	want, n := makeLiteral(literal, size)
	var toolCalls atomic.Int32
	var inputEqual atomic.Bool
	var fieldsEqual atomic.Bool
	server := mcp.NewServer(&mcp.Implementation{Name: "disk-backed-probe", Version: "1"}, nil)
	server.AddTool(&mcp.Tool{Name: "echo", InputSchema: schema()}, func(ctx context.Context, req *mcp.CallToolRequest) (*mcp.CallToolResult, error) {
		var args struct {
			Content, Label string
			Revision       int
		}
		if e := json.Unmarshal(req.Params.Arguments, &args); e != nil {
			return nil, e
		}
		got, gotN := textHash(args.Content, backend)
		inputEqual.Store(got == want && gotN == n)
		fieldsEqual.Store(args.Label == "证据 A" && args.Revision == 7)
		toolCalls.Add(1)
		return &mcp.CallToolResult{StructuredContent: map[string]any{"content": args.Content, "label": args.Label, "revision": args.Revision}, Content: []mcp.Content{&mcp.TextContent{Text: args.Content}}}, nil
	})
	handler := mcp.NewStreamableHTTPHandler(func(*http.Request) *mcp.Server { return server }, &mcp.StreamableHTTPOptions{JSONResponse: true})
	var serving http.Handler = adaptHTTP(handler, backend)
	if plain {
		serving = handler
	}
	httpServer := httptest.NewServer(serving)
	defer httpServer.Close()
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	var transport http.RoundTripper = roundTripper{connector}
	if plain {
		transport = http.DefaultTransport
	}
	remote, e := mcp.NewClient(&mcp.Implementation{Name: "probe-connector", Version: "1"}, nil).Connect(ctx, &mcp.StreamableClientTransport{Endpoint: httpServer.URL, HTTPClient: &http.Client{Transport: transport}, DisableStandaloneSSE: true}, nil)
	must(e)
	defer remote.Close()
	bridge := mcp.NewServer(&mcp.Implementation{Name: "probe-bridge", Version: "1"}, nil)
	bridge.AddTool(&mcp.Tool{Name: "echo", InputSchema: schema()}, func(ctx context.Context, req *mcp.CallToolRequest) (*mcp.CallToolResult, error) {
		return remote.CallTool(ctx, &mcp.CallToolParams{Name: req.Params.Name, Arguments: req.Params.Arguments})
	})
	sdkIn, sdkWrite := io.Pipe()
	externalOut, outWrite := io.Pipe()
	defer externalOut.Close()
	defer sdkWrite.Close()
	var output io.WriteCloser = &stdoutWriter{s: connector, out: outWrite}
	if plain {
		output = outWrite
	}
	session, e := bridge.Connect(ctx, &mcp.IOTransport{Reader: sdkIn, Writer: output}, nil)
	must(e)
	defer session.Close()
	extReader := bufio.NewReaderSize(externalOut, 65536)
	send := func(frame string) { _, e = io.WriteString(sdkWrite, frame+"\n"); must(e) }
	send(`{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-06-18","capabilities":{},"clientInfo":{"name":"probe-host","version":"1"}}}`)
	line, e := extReader.ReadBytes('\n')
	must(e)
	if !json.Valid(line) {
		panic("initialize response")
	}
	send(`{"jsonrpc":"2.0","method":"notifications/initialized"}`)
	runtime.GC()
	var baseline runtime.MemStats
	runtime.ReadMemStats(&baseline)
	var peak atomic.Uint64
	peak.Store(baseline.HeapAlloc)
	stop := make(chan struct{})
	go func() {
		t := time.NewTicker(time.Millisecond)
		defer t.Stop()
		for {
			select {
			case <-stop:
				return
			case <-t.C:
				var m runtime.MemStats
				runtime.ReadMemStats(&m)
				for old := peak.Load(); m.HeapAlloc > old; old = peak.Load() {
					if peak.CompareAndSwap(old, m.HeapAlloc) {
						break
					}
				}
			}
		}
	}()
	started := time.Now()
	f, e := os.Open(literal)
	must(e)
	input := io.MultiReader(strings.NewReader(`{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"echo","arguments":{"label":"证据 A","revision":7,"content":`), f, strings.NewReader("}}}"))
	if plain {
		_, e = io.CopyBuffer(sdkWrite, input, make([]byte, 65536))
		must(e)
		must(f.Close())
		_, e = io.WriteString(sdkWrite, "\n")
		must(e)
	} else {
		projected, e := project(input, connector)
		must(e)
		must(f.Close())
		send(string(projected))
	}
	// Read exactly one JSON-RPC line as a stream; neither host nor adapter holds
	// the complete response. SDK sees only the bounded projection.
	frameReader, frameWrite := io.Pipe()
	go func() {
		bw := bufio.NewWriterSize(frameWrite, 65536)
		for {
			c, err := extReader.ReadByte()
			if err != nil {
				frameWrite.CloseWithError(err)
				return
			}
			if c == '\n' {
				must(bw.Flush())
				frameWrite.Close()
				return
			}
			if err = bw.WriteByte(c); err != nil {
				frameWrite.CloseWithError(err)
				return
			}
		}
	}()
	result, e := project(frameReader, receiver)
	must(e)
	var response struct {
		Error  any
		Result struct {
			Content           []struct{ Text string }
			StructuredContent struct {
				Content, Label string
				Revision       int
			}
		}
	}
	must(json.Unmarshal(result, &response))
	if response.Error != nil {
		panic(fmt.Sprint(response.Error))
	}
	sc := response.Result.StructuredContent
	outputEqual := len(response.Result.Content) == 1 && sc.Label == "证据 A" && sc.Revision == 7
	for _, id := range []string{sc.Content, response.Result.Content[0].Text} {
		got, gotN := textHash(id, receiver)
		outputEqual = outputEqual && got == want && gotN == n
	}
	elapsed := time.Since(started).Seconds()
	close(stop)
	out := map[string]any{"plain_sdk": plain, "input_json_literal_target_bytes": size, "decoded_content_bytes": n, "stdio_http_request_response": true, "input_equal": inputEqual.Load(), "output_structured_and_text_equal": outputEqual, "fields_equal": fieldsEqual.Load(), "tool_calls": toolCalls.Load(), "elapsed_seconds": elapsed, "heap_baseline_bytes": baseline.HeapAlloc, "heap_peak_bytes": peak.Load(), "max_sdk_envelope_bytes": max(connector.maxProjection, backend.maxProjection), "spooled_literal_bytes": connector.bytes + backend.bytes + receiver.bytes, "scope": "Actual pinned MCP SDK IOTransport + StreamableClientTransport + StreamableHTTPHandler; isolated adapters; single tool/string payload; product permissions and full parser validation are implementation work"}
	save(base+"-result.json", out)
	fmt.Printf("stream size=%d input=%v output=%v seconds=%.3f\n", size, inputEqual.Load(), outputEqual, elapsed)
}
