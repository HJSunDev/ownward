package main

import (
	"database/sql"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"io"
	"io/fs"
	"math"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"time"

	"github.com/HJSunDev/ownward/internal/derived"
	"github.com/viterin/vek/vek32"
	_ "modernc.org/sqlite"
	"modernc.org/sqlite/vfs"
)

func must(e error) {
	if e != nil {
		panic(e)
	}
}
func save(name string, v any) {
	f, e := os.Create(name)
	must(e)
	defer f.Close()
	en := json.NewEncoder(f)
	en.SetIndent("", "  ")
	must(en.Encode(v))
}
func norm(v []float32) float64 {
	s := 0.
	for _, x := range v {
		s += float64(x) * float64(x)
	}
	return math.Sqrt(s)
}
func normalized(v []float32) []float32 {
	a := append([]float32(nil), v...)
	vek32.MulNumber_Inplace(a, float32(1/norm(a)))
	return a
}
func decode(b []byte) []float32 {
	v := make([]float32, len(b)/4)
	for i := range v {
		v[i] = math.Float32frombits(binary.LittleEndian.Uint32(b[4*i:]))
	}
	return v
}
func encoded(v []float32) []byte {
	b := make([]byte, 4*len(v))
	for i, x := range v {
		binary.LittleEndian.PutUint32(b[4*i:], math.Float32bits(x))
	}
	return b
}

type block struct {
	ID, Start, N      int
	IDs               []string
	Lo, Width, Center []float64
	Radius, MaxNorm   float64
}
type hit struct {
	ID    string
	Score float64
}

func better(a, b hit) bool {
	if a.Score == b.Score {
		return a.ID < b.ID
	}
	return a.Score > b.Score
}
func add(best []hit, h hit) []hit {
	if h.Score <= 0 {
		return best
	}
	if len(best) == 10 && !better(h, best[9]) {
		return best
	}
	best = append(best, h)
	sort.Slice(best, func(i, j int) bool { return better(best[i], best[j]) })
	if len(best) > 10 {
		best = best[:10]
	}
	return best
}
func cutoff(b []hit) float64 {
	if len(b) < 10 {
		return 0
	}
	return b[9].Score
}

type diskStats struct {
	Bytes, Reads int64
	Pages        map[int64]bool
}
type diskFS struct {
	Path string
	S    *diskStats
}
type diskFile struct {
	*os.File
	S   *diskStats
	pos int64
}

func (f diskFS) Open(name string) (fs.File, error) {
	p, e := os.Open(f.Path)
	if e != nil {
		return nil, e
	}
	return &diskFile{File: p, S: f.S}, nil
}
func (f *diskFile) Seek(n int64, w int) (int64, error) {
	p, e := f.File.Seek(n, w)
	f.pos = p
	return p, e
}
func (f *diskFile) Read(b []byte) (int, error) {
	n, e := f.File.Read(b)
	f.S.Reads++
	f.S.Bytes += int64(n)
	if n > 0 {
		for p := f.pos / 16384; p <= (f.pos+int64(n)-1)/16384; p++ {
			f.S.Pages[p] = true
		}
	}
	f.pos += int64(n)
	return n, e
}
func openRead(path string) (*sql.DB, *diskStats, func()) {
	s := &diskStats{Pages: map[int64]bool{}}
	name, v, e := vfs.New(diskFS{path, s})
	must(e)
	db, e := sql.Open("sqlite", "file:sample?vfs="+name+"&mode=ro&immutable=1")
	must(e)
	db.SetMaxOpenConns(1)
	for _, q := range []string{"PRAGMA cache_size=-1024", "PRAGMA mmap_size=0", "PRAGMA temp_store=FILE"} {
		_, e = db.Exec(q)
		must(e)
	}
	s.Bytes = 0
	s.Reads = 0
	s.Pages = map[int64]bool{}
	return db, s, func() { must(db.Close()); must(v.Close()) }
}
func getBlob(db *sql.DB, table string, key int) []byte {
	var b []byte
	must(db.QueryRow("SELECT data FROM "+table+" WHERE id=?", key).Scan(&b))
	return b
}
func buildDB(path string, ids []string, vs [][]float32) {
	db, e := sql.Open("sqlite", path)
	must(e)
	defer db.Close()
	db.SetMaxOpenConns(1)
	for _, q := range []string{"PRAGMA page_size=16384", "PRAGMA journal_mode=WAL", "PRAGMA synchronous=FULL", "PRAGMA cache_size=-2048", "CREATE TABLE blocks(id INTEGER PRIMARY KEY,data BLOB)", "CREATE TABLE coarse(id INTEGER PRIMARY KEY,data BLOB)", "CREATE TABLE fine(id INTEGER PRIMARY KEY,data BLOB)", "CREATE TABLE raw(id INTEGER PRIMARY KEY,data BLOB)"} {
		_, e = db.Exec(q)
		must(e)
	}
	tx, e := db.Begin()
	must(e)
	for start := 0; start < len(vs); start += 1024 {
		end := min(start+1024, len(vs))
		b := block{ID: start / 1024, Start: start, N: end - start, IDs: ids[start:end], Lo: make([]float64, 512), Width: make([]float64, 512), Center: make([]float64, 512)}
		for d := 0; d < 512; d++ {
			lo, hi := math.Inf(1), math.Inf(-1)
			for _, v := range vs[start:end] {
				x := float64(v[d])
				lo = math.Min(lo, x)
				hi = math.Max(hi, x)
				b.Center[d] += x / float64(b.N)
			}
			b.Lo[d] = lo
			b.Width[d] = (hi - lo) / 256
		}
		co, fi := make([][]byte, b.N), make([][]byte, b.N)
		for j, v := range vs[start:end] {
			co[j] = make([]byte, 264)
			fi[j] = make([]byte, 264)
			r4, r8, rr := 0., 0., 0.
			for d := 0; d < 512; d++ {
				x := float64(v[d])
				c := 0
				if b.Width[d] > 0 {
					c = min(255, max(0, int(math.Floor((x-b.Lo[d])/b.Width[d]))))
				}
				shift := uint(4 * (d % 2))
				co[j][d/2] |= byte(c>>4) << shift
				fi[j][d/2] |= byte(c&15) << shift
				c4 := b.Lo[d] + float64((c>>4)*16+8)*b.Width[d]
				c8 := b.Lo[d] + (float64(c)+.5)*b.Width[d]
				r4 += (x - c4) * (x - c4)
				r8 += (x - c8) * (x - c8)
				rr += (x - b.Center[d]) * (x - b.Center[d])
			}
			binary.LittleEndian.PutUint64(co[j][256:], math.Float64bits(math.Nextafter(math.Sqrt(r4)+1e-12, math.Inf(1))))
			binary.LittleEndian.PutUint64(fi[j][256:], math.Float64bits(math.Nextafter(math.Sqrt(r8)+1e-12, math.Inf(1))))
			b.Radius = math.Max(b.Radius, math.Sqrt(rr)+1e-12)
			b.MaxNorm = math.Max(b.MaxNorm, norm(v))
		}
		meta, e := json.Marshal(b)
		must(e)
		_, e = tx.Exec("INSERT INTO blocks VALUES(?,?)", b.ID, meta)
		must(e)
		for _, t := range []struct {
			name string
			rows [][]byte
		}{{"coarse", co}, {"fine", fi}} {
			for j := 0; j < b.N; j += 56 {
				data := make([]byte, 0, 56*264)
				for _, row := range t.rows[j:min(j+56, b.N)] {
					data = append(data, row...)
				}
				_, e = tx.Exec("INSERT INTO "+t.name+" VALUES(?,?)", b.ID*32+j/56, data)
				must(e)
			}
		}
		for j := 0; j < b.N; j += 7 {
			data := make([]byte, 0, 7*2048)
			for _, v := range vs[start+j : min(start+j+7, end)] {
				data = append(data, encoded(v)...)
			}
			_, e = tx.Exec("INSERT INTO raw VALUES(?,?)", b.ID*256+j/7, data)
			must(e)
		}
	}
	must(tx.Commit())
	_, e = db.Exec("PRAGMA wal_checkpoint(TRUNCATE)")
	must(e)
	_, e = db.Exec("PRAGMA journal_mode=DELETE")
	must(e)
}
func loadBlocks(db *sql.DB) []block {
	rows, e := db.Query("SELECT data FROM blocks ORDER BY id")
	must(e)
	defer rows.Close()
	var out []block
	for rows.Next() {
		var data []byte
		must(rows.Scan(&data))
		var b block
		must(json.Unmarshal(data, &b))
		out = append(out, b)
	}
	must(rows.Err())
	return out
}
func search(db *sql.DB, q []float32, exclude string, filter bool) ([]hit, int) {
	blocks := loadBlocks(db)
	rawStmt, e := db.Prepare("SELECT data FROM raw WHERE id=?")
	must(e)
	defer rawStmt.Close()
	best := []hit{}
	exact := 0
	qn := norm(q)
	dot := func(v []float64) float64 {
		s := 0.
		for i, x := range v {
			s += float64(q[i]) * x
		}
		return s
	}
	sort.Slice(blocks, func(i, j int) bool { return dot(blocks[i].Center) > dot(blocks[j].Center) })
	for _, b := range blocks {
		eps := (1024*math.Pow(2, -24))/(1-1024*math.Pow(2, -24))*qn*b.MaxNorm + 1e-10
		if filter && dot(b.Center)+qn*b.Radius+eps < cutoff(best) {
			continue
		}
		rawPage := -1
		var raw []float32
		eval := func(j int) {
			if b.IDs[j] == exclude {
				return
			}
			p := j / 7
			if p != rawPage {
				var payload []byte
				must(rawStmt.QueryRow(b.ID*256 + p).Scan(&payload))
				raw = decode(payload)
				rawPage = p
			}
			score := float64(vek32.Dot(q, raw[(j%7)*512:(j%7+1)*512]))
			best = add(best, hit{b.IDs[j], score})
			exact++
		}
		if !filter {
			rows, e := db.Query("SELECT data FROM raw WHERE id>=? AND id<? ORDER BY id", b.ID*256, (b.ID+1)*256)
			must(e)
			j := 0
			for rows.Next() {
				var data []byte
				must(rows.Scan(&data))
				v := decode(data)
				for off := 0; off < len(v); off += 512 {
					if b.IDs[j] != exclude {
						best = add(best, hit{b.IDs[j], float64(vek32.Dot(q, v[off:off+512]))})
						exact++
					}
					j++
				}
			}
			must(rows.Err())
			must(rows.Close())
			continue
		}
		// Fixed 1 MiB query tables; no full-corpus lookup table.
		ctab, ftab := make([]float64, 256*256), make([]float64, 256*256)
		for d := 0; d < 256; d++ {
			var c, f [2][16]float64
			for half := 0; half < 2; half++ {
				dim := 2*d + half
				for n := 0; n < 16; n++ {
					c[half][n] = float64(q[dim]) * (b.Lo[dim] + float64(n*16+8)*b.Width[dim])
					f[half][n] = float64(q[dim]) * (float64(n) - 7.5) * b.Width[dim]
				}
			}
			for code := 0; code < 256; code++ {
				ctab[d*256+code] = c[0][code&15] + c[1][code>>4]
				ftab[d*256+code] = f[0][code&15] + f[1][code>>4]
			}
		}
		codes := make([]byte, 0, b.N*264)
		rows, e := db.Query("SELECT data FROM coarse WHERE id>=? AND id<? ORDER BY id", b.ID*32, (b.ID+1)*32)
		must(e)
		for rows.Next() {
			var data []byte
			must(rows.Scan(&data))
			codes = append(codes, data...)
		}
		must(rows.Err())
		must(rows.Close())
		type cand struct {
			j             int
			approx, upper float64
		}
		cs := make([]cand, 0, b.N)
		for j := 0; j < b.N; j++ {
			row := codes[j*264 : (j+1)*264]
			a := 0.
			for d, c := range row[:256] {
				a += ctab[d*256+int(c)]
			}
			r := math.Float64frombits(binary.LittleEndian.Uint64(row[256:]))
			cs = append(cs, cand{j, a, a + qn*r + eps})
		}
		evaluated := make([]bool, b.N)
		if len(best) < 10 {
			sort.Slice(cs, func(i, j int) bool { return cs[i].approx > cs[j].approx })
			for _, c := range cs[:min(11, len(cs))] {
				eval(c.j)
				evaluated[c.j] = true
			}
		}
		sort.Slice(cs, func(i, j int) bool { return cs[i].upper > cs[j].upper })
		finePages := make([][]byte, (b.N+55)/56)
		for _, c := range cs {
			if c.upper < cutoff(best) {
				break
			}
			if evaluated[c.j] || b.IDs[c.j] == exclude {
				continue
			}
			p := c.j / 56
			if finePages[p] == nil {
				finePages[p] = getBlob(db, "fine", b.ID*32+p)
			}
			fine := finePages[p]
			row := fine[(c.j%56)*264 : (c.j%56+1)*264]
			a := c.approx
			for d, code := range row[:256] {
				a += ftab[d*256+int(code)]
			}
			r := math.Float64frombits(binary.LittleEndian.Uint64(row[256:]))
			if math.Min(c.upper, a+qn*r+eps) >= cutoff(best) {
				eval(c.j)
			}
		}
	}
	return best, exact
}
func vectorMain() {
	f, e := os.Open("vectors.bin")
	must(e)
	defer f.Close()
	read := func(n int) []byte { b := make([]byte, n); _, e := io.ReadFull(f, b); must(e); return b }
	count := int(binary.LittleEndian.Uint32(read(4)))
	ids := make([]string, count)
	vs := make([][]float32, count)
	records := make([]derived.Record, count)
	for i := 0; i < count; i++ {
		n := int(binary.LittleEndian.Uint32(read(4)))
		ids[i] = string(read(n))
		original := decode(read(2048))
		vs[i] = normalized(original)
		records[i] = derived.Record{AssetID: ids[i], Embedding: original}
	}
	query := decode(read(2048))
	queries := [][]float32{query}
	exclude := []string{""}
	for i := 0; i < 12; i++ {
		j := i * (count - 1) / 11
		queries = append(queries, records[j].Embedding)
		exclude = append(exclude, ids[j])
	}
	idx := derived.NewIndex(records)
	expected := make([][]hit, len(queries))
	var memoryMS []float64
	for i, q := range queries {
		start := time.Now()
		for _, h := range idx.Search(q, nil, 11) {
			if h.AssetID != exclude[i] && len(expected[i]) < 10 {
				expected[i] = append(expected[i], hit{h.AssetID, h.Score})
			}
		}
		memoryMS = append(memoryMS, float64(time.Since(start).Microseconds())/1000)
	}
	save("query-cases.json", map[string]any{"queries": queries, "exclude": exclude, "expected": expected})
	path, e := filepath.Abs("vectors.sqlite")
	must(e)
	if _, e = os.Stat(path); os.IsNotExist(e) {
		buildDB(path, ids, vs)
	}
	idx = nil
	records = nil
	vs = nil
	runtime.GC()
	var runs []map[string]any
	all := true
	for i, q := range queries {
		for _, filter := range []bool{false, true} {
			db, s, close := openRead(path)
			start := time.Now()
			got, n := search(db, normalized(q), exclude[i], filter)
			ms := float64(time.Since(start).Microseconds()) / 1000
			equal := len(got) == len(expected[i])
			for j, h := range got {
				if j >= len(expected[i]) || h != expected[i][j] {
					equal = false
				}
			}
			all = all && equal
			runs = append(runs, map[string]any{"query": i, "filter": filter, "equal_formal_index": equal, "query_ms": ms, "exact_vectors": n, "vfs_read_bytes": s.Bytes, "vfs_read_calls": s.Reads, "unique_sqlite_pages": len(s.Pages)})
			close()
		}
	}
	out := map[string]any{"all_equal_formal_index": all, "vectors": count, "queries": len(queries), "page_size": 16384, "reader_cache_bytes": 1048576, "scoring": "formal derived.Index.Search reference, vek32 float32 normalization and SIMD dot; exact score and ID equality", "cache": "fresh SQLite connections; operating system cache not cleared", "query_algorithm_live_buffers_upper_estimate_bytes": 2 << 20, "measurement": "read-only SQLite VFS over real os.File; SQLite page reads, not physical SSD reads; no WAL concurrency", "runs": runs, "formal_memory_index_query_ms": memoryMS}
	save("vector-result.json", out)
	fmt.Printf("vector queries=%d formal_equal=%v\n", len(queries), all)
}

func vectorResourceMain() {
	var cases struct {
		Queries  [][]float32
		Exclude  []string
		Expected [][]hit
	}
	data, e := os.ReadFile("query-cases.json")
	must(e)
	must(json.Unmarshal(data, &cases))
	data = nil
	runtime.GC()
	path, e := filepath.Abs("vectors.sqlite")
	must(e)
	var m runtime.MemStats
	runtime.ReadMemStats(&m)
	baseline := m.HeapAlloc
	peak := baseline
	peakSys := m.Sys
	all := true
	for i, q := range cases.Queries {
		db, _, close := openRead(path)
		got, _ := search(db, normalized(q), cases.Exclude[i], true)
		close()
		runtime.ReadMemStats(&m)
		peak = max(peak, m.HeapAlloc)
		peakSys = max(peakSys, m.Sys)
		if len(got) != len(cases.Expected[i]) {
			all = false
		} else {
			for j, h := range got {
				all = all && h == cases.Expected[i][j]
			}
		}
	}
	save("vector-resource.json", map[string]any{"all_equal": all, "heap_baseline_bytes": baseline, "heap_max_end_query_bytes": peak, "runtime_sys_max_end_query_bytes": peakSys, "scope": "fresh query-only process; corpus not loaded, SQLite cache=1MiB; five-block small-slice metadata only; full-scale directory streaming remains unit2 implementation"})
}
