package main

import "os"

func main() {
	if len(os.Args) > 1 && os.Args[1] == "stream" {
		streamMain()
	} else if len(os.Args) > 1 && os.Args[1] == "vector-resource" {
		vectorResourceMain()
	} else {
		vectorMain()
	}
}
