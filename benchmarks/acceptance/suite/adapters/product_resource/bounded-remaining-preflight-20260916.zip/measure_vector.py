import json, os, subprocess, time
from pathlib import Path
import psutil
r=Path(__file__).resolve().parent
p=subprocess.Popen([str(r/'preflight.exe'),'vector-resource'],cwd=r,env=dict(os.environ,GOMAXPROCS='2'),stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=subprocess.CREATE_NO_WINDOW)
started=time.monotonic();peak=private=0
while p.poll() is None:
    try:
        m=psutil.Process(p.pid).memory_info();peak=max(peak,m.rss,getattr(m,'peak_wset',0));private=max(private,getattr(m,'private',0))
    except psutil.Error: pass
    if time.monotonic()-started>30:
        p.kill();p.wait();raise RuntimeError('query-only probe exceeded limit')
    time.sleep(.005)
stdout,stderr=p.communicate()
assert p.returncode==0,stderr.decode(errors='replace')
d=json.loads((r/'vector-resource.json').read_text());d.update(peak_rss_bytes=peak,peak_private_bytes=private)
(r/'vector-resource.json').write_text(json.dumps(d,indent=2))
print(json.dumps(d))
