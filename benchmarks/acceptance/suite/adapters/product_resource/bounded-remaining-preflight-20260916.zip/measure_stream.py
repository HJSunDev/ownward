import json, os, subprocess, time
from pathlib import Path
import psutil
r=Path(__file__).resolve().parent
out=[]
for size,plain in [(4096,False),(4096,True),(1048576,False),(1048576,True),(16777216,False),(16777216,True)]:
    started=time.monotonic()
    p=subprocess.Popen([str(r/'preflight.exe'),'stream',str(size)]+(['plain'] if plain else []),cwd=r,env=dict(os.environ,GOMAXPROCS='2'),stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=subprocess.CREATE_NO_WINDOW)
    peak_rss=peak_private=0
    while p.poll() is None:
        try:
            m=psutil.Process(p.pid).memory_info()
            peak_rss=max(peak_rss,m.rss,getattr(m,'peak_wset',0));peak_private=max(peak_private,getattr(m,'private',0))
        except psutil.Error: pass
        if time.monotonic()-started>60:
            p.kill();p.wait();raise RuntimeError('probe exceeded one-minute limit')
        time.sleep(.01)
    stdout,stderr=p.communicate()
    if p.returncode: raise RuntimeError(stderr.decode(errors='replace'))
    suffix='-plain' if plain else ''
    d=json.loads((r/f'stream-{size}{suffix}-result.json').read_text())
    d.update(peak_rss_bytes=peak_rss,peak_private_bytes=peak_private,stdout=stdout.decode().strip(),process_seconds=time.monotonic()-started)
    out.append(d)
    print(json.dumps({k:d[k] for k in ['plain_sdk','input_json_literal_target_bytes','elapsed_seconds','heap_peak_bytes','peak_rss_bytes','input_equal','output_structured_and_text_equal']}),flush=True)
(r/'stream-results.json').write_text(json.dumps(out,indent=2))
