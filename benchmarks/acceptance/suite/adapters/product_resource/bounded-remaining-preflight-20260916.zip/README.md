# Remaining bounded-storage feasibility probes

Scope: isolated mechanism evidence, not formal implementation or product acceptance.

Reproduce under the repository's .tmp directory (two levels below repository root):
1. Preserve the local go.mod replace path ../..; use the recorded repository source.
2. python prepare.py reads the already prepared 4,734 vectors and cached query. No model call.
3. go build -mod=readonly -o preflight.exe .
4. Set GOMAXPROCS=2; run preflight.exe, then python measure_vector.py.
5. python measure_stream.py runs bounded and ordinary SDK controls for each input size.

Existing inputs are identified by SHA256 in input-identity.json. They are not duplicated in this archive. The streaming fixture is synthetic and generated locally. Dependencies were already installed; this probe does not alter the root module.

Vector reference calls the repository's actual derived.Index.Search; scoring uses the same float32 normalization and vek32.Dot. SQLite pages are measured with modernc's read-only VFS wrapping a real file, after a WAL checkpoint. Reads include real B-tree/overflow overhead but are not physical SSD cache-miss counts. Each query uses a fresh 1 MiB SQLite page cache; OS cache is warm/not cleared. Query-only resource measurement excludes corpus preparation. The five-block proof loads small block metadata; the production bounded directory traversal and full filter/mutation cases belong to implementation unit 2.

The first vector slice issued individual SQL reads and did not adequately reuse fine pages. Its evidence and source are retained as vector-result-per-page.json and vector-per-page.go.txt. The final slice follows the architecture's bounded batches, reuses each fine page within the current block, and prepares the exact-vector statement once. The exact scan control also uses batch reads. This is a probe correction, not a product code change.

Streaming uses the pinned MCP SDK IOTransport, StreamableClientTransport and StreamableHTTPHandler in one isolated process, connected with pipes and loopback HTTP. It validates decoded original bytes (SHA256 and length), adjacent fields, and both structured/text response representations. JSON literal size and decoded original size are reported separately. Output hashing and a test-host receiver are included in both latency measurements; this is not the entire storage/semantic workflow. One run per size/control is a feasibility sample, not p95 acceptance. Heap and whole-process RSS/private memory are separate measurements.

The probe handles a single large string field. Product authentication, collision-resistant scoped references, complete streaming validation, lists, cancellation, durable storage and combined model/process-tree budgets remain the existing implementation-unit acceptance duties. Do not copy the fixture parser/echo service into production.

Warm large-scale estimates assume the same asset density, pruning and per-block cost; they are not measured results or guarantees. Cold disk cost additionally depends on uncached bytes, sequential bandwidth and random-read latency. Neither the GB projections nor these mechanism checks replace frozen-workload latency acceptance.
