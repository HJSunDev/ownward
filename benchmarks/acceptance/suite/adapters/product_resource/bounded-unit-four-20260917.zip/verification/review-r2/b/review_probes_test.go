package boundedstore

import (
 "context"
 "errors"
 "os"
 "path/filepath"
 "testing"

 "github.com/HJSunDev/ownward/internal/assetlog"
)

func TestReview4MissingActivatedTargetCannotRollback(t *testing.T) {
 ctx := context.Background()
 root := t.TempDir()
 legacyFixture(t, root)
 interrupted := errors.New("review stop after activation")
 o := deploymentOptions()
 o.checkpoint = func(phase string) error { if phase == "activated" { return interrupted }; return nil }
 s, e := OpenDeployment(ctx, root, o)
 if s != nil { s.Close() }
 if !errors.Is(e, interrupted) { t.Fatal("fixture did not reach activation", e) }
 var state migrationState
 if e = readSmallJSON(filepath.Join(root, "migration.json"), &state); e != nil { t.Fatal(e) }
 target := filepath.Join(root, "stores", state.ID, "ownward.sqlite")
 if e = os.Rename(target, target+".unavailable"); e != nil { t.Fatal(e) }
 cancelError := CancelDeployment(ctx, root)
 old, oldError := assetlog.Open(filepath.Join(root, "assets"))
 if old != nil { old.Close() }
 t.Logf("cancel_error=%v legacy_open_error=%v", cancelError, oldError)
 if cancelError == nil || oldError == nil { t.Error("an activated but unavailable target allowed rollback to the old authority") }
}
