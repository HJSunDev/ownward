# 有界存储单元四：固定修复版本完整复审

**整轮复审完成，结论：通过。U4-B1、U4-B2均关闭，未发现新增阻塞项。** 本轮与首轮完整覆盖共同支持关闭本执行单元；A归档本轮证据、同步正式状态后停止，不自动扩大到题目优化、500题或真实用户资料切换。

## 版本与完整性

- 固定composition：`52797ade3d38c1dd4ce6a25436653734552a893265a9d9e0b7efcf3cc583dd94`。
- HEAD：`bea38d4d45e1777767608ddffd4fb109b4fb8fa7`，与首轮一致。
- `../source-identity.json`列出的**387项文件在本轮开始、结束全部匹配**，没有缺失或变化；最终核对时间2026-09-17 15:25:18 +08:00。见`initial-identity.json`、`final-identity.json`。
- 相比首轮只有10项文件变化：4个正式行为文件、2个测试文件、组合清单、正式证据及2份文档。6个源码/测试文件的首轮版本从原ZIP取出，逐项校验首轮SHA-256后比较完整差异；核验副本在`prior-source/`。
- 其余迁移保真、向量兼容、新旧互斥、遗忘、备份恢复、格式3和缓冲预算等路径代码未变，复用首轮完整审查与有效验证。没有仅凭两个测试就冒称重新验证全部产品。

## 原发现复核

| 发现 | 实现与独立证据 | 结论 |
| --- | --- | --- |
| U4-B1：已激活目标缺失时取消会恢复旧权威 | `CancelDeployment`先限制合法阶段，cleaning直接拒绝；目标缺失且存在活动指针或已处于validated时拒绝未知激活状态。正常目标仍查库内激活标记，真正早期取消保留。原首轮反例现返回“无法确认目标激活状态，拒绝回退”，实际旧assetlog入口因退休格式仍被拒绝；正常/缺失/损坏、修复目标后向前恢复和已决定rollback的接续均通过。 | 关闭 |
| U4-B2：授权管理者能准备却不能启动交接 | 运行中start改用按请求的`HandoffManager`；关闭运行时后，经`ReadControlAtContext`把请求凭据传至`ReadDeploymentControl`的有界主体选择，再执行现有交接权限检查。没有全主体加载或放松权限。真实发布服务测试中，非所有者管理者实际Prepare→Start→完成交接；源服务重启后owner和manager均可接续，无效/已撤销管理权凭据在前后两条路径均拒绝。 | 关闭 |

U4-B1的阶段判断与正式迁移顺序一致：validated日志先于指针发布及目标激活，cleaning日志晚于激活；因而“目标丢失、无法读取激活标记”不会再被当成“目标尚未激活”。已耐久决定的rollback继续完成原决定，不重新开启同一迁移。

U4-B2同时检查了正式调用、被选择的当前主体与权限核验。原首轮反例直接调用的旧`CheckHandoffManager(ctx, c.State(), id)`已经从start移除，本轮没有继续执行该过时组合来制造假回归，而是运行真实入口验证修复结果。默认无请求的控制读取保留兼容包装，用于无需管理者身份的原调用；请求路径才增加当前凭据选择。

## 独立验证

本轮只执行**一次Go命令，6项顶层测试、7项子测试全部通过，失败0、跳过0**。包并行度1、各包120秒上限；过程检查日志，无异常等待、重试或重复运行。所有测试及其子进程已结束，命令退出码0。

```text
go test -overlay .tmp/bounded-unit4/review-r2/b/overlay.json -p 1 -count=1 -timeout 120s -json ./internal/boundedstore ./internal/assembly ./cmd/ownward -run '^(TestReview4MissingActivatedTargetCannotRollback|TestDeploymentCancelBeforeActivationAndRejectAfter|TestDeploymentCancelKeepsUncertainTargetIsolated|TestDeploymentCancelResumesDurableRollback|TestBoundedHandoffKeepsIdentityAndReceipts|TestInstalledRuntimeTransfersAndResumesWithoutAnotherAuthority)$'
```

| 包 | 本轮覆盖 | 包报告耗时 |
| --- | --- | ---: |
| boundedstore | 首轮独立反例；早期/未激活取消；正常/缺失/损坏的激活后拒绝；向前恢复与rollback接续 | 4.217秒 |
| assembly | 正式装配交接后的身份、依据回执保留 | 1.311秒 |
| cmd/ownward | 隔离发布构建和真实源/目标服务，授权管理者交接、重启接续、拒绝无效及已撤销权限、旧端退役 | 29.973秒 |

这些是测试包耗时，不是用户保存资料、语义组织或取证作答的等待成绩。发布测试另记录的微型夹具耗时也不作性能验收数据。

证据：`verification-plan.md`、`review_probes_test.go`、`overlay.json`、`test-results.jsonl`、`review.json`。测试使用合成资料与隔离凭据区；外部AI调用0。发布测试复用既有helper创建并清理专属发布夹具，未使用真实用户资料。

A的受影响3包自验日志另独立核对为66项顶层、32项子测试通过，未见失败；`vet.log`无诊断。此为A已有验证，不计入B的6项独立测试数。

## 证据复用与交付边界

- 正式证据已记录修复版本及待复审状态；此前错误的已关闭标记已经撤回。本轮完成后由A统一将两发现改为关闭、归档报告并更新执行文档。
- 此次4个行为文件的变化仅影响迁移取消和交接授权，没有修改原文、语义组织、词法/向量检索或取证流程。未发现需要重复AI准备、题目答题或资源负载测量的依据。
- 资源测量和38案例407次工具等价回放继续绑定`3face7f6…`；14题11/14、24题24/24的外部模型成绩继续绑定`4e7a236f…`。它们不是`52797ade…`的新测量。原文、向量、资源冷热条件、磁盘口径和回放边界沿用首轮报告中的限定。
- 本结论仅关闭有界存储单元四的实现、已确认缺陷及必要回归，不宣称取证提速任务的13/14和约60秒目标已经达成，也不宣称整个产品已完成最终发布验收。
- B未修改正式代码、权威文档或Git状态；仅保存本轮隔离核验材料。审查及本地测试资源已释放，不再追加试验。

**下一步由A归档并同步状态，随后停止本单元工作。无需再次交付未变化实现的重复复审。**
