from __future__ import annotations

def process_question(
    question: dict[str, Any], output_root: Path, run_identity: str,
    binary: Path, embedding: Path,
    protocol: dict[str, Any], evaluator: Path,
    capability_factory: Callable[[], ExternalIntelligenceCapability],
    external_intelligence_scheduler: ExternalIntelligenceScheduler,
    stage_run_identities: dict[str, str] | None = None,
    *, prepare_only: bool = False, runtime_workers: int = 1,
) -> dict[str, Any]:
    evaluation_question = question
    question = _product_question(question)
    identifier = question["question_id"]
    root = output_root / "questions" / identifier
    result_path = root / "result.json"
    if prepare_only:
        require(not any((root / name).exists() for name in ("result.json", "answer.json", "reader", "judge")),
                "preparation requires a pre-answer data state")
    identity = _question_identity(question, run_identity)
    stages = stage_run_identities or {name: run_identity for name in ("semantic", "retrieval", "reader", "judge", "diagnostic")}
    stage_identities = {name: _question_identity(question, value) for name, value in stages.items()}
    if result_path.is_file():
        existing = load_json(result_path)
        if isinstance(existing, dict) and existing.get("identity") == identity and existing.get("complete") is True:
            return existing
        checkpoint_path = root / "checkpoint.json"
        checkpoint = load_json(checkpoint_path) if checkpoint_path.is_file() else {}
        if (isinstance(existing, dict) and existing.get("complete") is True
                and checkpoint.get("identity") == existing.get("identity")
                and checkpoint.get("stage_identities") == stage_identities):
            # Only run orchestration changed: preserve the answer, traces and original timings.
            existing["identity"] = identity
            write_json(result_path, existing)
            checkpoint["identity"] = identity
            write_json(checkpoint_path, checkpoint)
            return existing
        raise AdapterError(f"question checkpoint identity changed: {identifier}")
    root.mkdir(parents=True, exist_ok=True)
    checkpoint_path = root / "checkpoint.json"
    checkpoint = load_json(checkpoint_path) if checkpoint_path.is_file() else {
        "schema": QUESTION_SCHEMA,
        "identity": identity,
        "stage_identities": stage_identities,
        "question_id": identifier,
        "assets": [],
        "asset_sources": [],
        "organized_batches": 0,
        "analysis_completion_order": [],
        "submission_order": [],
        "phase_seconds": {"create": 0.0, "semantic": 0.0},
        "semantic_usage": _empty_usage(),
    }
    require(isinstance(checkpoint, dict), f"question checkpoint is invalid: {identifier}")
    if checkpoint.get("identity") != identity:
        require(checkpoint.get("stage_identities", {}).get("semantic") == stage_identities["semantic"], f"question semantic checkpoint identity changed: {identifier}")
        checkpoint["identity"] = identity
        checkpoint["stage_identities"] = stage_identities
        write_json(checkpoint_path, checkpoint)
    else:
        require(checkpoint.get("stage_identities", stage_identities) == stage_identities, f"question stage checkpoint identity changed: {identifier}")
    data_dir = root / "ownward-data"
    environment = kernel_runtime_environment(embedding, runtime_workers)
    started = time.monotonic()
    stored_phase = checkpoint.get("phase_seconds") if isinstance(checkpoint.get("phase_seconds"), dict) else {}
    create_seconds = float(stored_phase.get("create", 0.0))
    semantic_seconds = float(stored_phase.get("semantic", 0.0))
    stored_usage = checkpoint.get("semantic_usage") if isinstance(checkpoint.get("semantic_usage"), dict) else {}
    semantic_usage = _empty_usage()
    _add_usage(semantic_usage, stored_usage)
    capability = capability_factory()
    # One independent scope per question, shared by its parallel analysis units,
    # Reader and Judge. Stateless/legacy transports require no new API.
    if isinstance(capability, ExternalIntelligenceCapability):
        factory = getattr(capability.transport, "new_scope", None)
        if callable(factory):
            capability = ExternalIntelligenceCapability(factory(), capability.semantic_contract)
    semantic_contract = (
        capability.semantic_contract
        if isinstance(capability, ExternalIntelligenceCapability)
        else semantic_representation.load_contract(None)
    )
    # Batch organization includes local vector generation; it is not a query.
    with OwnwardRuntime(binary, data_dir, environment, startup_seconds=60, operation_seconds=float(protocol["memory"]["semantic_timeout_seconds"])) as runtime:
        require(runtime.client is not None, "Ownward client is unavailable")
        sessions = [session_content(str(sid), str(date), turns) for sid, date, turns in zip(question["haystack_session_ids"], question["haystack_dates"], question["haystack_sessions"])]
        assets = list(checkpoint.get("assets", []))
        asset_sources = list(checkpoint.get("asset_sources", []))
        require(len(asset_sources) == len(assets), f"asset source checkpoint is incomplete: {identifier}")
        batch_size = int(protocol["memory"]["create_batch_size"])
        for offset in range(len(assets), len(sessions), batch_size):
            contents = sessions[offset:offset + batch_size]
            phase_started = time.monotonic()
            created = runtime.client.call_tool("ownward_create_batch", {"items": [
                {"content": content, "contexts": [{"key": "source", "value": "LongMemEval-S"}], "source": {"actor": "longmemeval-s", "ref": session_reference(str(question["haystack_session_ids"][offset + index]))}}
                for index, content in enumerate(contents)
            ]})
            values = created.get("results") if isinstance(created, dict) else None
            require(isinstance(values, list) and len(values) == len(contents), f"Ownward create batch failed: {identifier}")
            for index, value in enumerate(values):
                mutation = value.get("result") if isinstance(value, dict) and not value.get("error") else None
                information = mutation.get("information") if isinstance(mutation, dict) else None
                require(isinstance(information, dict) and isinstance(information.get("id"), str), f"Ownward create item failed: {identifier}")
                assets.append(information["id"])
                asset_sources.append({
                    "asset_id": information["id"],
                    "session_id": str(question["haystack_session_ids"][offset + index]),
                })
            create_seconds += time.monotonic() - phase_started
            checkpoint["assets"] = assets
            checkpoint["asset_sources"] = asset_sources
            checkpoint["phase_seconds"] = {"create": create_seconds, "semantic": semantic_seconds}
            write_json(checkpoint_path, checkpoint)
        # The caller verified identical authoritative data and derived state.
        # Validate completed stage identity and order without rebuilding AI prompts.
        plan = load_json(root / "semantic-plan.json")
        semantic_size = int(protocol["memory"]["semantic_batch_size"])
        expected_batches = (len(assets) + semantic_size - 1) // semantic_size
        require(checkpoint.get("organized_batches") == expected_batches,
                "prepared fixture is not completely organized")
        require(checkpoint.get("submission_order") == list(range(expected_batches)),
                "prepared fixture submission order is invalid")
        require(plan.get("question_identity") == stage_identities["semantic"],
                "prepared fixture semantic identity changed")
        require(len(plan.get("batches", [])) == expected_batches,
                "prepared fixture plan is incomplete")
        trace_root = root / "semantic-traces"
        plan_path = root / "semantic-plan.json"
        direct_question_probe: dict[str, Any] | None = None
        runtime.client.timeout_seconds = float(protocol["retrieval"]["query_timeout_seconds"])
        retrieval_path = root / "retrieval.json"
        reader_prompt = _active_answer_prompt(question, protocol["retrieval"])
        reader_input_path = root / "reader" / "input.json"
        _write_immutable(reader_input_path, {
            "schema": "ownward.longmemeval-s-reader-input/v2",
            "question_identity": stage_identities["reader"],
            "question": question["question"],
            "question_date": question.get("question_date", ""),
            "retrieval_mode": protocol["retrieval"]["mode"],
            "tool_budget": {
                "calls": protocol["retrieval"]["max_tool_calls"],
                "reads": protocol["retrieval"]["read_limit"],
                "context_chars": protocol["retrieval"]["context_max_chars"],
            },
            "prompt": reader_prompt,
            "prompt_sha256": hashlib.sha256(reader_prompt.encode("utf-8")).hexdigest(),
        }, f"Reader input changed: {identifier}")
        reader_output_path = root / "reader" / "output.json"
        if reader_output_path.is_file():
            require(retrieval_path.is_file(), f"active retrieval evidence is missing: {identifier}")
            reader_output_value = load_json(reader_output_path)
            require(reader_output_value.get("question_identity") == stage_identities["reader"], f"Reader output identity changed: {identifier}")
            retrieval_checkpoint = load_json(retrieval_path)
            require(
                isinstance(retrieval_checkpoint, dict)
                and retrieval_checkpoint.get("question_identity") == stage_identities["retrieval"],
                f"retrieval checkpoint identity changed: {identifier}",
            )
            retrieval = retrieval_checkpoint["retrieval"]
            require(retrieval.get("mode") == "external-agent-progressive/v1", f"passive retrieval cannot resume product evaluation: {identifier}")
            answer = reader_output_value["answer"]
            reader_usage = reader_output_value["usage"]
            reader_seconds = float(reader_output_value["wall_seconds"])
        else:
            reader_started = time.monotonic()
            answer, reader_usage, retrieval = external_intelligence_scheduler.submit(
                capability.active_answer,
                question,
                runtime.client,
                protocol["reader"],
                protocol["retrieval"],
                root / "reader" / "codex",
            ).result()
            reader_seconds = time.monotonic() - reader_started
            _write_immutable(retrieval_path, {
                "schema": "ownward.longmemeval-s-retrieval/v2",
                "question_identity": stage_identities["retrieval"],
                "retrieval": retrieval,
            }, f"retrieval checkpoint changed: {identifier}")
            _write_immutable(reader_output_path, {
                "schema": "ownward.longmemeval-s-reader-output/v2",
                "question_identity": stage_identities["reader"],
                "retrieval_sha256": sha256(retrieval_path),
                "answer": answer,
                "usage": reader_usage,
                "wall_seconds": reader_seconds,
            }, f"Reader output changed: {identifier}")
        source_to_asset = {str(item["session_id"]): str(item["asset_id"]) for item in asset_sources}
        expected_assets = [
            source_to_asset[str(value)]
            for value in evaluation_question.get("answer_session_ids", [])
            if str(value) in source_to_asset
        ]
        if not set(expected_assets).issubset(set(retrieval.get("read_ids", []))):
            direct_question_probe = _direct_question_retrieval_probe(
                runtime.client,
                str(question["question"]),
                expected_assets,
                int(protocol["retrieval"]["search_limit_per_call"]),
            )
    answer_path = root / "answer.json"
    _write_immutable(answer_path, {
        "schema": "ownward.longmemeval-s-frozen-answer/v1",
        "question_identity": stage_identities["reader"],
        "answer": answer,
        "reader_output_sha256": sha256(reader_output_path),
    }, f"frozen product answer changed: {identifier}")
    prompt = official_prompt(evaluator, evaluation_question, answer)
    judge_input_path = root / "judge" / "input.json"
    _write_immutable(judge_input_path, {
        "schema": "ownward.longmemeval-s-judge-input/v1",
        "question_identity": stage_identities["judge"],
        "answer_frozen_sha256": sha256(answer_path),
        "official_prompt": prompt,
        "official_prompt_sha256": hashlib.sha256(prompt.encode("utf-8")).hexdigest(),
    }, f"official judge input changed: {identifier}")
    judge_output_path = root / "judge" / "output.json"
    if judge_output_path.is_file():
        judge_output_value = load_json(judge_output_path)
        require(judge_output_value.get("question_identity") == stage_identities["judge"], f"judge output identity changed: {identifier}")
        correct = bool(judge_output_value["label"])
        judge_output = str(judge_output_value["output"])
        judge_usage = judge_output_value["usage"]
        judge_seconds = float(judge_output_value["wall_seconds"])
    else:
        judge_started = time.monotonic()
        correct, judge_output, judge_usage = external_intelligence_scheduler.submit(
            capability.judge,
            prompt,
            protocol["judge"],
            root / "judge" / "codex",
        ).result()
        judge_seconds = time.monotonic() - judge_started
        _write_immutable(judge_output_path, {
            "schema": "ownward.longmemeval-s-judge-output/v1",
            "question_identity": stage_identities["judge"],
            "model": protocol["judge"]["model"],
            "reasoning_effort": protocol["judge"]["reasoning_effort"],
            "label": correct,
            "output": judge_output,
            "usage": judge_usage,
            "wall_seconds": judge_seconds,
        }, f"judge output changed: {identifier}")
    wall_seconds = time.monotonic() - started
    require(wall_seconds <= float(protocol["execution"]["question_wall_seconds"]), f"question wall budget exceeded: {identifier}")
    data_bytes = sum(path.stat().st_size for path in data_dir.rglob("*") if path.is_file())
    phase_seconds = {
        "create": create_seconds,
        "semantic": semantic_seconds,
        "retrieval": retrieval["total_ms"] / 1000.0,
        "reader": max(0.0, reader_seconds - retrieval["total_ms"] / 1000.0),
        "judge": judge_seconds,
        "other": max(0.0, wall_seconds - create_seconds - semantic_seconds - reader_seconds - judge_seconds),
    }
    usage = {"semantic": semantic_usage, "reader": reader_usage, "judge": judge_usage}
    organized_asset_ids: list[str] = []
    for frozen in plan["batches"]:
        submission = load_json(trace_root / frozen["batch_id"] / "submission.json")
        organized_asset_ids.extend(str(value) for value in submission["asset_ids"])
    require(organized_asset_ids == assets, f"organized asset identity changed: {identifier}")
    diagnostic_path = root / "diagnostic.json"
    diagnostic = _diagnostic_record(
        evaluation_question,
        identity=stage_identities["diagnostic"],
        answer=answer,
        correct=correct,
        assets=assets,
        asset_sources=asset_sources,
        organized_asset_ids=organized_asset_ids,
        retrieval=retrieval,
        semantic_trace_root=trace_root,
        reader_input=reader_input_path,
        reader_output=reader_output_path,
        judge_input=judge_input_path,
        judge_output=judge_output_path,
        phase_seconds=phase_seconds,
        usage=usage,
        checkpoint_path=checkpoint_path,
        semantic_plan_path=plan_path,
        retrieval_path=retrieval_path,
        answer_path=answer_path,
        direct_question_probe=direct_question_probe,
    )
    _write_immutable(diagnostic_path, diagnostic, f"diagnostic evidence changed: {identifier}")
    result = {
        "schema": QUESTION_SCHEMA, "identity": identity, "question_id": identifier, "question_type": question["question_type"],
        "hypothesis": answer, "autoeval_label": {"model": protocol["judge"]["model"], "label": correct, "output": judge_output},
        "retrieval": retrieval, "usage": usage,
        "asset_count": len(assets), "semantic_batches": expected_batches,
        "semantic_execution": {
            "plan_sha256": plan["serial_identity_sha256"],
            "serial_concurrent_equivalent": plan["equivalent"],
            "analysis_completion_order": checkpoint["analysis_completion_order"],
            "submission_order": checkpoint["submission_order"],
            "analysis_units": plan["transport"]["analysis_calls"],
            "analysis_input_token_upper_bound": protocol["memory"]["semantic_analysis_input_token_upper_bound"],
            "analysis_output_token_upper_bound": protocol["memory"]["semantic_analysis_output_token_upper_bound"],
            "input_representation": semantic_contract.representation,
            "input_representation_manifest_identity": semantic_contract.manifest_identity,
            "all_analyses_complete_before_submission": True,
        },
        "phase_seconds": phase_seconds,
        "diagnostic": {"path": diagnostic_path.as_posix(), "sha256": sha256(diagnostic_path), "first_observed_gap": diagnostic["first_observed_gap"]},
        "resources": {"ownward_data_bytes": data_bytes}, "wall_seconds": wall_seconds, "complete": True,
    }
    write_json(result_path, result)
    return result
