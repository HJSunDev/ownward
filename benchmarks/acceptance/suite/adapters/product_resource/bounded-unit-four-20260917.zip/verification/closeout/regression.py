import concurrent.futures, hashlib, importlib.util, json, os, shutil, subprocess, sys, time
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
sys.path.insert(0,str(ROOT/'benchmarks/longmemeval_s'))
sys.path.insert(0,'E:/Ownward/acceptance/longmemeval-s/runtime/v1/python/Lib/site-packages')
import run as p
import migrate_materials as migration
PREP=ROOT/'.tmp/four-package-quality/prepared-20260911-130158'
def read(f):return json.loads(Path(f).read_text(encoding='utf-8-sig'))
def save(f,v):p.write_json(f,v)
config=read(PREP/'current-execution.json')
env=read(config['community']['environment_manifest'])
external=config['community']['external_intelligence']
bundle=ROOT/'.tmp/bounded-unit1/formal-bundle'
host=OUT/'host.exe'
def materials(which):
    if which=='14':
        catalog=read(ROOT/'.tmp/evidence-answer-improvement-20260913/runs/full14-examples-sentences-1/material-reuse.json')
        allq=p.validate_dataset(Path(env['layout']['data']),formal=True)
        return [(int(k.split(':')[1]),allq[int(k.split(':')[1])-1],Path(v['source'])) for k,v in catalog.items()]
    fixed=read(ROOT/'benchmarks/acceptance/suite/iteration/v2/fixed-capability-regression.json')
    assert p.sha256(Path(fixed['dataset']))==fixed['dataset_sha256']
    return [(q['question_id'],q,ROOT/'.tmp/formal-kernel24-20260914/questions'/q['question_id']) for q in p.validate_dataset(Path(fixed['dataset']),formal=False)]
def prepare(which):
    def one(item):
        ordinal,q,source=item; target=OUT/('materials'+which)/'questions'/q['question_id'];target.mkdir(parents=True,exist_ok=True)
        if (target/'ownward-data.migration.json').exists(): return read(target/'ownward-data.migration.json')
        if (target/'ownward-data/storage.json').exists():
            proof=migration.verify_compatible(source/'ownward-data',target/'ownward-data')
            result={'source_sha256':migration.hashes(source/'ownward-data'),'target_sha256':migration.hashes(target/'ownward-data'),'new_semantic_calls':0,**proof}
            save(target/'ownward-data.migration.json',result)
        else:
            assert not (target/'ownward-data').exists(), 'Incomplete conversion must be diagnosed before resuming'
            result=migration.migrate_snapshot(source/'ownward-data',target/'ownward-data',[str(host),'migrate'],environment=dict(os.environ,OWNWARD_EMBEDDING_BUNDLE_DIR=str(bundle),GOMAXPROCS='2'))
        for name in ('checkpoint.json','semantic-plan.json'):
            shutil.copyfile(source/name,target/name)
        copy_receipts(source,target)
        print(json.dumps({'prepared':ordinal,**{k:result[k] for k in ('assets','organizations','new_semantic_calls')}},ensure_ascii=False),flush=True)
        return result
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        list(pool.map(one,materials(which)))

def copy_receipts(source,target):
    for batch in read(source/'semantic-plan.json')['batches']:
        relative=Path('semantic-traces')/batch['batch_id']/'submission.json'
        assert (source/relative).is_file(),str(source/relative)
        (target/relative).parent.mkdir(parents=True,exist_ok=True)
        if (target/relative).exists():
            assert p.sha256(source/relative)==p.sha256(target/relative)
        else: shutil.copyfile(source/relative,target/relative)

def finish(which):
    out=OUT/('regression'+which); identity=read(out/'identity.json');rid=identity['identity']
    assert p.sha256(host)==identity['binary_sha256']
    spec=importlib.util.spec_from_file_location('prepared_runner',ROOT/'.tmp/evidence-answer-improvement-20260913/prepared_runner.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    mod.install(p,out/'prepared-process.py');assert p.sha256(out/'prepared-process.py')==identity['prepared_runner_sha256']
    previous=read(out/'summary.json');save(out/'report-interruption.json',previous)
    hashes={str(f.relative_to(out)):p.sha256(f) for f in out.glob('questions/*/*/output.json')}
    class NoAI:
        new_scope=None
        def __getattr__(self,name):raise AssertionError('No AI call permitted while completing frozen reports: '+name)
    contract=p.semantic_representation.load_contract(ROOT/'manifests/kernel-candidates/v2/source-ownership/semantic-representation.json')
    rows=[]
    with p.ExternalIntelligenceScheduler(1) as scheduler:
        for ordinal,q,source in materials(which):
            copy_receipts(source,out/'questions'/q['question_id'])
            result=p.process_question(q,out,rid,host,bundle,identity['protocol'],PREP/'evaluation-only/evaluate_qa.py',lambda:p.ExternalIntelligenceCapability(NoAI(),contract),scheduler,stage_run_identities={k:identity['semantic_run_identity'] if k=='semantic' else rid for k in ('semantic','retrieval','reader','judge','diagnostic')},runtime_workers=6)
            phases=result['phase_seconds'];row={'ordinal':ordinal,'case':q['question_id'],'correct':result['autoeval_label']['label'],'wait_seconds':phases['reader']+phases['retrieval'],'complete':True}
            rows.append(row);print(json.dumps(row),flush=True)
    assert hashes=={str(f.relative_to(out)):p.sha256(f) for f in out.glob('questions/*/*/output.json')}
    save(out/'summary.json',{'results':rows,'passed':sum(r['correct'] is True for r in rows),'failed':sum(r['correct'] is False for r in rows),'incomplete':0,'mean_wait_seconds':sum(r['wait_seconds'] for r in rows)/len(rows),'binary_unchanged':True,'report_completion':{'new_ai_calls':0,'reader_and_judge_outputs_unchanged':True}})
def run(which):
    base=OUT/('materials'+which); out=OUT/('regression'+which)
    assert not out.exists(),'Do not overwrite an independent evaluation'
    out.mkdir()
    spec=importlib.util.spec_from_file_location('prepared_runner',ROOT/'.tmp/evidence-answer-improvement-20260913/prepared_runner.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);mod.install(p,out/'prepared-process.py')
    protocol=p.apply_external_intelligence_roles(read(ROOT/'benchmarks/longmemeval_s/protocol.json'),{k:external['roles'][k] for k in ('semantic','reader','judge')})
    contract=p.semantic_representation.load_contract(ROOT/'manifests/kernel-candidates/v2/source-ownership/semantic-representation.json')
    cases=materials(which)
    semantic=read(ROOT/'.tmp/formal-prompt14-20260913-recovery/identity.json')['resumed_semantic_identity'] if which=='14' else read(ROOT/'.tmp/formal-kernel24-20260914/identity.json')['identity']
    identity={'suite':which,'cases':[q['question_id'] for _,q,_ in cases],'excluded':[],'not_optimization_targets':[123,139] if which=='14' else [],'binary_sha256':p.sha256(host),'composition':read(ROOT/'manifests/compositions/v1/current-collaborative.json'),'protocol':protocol,'semantic_run_identity':semantic,'prepared_runner_sha256':p.sha256(out/'prepared-process.py'),'started':time.time(),'semantic_calls':0}
    rid=p.canonical_sha256(identity);save(out/'identity.json',{**identity,'identity':rid})
    for _,q,_ in cases:
        case=q['question_id'];s=base/'questions'/case; t=out/'questions'/case;shutil.copytree(s,t)
    for _,q,source in cases:copy_receipts(source,out/'questions'/q['question_id'])
    rows=[]
    with p.ExternalIntelligenceScheduler(8) as scheduler, p.open_external_intelligence_runtime(driver=external['driver'],binary=ROOT/'benchmarks/longmemeval_s/go_api_external_intelligence.py',credential_file=Path(external['credential_file']),max_active=8,worker_processes=8,runtime_parent=out/'.runtime') as transport:
        def one(item):
            ordinal,q,_=item;start=time.monotonic();print(json.dumps({'started':ordinal}),flush=True)
            try:
                result=p.process_question(q,out,rid,host,bundle,protocol,PREP/'evaluation-only/evaluate_qa.py',lambda:p.ExternalIntelligenceCapability(transport,contract),scheduler,stage_run_identities={k:semantic if k=='semantic' else rid for k in ('semantic','retrieval','reader','judge','diagnostic')},runtime_workers=6)
                phases=result['phase_seconds'];row={'ordinal':ordinal,'case':q['question_id'],'correct':result['autoeval_label']['label'],'wait_seconds':phases['reader']+phases['retrieval'],'complete':True}
            except Exception as e:
                p.record_question_failure(out,q,e);row={'ordinal':ordinal,'case':q['question_id'],'complete':False,'error':str(e),'error_type':type(e).__name__}
            row['wall_seconds']=time.monotonic()-start;print(json.dumps(row,ensure_ascii=False),flush=True);save(out/('status-'+q['question_id']+'.json'),row);return row
        with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
            for future in concurrent.futures.as_completed([pool.submit(one,x) for x in cases]):
                rows.append(future.result());save(out/'progress.json',rows)
    waits=[r['wait_seconds'] for r in rows if r['complete']]
    save(out/'summary.json',{'results':rows,'passed':sum(r.get('correct') is True for r in rows),'failed':sum(r.get('correct') is False for r in rows),'incomplete':sum(not r['complete'] for r in rows),'mean_wait_seconds':sum(waits)/len(waits) if waits else None,'binary_unchanged':identity['binary_sha256']==p.sha256(host)})
if __name__=='__main__':
    {'prepare':prepare,'run':run,'finish':finish}[sys.argv[1]](sys.argv[2])
