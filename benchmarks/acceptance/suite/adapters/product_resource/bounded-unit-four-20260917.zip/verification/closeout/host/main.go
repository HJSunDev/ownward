// Isolated evaluation host: real assembly, authorization and MCP adapter.
// The harness is the owner of its generated fixture data, never user data.
package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"github.com/HJSunDev/ownward/internal/adapter/mcpserver"
	"github.com/HJSunDev/ownward/internal/assembly"

	"github.com/HJSunDev/ownward/internal/informationcontrol"

	"github.com/HJSunDev/ownward/internal/resourcebudget"
	"github.com/modelcontextprotocol/go-sdk/mcp"
	"net"
	"net/http"
	"os"
	"path/filepath"
)

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
func run() error {
	flags := flag.NewFlagSet("mcp-http", flag.ContinueOnError)
	data := flags.String("data-dir", "", "")
	address := flags.String("listen", "127.0.0.1:0", "")
	token := flags.String("token", "", "")
	if err := flags.Parse(os.Args[2:]); err != nil {
		return err
	}
	runtime, err := assembly.Open(assembly.Request{DataDir: *data, ProductSemantics: assembly.Collaborative, VectorBundleDir: os.Getenv("OWNWARD_EMBEDDING_BUNDLE_DIR")})
	if err != nil {
		return err
	}
	defer runtime.Close()
	if os.Args[1] == "migrate" {
		return nil
	}
	var credential string
	if runtime.UserControl().SystemID() == "" {
		credential, err = runtime.UserControl().InitializeOwner("isolated evaluation owner")
	} else {
		credential, err = runtime.UserControl().RecoverOwner()
	}
	if err != nil {
		return err
	}
	server := mcpserver.NewStreamingStorage(runtime.Streaming(), "formal-product-evaluation", filepath.Join(*data, "scratch"), runtime.Streaming().Budget, 256*resourcebudget.MiB)
	server.AddManagementTools(runtime.Management())
	// The generated transport token is the harness's private connection; scope
	// authorization still runs through the actual Product on every invocation.
	server.MCP().AddReceivingMiddleware(func(next mcp.MethodHandler) mcp.MethodHandler {
		return func(ctx context.Context, method string, req mcp.Request) (mcp.Result, error) {
			return next(informationcontrol.Authenticate(ctx, credential), method, req)
		}
	})
	listener, err := net.Listen("tcp", *address)
	if err != nil {
		return err
	}
	defer listener.Close()
	handler := server.HTTPHandler()
	secured := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") != "Bearer "+*token {
			http.Error(w, "forbidden", http.StatusForbidden)
			return
		}

		r = r.WithContext(informationcontrol.Authenticate(r.Context(), credential))
		handler.ServeHTTP(w, r)
	})
	if err = json.NewEncoder(os.Stdout).Encode(map[string]string{"endpoint": "http://" + listener.Addr().String()}); err != nil {
		return err
	}
	return http.Serve(listener, secured)
}
