import json,time
from pathlib import Path
import regression as r
out=r.OUT/'closeout-full-replay';out.mkdir(exist_ok=True)
host=r.OUT/'host-closeout.exe'
def simplify(value):
 if isinstance(value,list):return [simplify(x) for x in value]
 if isinstance(value,dict):return {k:('nav2:<opaque>' if k=='continuation' and isinstance(v,str) and v.startswith('nav2:') else simplify(v)) for k,v in value.items() if k not in ('basis','basis_receipt','generation','expires_at','created_at','request_id')}
 return value
rows=[]; cases=[]
for suite in ('14','24'):
 for ordinal,q,source in r.materials(suite):
  case=q['question_id'];data=out/suite/case/'data'; print('migrate',suite,ordinal,flush=True)
  proof=r.read(data.with_name('data.migration.json')) if data.with_name('data.migration.json').exists() else r.migration.migrate_snapshot(source/'ownward-data',data,[str(host),'migrate'],environment=r.p.kernel_runtime_environment(r.bundle,4))
  steps=r.read(r.OUT/('regression'+suite)/'questions'/case/'retrieval.json')['retrieval']['selection_steps']
  if (out/suite/case/'case-summary.json').exists():
   saved=r.read(out/suite/case/'case-summary.json'); cases.append(saved); rows.extend(r.read(out/suite/case/f'step-{i}.json')['comparison'] for i in range(len(steps)) if steps[i].get('success',True)); print('reuse verified',suite,ordinal,flush=True); continue
  token_map={}
  def arguments(v):
   if isinstance(v,dict):return {k:arguments(x) for k,x in v.items()}
   if isinstance(v,list):return [arguments(x) for x in v]
   if isinstance(v,str) and v.startswith('nav2:'):return token_map[v]
   return v
  def bind(a,b):
   if isinstance(a,dict) and isinstance(b,dict):
    for k in a.keys() & b.keys():
     if k=='continuation' and isinstance(a[k],str) and a[k].startswith('nav2:'):token_map[b[k]]=a[k]
     else:bind(a[k],b[k])
   elif isinstance(a,list) and isinstance(b,list):
    for x,y in zip(a,b):bind(x,y)
  with r.p.OwnwardRuntime(host,data,r.p.kernel_runtime_environment(r.bundle,4),startup_seconds=60,operation_seconds=120) as runtime:
   for i,step in enumerate(steps):
    if not step.get('success',True):
     assert step['result'] is None; r.save(out/suite/case/f'rejected-{i}.json',{'reason':'original harness rejection before product invocation; unchanged harness','record':step}); continue
    start=time.monotonic();actual=runtime.client.call_tool(step['tool'],arguments(step['arguments'])); bind(actual,step['result'])
    row={'suite':suite,'ordinal':ordinal,'step':i,'tool':step['tool'],'equal':simplify(actual)==simplify(step['result']),'seconds':time.monotonic()-start}
    r.save(out/suite/case/f'step-{i}.json',{'arguments':step['arguments'],'replayed_arguments':arguments(step['arguments']),'actual':actual,'expected':step['result'],'comparison':row});rows.append(row)
    if not row['equal']: print('MISMATCH',row,flush=True);raise SystemExit(1)
  cases.append({'suite':suite,'ordinal':ordinal,'case':case,'steps':len(steps),'migration':proof})
  r.save(out/suite/case/'case-summary.json',cases[-1]); print('equal',suite,ordinal,len(steps),flush=True)
  r.save(out/'progress.json',{'cases':len(cases),'steps':len(rows),'all_equal':all(x['equal'] for x in rows)})
summary={'binary_sha256':r.p.sha256(host),'composition':r.read(r.ROOT/'manifests/compositions/v1/current-collaborative.json')['identity'],'all_equal':all(x['equal'] for x in rows),'steps':rows,'cases':cases,'new_ai_calls':0,'comparison_notes':'Opaque nav2 continuation values normalized while preserving presence; subsequent requests are rebound to newly issued tokens and continuations executed. Transient basis and generation identities excluded; other result fields compared exactly.'}
r.save(out/'summary.json',summary)
