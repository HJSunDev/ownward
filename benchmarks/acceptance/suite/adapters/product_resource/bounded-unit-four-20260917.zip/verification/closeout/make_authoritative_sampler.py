from pathlib import Path
p=Path('.tmp/bounded-unit4')
monitor=''' import importlib.util,sys,ctypes
 sys.path.insert(0,str(pathlib.Path.cwd()))
 spec=importlib.util.spec_from_file_location('delivery_verify',pathlib.Path('benchmarks/acceptance/suite/adapters/product_resource/verify.py'));v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
 while not stop:
  snapshot=v._process_snapshot();pids=set()
  for pid in list(roots):pids.update(v._descendants(pid,snapshot))
  total=private=non_model=0;detail={}
  for pid in pids:
   handle=v.kernel32.OpenProcess(v.PROCESS_QUERY_LIMITED_INFORMATION|v.PROCESS_VM_READ,False,pid)
   if not handle:continue
   try:
    m=v.PROCESS_MEMORY_COUNTERS_EX();m.cb=ctypes.sizeof(m)
    if not v.psapi.GetProcessMemoryInfo(handle,ctypes.byref(m),m.cb):continue
    name=snapshot.get(pid,(0,''))[1];rss=m.WorkingSetSize;total+=rss;private+=m.PrivateUsage;non_model+=rss if name!='llama-server.exe' else 0;detail[str(pid)]=[name,rss];individual[name]=max(individual.get(name,0),rss)
   finally:v.kernel32.CloseHandle(handle)
  private_peak=max(private_peak,private);non_model_peak=max(non_model_peak,non_model)
  if total>peak:peak=total;samples.append({'rss':total,'processes':detail})
  time.sleep(.05)
'''
for name in ('final-delivery','final-cold'):
 s=(p/f'measure-{name}.py').read_text(encoding='utf-8-sig')
 a=s.index(' while not stop:');b=s.index('thread=threading.Thread',a)
 s=s[:a]+monitor+s[b:]
 (p/f'measure-controlled-{name}.py').write_text(s,encoding='utf-8')
