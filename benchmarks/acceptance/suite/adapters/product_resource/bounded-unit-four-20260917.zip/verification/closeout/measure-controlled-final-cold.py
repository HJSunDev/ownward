import subprocess, pathlib, os, json, time, threading, urllib.request, hashlib, psutil
root=pathlib.Path('.tmp/bounded-unit4').resolve();work=root/('closeout-resource-'+str(time.time_ns()));work.mkdir()
exe=root/'ownward-test-final-delivery.exe';env=dict(os.environ,GOMAXPROCS='4',OWNWARD_BOUND_ROLE='service',OWNWARD_BOUND_DIR=str(work),OWNWARD_BOUND_BUNDLE=str(pathlib.Path('.tmp/bounded-unit1/formal-bundle').resolve()),OWNWARD_BOUND_RETRIEVAL='1',OWNWARD_BOUND_FORMAL='1')
log=(work/'service.log').open('wb');boot=time.monotonic();service=subprocess.Popen([str(exe),'-test.run=^TestBoundedStorageProcess$'],stdin=subprocess.PIPE,stdout=log,stderr=log,env=env,creationflags=subprocess.DETACHED_PROCESS)
roots=[service.pid];stop=False;peak=0;private_peak=0;non_model_peak=0;individual={};samples=[]
def monitor():
 global peak, private_peak, non_model_peak
 import importlib.util,sys,ctypes
 sys.path.insert(0,str(pathlib.Path.cwd()))
 spec=importlib.util.spec_from_file_location('delivery_verify',pathlib.Path('benchmarks/acceptance/suite/adapters/product_resource/verify.py'));v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
 while not stop:
  snapshot=v._process_snapshot();pids=set()
  for pid in list(roots):pids.update(v._descendants(pid,snapshot))
  total=private=non_model=0;detail={}
  for pid in pids:
   handle=v.kernel32.OpenProcess(v.PROCESS_QUERY_LIMITED_INFORMATION|v.PROCESS_VM_READ,False,pid)
   if not handle:continue
   try:
    m=v.PROCESS_MEMORY_COUNTERS_EX();m.cb=ctypes.sizeof(m)
    if not v.psapi.GetProcessMemoryInfo(handle,ctypes.byref(m),m.cb):continue
    name=snapshot.get(pid,(0,''))[1];rss=m.WorkingSetSize;total+=rss;private+=m.PrivateUsage;non_model+=rss if name!='llama-server.exe' else 0;detail[str(pid)]=[name,rss];individual[name]=max(individual.get(name,0),rss)
   finally:v.kernel32.CloseHandle(handle)
  private_peak=max(private_peak,private);non_model_peak=max(non_model_peak,non_model)
  if total>peak:peak=total;samples.append({'rss':total,'processes':detail})
  time.sleep(.05)
thread=threading.Thread(target=monitor);thread.start();connector=None
try:
 deadline=time.monotonic()+25
 while not (work/'endpoint').exists():
  if service.poll() is not None:raise RuntimeError((work/'service.log').read_text(errors='replace'))
  if time.monotonic()>deadline:raise RuntimeError('service startup timeout')
  time.sleep(.05)
 endpoint=(work/'endpoint').read_text()
 env.update(OWNWARD_BOUND_ROLE='connector',OWNWARD_BOUND_ENDPOINT=endpoint)
 err=(work/'connector.log').open('wb')
 connector=subprocess.Popen([str(exe),'-test.run=^TestBoundedStorageProcess$'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,env=env,creationflags=subprocess.DETACHED_PROCESS);roots.append(connector.pid)
 def send(v):connector.stdin.write(json.dumps(v,ensure_ascii=False,separators=(',',':')).encode()+b'\n');connector.stdin.flush()
 def request(v):
  send(v)
  while True:
   line=connector.stdout.readline()
   if not line:raise RuntimeError('connector ended: '+(work/'connector.log').read_text(errors='replace'))
   result=json.loads(line)
   if result.get('id')==v['id']:return result
 request({'jsonrpc':'2.0','id':1,'method':'initialize','params':{'protocolVersion':'2025-03-26','capabilities':{},'clientInfo':{'name':'external-fixture','version':'1'}}})
 send({'jsonrpc':'2.0','method':'notifications/initialized'})

 metrics=[];warm=[];counter=2
 def call(name,args):
  global counter
  key=counter;counter+=1
  result=request({'jsonrpc':'2.0','id':key,'method':'tools/call','params':{'name':name,'arguments':args,'_meta':{'ownward/operation':'op-'+str(key),'ownward/generation':1}}})
  if result.get('error') or result.get('result',{}).get('isError'):raise RuntimeError(str(result)[:1600])
  v=result['result']['structuredContent'];assert json.loads(result['result']['content'][0]['text'])==v
  return v
 start=time.monotonic();call('ownward_search',{'query':'如何恢复我此前记录的旅行准备经验？','limit':10});cold=time.monotonic()-boot
 metrics.append({'cold_start_total_ms':cold*1000})
 print(metrics[-1],flush=True)

finally:
 if connector is not None:
  connector.stdin.close()
  try:connector.wait(timeout=8)
  except subprocess.TimeoutExpired:connector.terminate();connector.wait()
 if service.poll() is None:service.stdin.write(b'x');service.stdin.flush();service.wait(timeout=10)
 stop=True;thread.join();log.close()
 evidence={'binary_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'composition':json.loads(pathlib.Path('manifests/compositions/v1/current-collaborative.json').read_text(encoding='utf-8')).get('identity'),'small_query_seconds':locals().get('warm',[]),'peak_mib':peak/1048576,'private_commit_peak_mib':private_peak/1048576,'non_model_peak_mib':non_model_peak/1048576,'individual_peak_mib':{k:v/1048576 for k,v in individual.items()},'peak_observations':samples[-5:],'tests':locals().get('metrics',[]),'service_exit':service.returncode,'connector_exit':connector.returncode if connector else None}
 (work/'result.json').write_text(json.dumps(evidence,indent=2),encoding='utf-8');print(json.dumps({'work':str(work),**evidence},ensure_ascii=False),flush=True)


