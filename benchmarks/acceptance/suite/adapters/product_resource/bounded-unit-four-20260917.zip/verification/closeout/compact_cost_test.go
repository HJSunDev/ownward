package boundedstore

import (
 "context"
 "crypto/sha256"
 "database/sql"
 "encoding/hex"
 "encoding/json"
 "fmt"
 "os"
 "path/filepath"
 "testing"
 "time"
 "github.com/HJSunDev/ownward/internal/resourcebudget"
)

func TestCompactRealCost(t *testing.T) {
 ctx:=context.Background();root,_:=filepath.Abs("../../.tmp/bounded-unit4")
 sources,_:=filepath.Glob(filepath.Join(root,"materials14/questions/gpt4_a56e767c/ownward-data/stores/*/ownward.sqlite"))
 old,_:=filepath.Glob(filepath.Join(root,"cost-probe-*/measurement.json"));for _,m:=range old{paths,_:=filepath.Glob(filepath.Join(filepath.Dir(m),"stores/*/ownward.sqlite"));sources=append(sources,paths...)}
 out:=filepath.Join(root,"compact-cost-final");os.MkdirAll(out,0700)
 var results []map[string]any
 for i,source:=range sources {
  dir:=filepath.Join(out,fmt.Sprint(i));os.MkdirAll(dir,0700);path:=filepath.Join(dir,"ownward.sqlite")
  data,e:=os.ReadFile(source);if e!=nil{t.Fatal(e)};if _,e=os.Stat(path);!os.IsNotExist(e){t.Fatal("refuse overwrite",path)};if e=os.WriteFile(path,data,0600);e!=nil{t.Fatal(e)}
  inspect:=func(compact bool)map[string]any{
   db,e:=sql.Open("sqlite",path);if e!=nil{t.Fatal(e)};defer db.Close()
   var pages,free,sz,raw,org,vec int64
   for q,v:=range map[string]*int64{"PRAGMA page_count":&pages,"PRAGMA freelist_count":&free,"PRAGMA page_size":&sz,"SELECT coalesce(sum(length(bytes)),0) FROM content_chunks WHERE part=0":&raw,"SELECT coalesce(sum(length(bytes)),0) FROM organization_chunks":&org,"SELECT coalesce(sum(length(data)),0) FROM vectors":&vec}{if e=db.QueryRow(q).Scan(v);e!=nil{t.Fatal(e)}}
   tables:=map[string]int64{};rows,e:=db.Query("SELECT name,sum(pgsize) FROM dbstat GROUP BY name");if e!=nil{t.Fatal(e)};for rows.Next(){var k string;var v int64;rows.Scan(&k,&v);tables[k]=v};rows.Close()
   hashes:=map[string]string{}
   queries:=map[string]string{"raw":"SELECT payload,part,ordinal,bytes FROM content_chunks ORDER BY payload,part,ordinal","semantics":"SELECT organization,ordinal,bytes FROM organization_chunks ORDER BY organization,ordinal","vectors":"SELECT organization,data,digest FROM vectors ORDER BY organization","postings":"SELECT term,payload,frequency FROM postings ORDER BY term,payload"}
   if compact{queries["postings"]="SELECT p.term,i.payload,p.frequency FROM postings p JOIN lexical_payload_ids i ON i.id=p.payload ORDER BY p.term,i.payload"}
   for k,q:=range queries{rows,e:=db.Query(q);if e!=nil{t.Fatal(e)};cols,_:=rows.Columns();h:=sha256.New();enc:=json.NewEncoder(h);for rows.Next(){v:=make([]any,len(cols));ptr:=make([]any,len(cols));for j:=range v{ptr[j]=&v[j]};if e=rows.Scan(ptr...);e!=nil{t.Fatal(e)};enc.Encode(v)};if e=rows.Err();e!=nil{t.Fatal(e)};rows.Close();hashes[k]=hex.EncodeToString(h.Sum(nil))}
   return map[string]any{"sqlite_bytes":pages*sz,"free_bytes":free*sz,"raw_bytes":raw,"organization_bytes":org,"vector_bytes":vec,"tables":tables,"hashes":hashes}
  }
  before:=inspect(false);b,_:=resourcebudget.New(20*resourcebudget.MiB,resourcebudget.MiB);start:=time.Now();s,e:=Open(ctx,path,Options{Budget:b,paused:true});if e!=nil{t.Fatal(e)}
  if e=s.DrainMaintenance(ctx);e!=nil{t.Fatal(e)}
  // Return pages freed by the one-off format conversion, with bounded work.
  for {var free int64;s.writer.QueryRowContext(ctx,"PRAGMA freelist_count").Scan(&free);if free==0{break};rows,e:=s.writer.QueryContext(ctx,"PRAGMA incremental_vacuum(64)");if e!=nil{t.Fatal(e)};for rows.Next(){};e=rows.Err();rows.Close();if e!=nil{t.Fatal(e)};if _,e=s.writer.ExecContext(ctx,"PRAGMA wal_checkpoint(TRUNCATE)");e!=nil{t.Fatal(e)}}
  if e=s.Close();e!=nil{t.Fatal(e)};after:=inspect(true)
  same:=fmt.Sprint(before["hashes"])==fmt.Sprint(after["hashes"]);if !same{t.Fatal("information changed",before["hashes"],after["hashes"])}
  row:=map[string]any{"source":source,"before":before,"after":after,"exact":same,"upgrade_seconds":time.Since(start).Seconds()};results=append(results,row);fmt.Println(source, before["sqlite_bytes"],after["sqlite_bytes"])
 }
 bytes,_:=json.MarshalIndent(results,"","  ");os.WriteFile(filepath.Join(out,"summary.json"),bytes,0600)
}

