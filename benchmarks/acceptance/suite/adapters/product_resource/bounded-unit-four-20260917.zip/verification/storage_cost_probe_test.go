package performance

import (
 "database/sql"
 "encoding/json"
 "fmt"
 "os"
 "path/filepath"
 "testing"
 "time"
 "github.com/HJSunDev/ownward/internal/boundedstore"
 "github.com/HJSunDev/ownward/internal/resourcebudget"
)

func TestBoundedStorageCostProbe(t *testing.T) {
 for _,n:=range []int{80,160}{
  root,e:=os.MkdirTemp(filepath.Join("..","..",".tmp","bounded-unit4"),"cost-probe-");if e!=nil{t.Fatal(e)}
  root,_=filepath.Abs(root)
  raw,derived,old,e:=prepareReleaseFixture(t.Context(),root,n,512);if e!=nil{t.Fatal(e)}
  budget,_:=resourcebudget.New(20*resourcebudget.MiB,4*resourcebudget.MiB)
  start:=time.Now();s,e:=boundedstore.OpenDeployment(t.Context(),root,boundedstore.DeploymentOptions{Options:boundedstore.Options{Budget:budget}});if e!=nil{t.Fatal(e)}
  if e=s.DrainMaintenance(t.Context());e!=nil{t.Fatal(e)};if e=s.Close();e!=nil{t.Fatal(e)}
  paths,_:=filepath.Glob(filepath.Join(root,"stores","*","ownward.sqlite"));db,e:=sql.Open("sqlite",paths[0]);if e!=nil{t.Fatal(e)}
  var pages,free,pageSize int64;db.QueryRow("PRAGMA page_count").Scan(&pages);db.QueryRow("PRAGMA freelist_count").Scan(&free);db.QueryRow("PRAGMA page_size").Scan(&pageSize)
  tables:=map[string]int64{};rows,e:=db.Query("SELECT name,sum(pgsize) FROM dbstat GROUP BY name");if e!=nil{t.Fatal(e)}
  for rows.Next(){var name string;var b int64;rows.Scan(&name,&b);tables[name]=b};rows.Close();db.Close()
  result:=map[string]any{"items":n,"raw_asset_bytes":raw,"old_derived_bytes":derived,"old_total_bytes":old,"vector_bytes":n*512*4,"sqlite_bytes":pages*pageSize,"free_bytes":free*pageSize,"tables":tables,"migration_seconds":time.Since(start).Seconds()}
  data,_:=json.MarshalIndent(result,"","  ");os.WriteFile(filepath.Join(root,"measurement.json"),data,0600);fmt.Println(string(data))
 }
}
