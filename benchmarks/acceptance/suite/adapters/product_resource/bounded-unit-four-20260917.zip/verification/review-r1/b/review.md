# 有界存储单元四：首轮完整独立审查

结论：**整轮审查完成，changes_required。确认2项本单元缺陷，当前不能关闭单元四。** A应集中修复、自验，再交付固定修复版本供B完整复审。没有扩大到信息使用层优化、500题或真实用户资料迁移。

## 版本与边界

- 被审composition：`3face7f67cb4bdcca8c00e68abab9369cce37fe37fb813f25bdb1bc85cc10945`。
- 基线HEAD：`bea38d4d45e1777767608ddffd4fb109b4fb8fa7`，包括冻结时全部正式工作区变更。
- `../source-identity.json`所列387项文件在审查开始、结束均全部匹配；HEAD一致。见`initial-identity.json`、`final-identity.json`；结束核对时间2026-09-17 15:03:45 +08:00。
- 正式证据：`benchmarks/acceptance/suite/adapters/product_resource/bounded-unit-four-20260917.json`及同名ZIP。ZIP SHA-256：`69543c45ab7524ea932d7ad460a39d19bd3467de5eb4bbfa7b3a378a2d38e804`。
- B只写本审查目录，以Go overlay装入测试；未修改正式源码、权威文档、暂存区或Git历史。无外部AI调用，无真实用户资料操作。所有测试进程已结束，测试资源已释放。

## 必须修复的发现

### U4-B1 · P1：已激活目标缺失时，取消入口错误恢复旧资料权威

定位：`internal/boundedstore/deployment_cancel.go:64`，关联49–77行及`finishRollback`。

用户从旧资料迁移到新库，目标已耐久激活后发生中断；若目标文件随后不可用，明确执行取消迁移会成功，旧程序也能重新打开旧资料。架构§8.2明确要求激活后只允许向前恢复，目标不可用时进入恢复处理，不能重新开放旧权威；这也不以是否已有新业务写入为条件。

根因：`CancelDeployment`只在目标文件存在时读取并判断`storage_migration.activated`；目标不存在直接越过判断。只要旧源摘要仍一致，就登记rollback并删除活动指针、恢复旧清单。存在活动指针并没有成为拒绝未知激活状态的依据。在`activated`检查点中断时，激活标记已提交，迁移日志仍可能是validated，不能仅用这一日志阶段推断未激活。

独立复现：`review_probes_test.go`的`TestReview4MissingActivatedTargetCannotRollback`用合成旧资料，在正式`activated`检查点中断，再将测试专属目标文件改名保留以模拟不可用。调用真实`CancelDeployment`后，实际`assetlog.Open`旧入口也成功。`probe-results.jsonl`记录`cancel_error=<nil> legacy_open_error=<nil>`。这是维护API的可达反例，未声称存在已验证的CLI取消命令，也未声称该夹具已发生新用户数据丢失。

修复要求：只有能证明目标尚未激活、旧源完整时才允许恢复旧入口；目标状态不明时保留隔离与恢复现场。兼顾尚未创建目标等确实安全的早期取消，不用一概禁用取消代替正确状态判断。

必要验证：已激活目标正常、缺失、损坏均不得恢复旧入口；已确认未激活的取消仍成功；中断后的回退接续与旧入口隔离保持成立。

### U4-B2 · P2：被授权管理者能准备交接，却无法启动交接

定位：`cmd/ownward/service_runtime.go:508`、515；关闭运行时分支510也需要按请求身份核对。

用户授予另一连接管理权，该连接能够准备部署交接，但调用正式start入口时被拒绝。所有者路径正常，因此既有所有者交接测试不能覆盖此回归。

根因：新的SQLite控制读取是有界选择视图。`Control.State()`使用无请求凭据的读取，通常只带所有者等必要主体；start仍把它当完整权限状态交给`CheckHandoffManager`。合法管理者不在这一视图中，遂被判定无权限。关闭运行时后的`assembly.ReadControlAt`也是默认选择读取，不能忽略恢复路径。

独立复现：`TestReview4DelegatedManagerCanStartPreparedHandoff`初始化所有者，登记并授予非所有者read/manage权限，以该连接成功`PrepareHandoff`。同一上下文的`Control.HandoffManager`检查成功，而正式start使用的`CheckHandoffManager(ctx, c.State(), id)`返回拒绝。日志记录`scoped_manager_check=<nil> production_start_state_check=该连接未获准执行此操作`。复现执行了正式入口的确切授权函数链，未将它描述成实际HTTP端到端测试。

修复要求：start及运行时关闭后的恢复路径按当前请求凭据读取必要主体，或使用现有按请求授权的方法。保持有界读取与实时撤销检查，不恢复全主体加载，不放宽权限。

必要验证：所有者、获管理权的非所有者都能准备并启动；关闭运行时后的接续可用；权限被撤销或凭据无效时仍拒绝。

## 完整审查覆盖及正向结果

已对照产品需求、架构§8/10、单元四执行规格、数据说明和准备材料复用规则，沿正式调用检查：

| 范围 | 核查结论 |
| --- | --- |
| 迁移与新旧互斥 | 原目录锁、永久旧格式拒绝标记、迁移意图/隔离/构建/指针/激活/清理、源摘要、接续与取消均已检查；U4-B1为阻塞缺陷。 |
| 保真与复用 | 原文修订与删除账本、控制投影、旧v2/v3/v4/v5组织读取、引用/回执转换、依赖有效性、向量命名空间兼容及逐字节校验已检查；未发现需重复语义AI准备的依据。 |
| 正式存取和管理 | CLI、HTTP、连接器与流式产品装配，选取控制视图、主体列表、权限变更、遗忘屏障、维护接续、依据/预览/版本核验已检查。 |
| 备份与交接 | 默认备份派生隔离、归档校验、恢复标记与入口关闭、凭据失效、交接身份/回执保留、激活许可及旧部署退役已检查；U4-B2阻断合法管理者启动。 |
| 格式3与缓冲 | 词法整数ID转换与批次接续、旧表回收、检索连接与删除路径；8 KiB缓冲先入预算、磁盘配额、偏移、落盘、关闭释放及正式调用边界已检查。 |
| 交付证据 | 资源冷热条件、进程树内存、真实与合成磁盘样本、旧版本答题、最终工具回放及版本身份分别核查；适用范围如下。 |

B独立运行2次本地Go命令，未因夹具错误重跑，未追加全仓或整批题测试：

1. 两个定向诊断均复现产品缺陷，包耗时2.559秒，见`probe-results.jsonl`。运行：

   `go test -overlay .tmp/bounded-unit4/review-r1/b/overlay.json -p 1 -count=1 -timeout 45s -json ./internal/boundedstore -run '^TestReview4'`

2. **8项顶层正向测试、10项子测试全部通过**，无失败，见`positive-results.jsonl`。覆盖所有迁移耐久检查点、旧格式组织与默认备份隔离、格式3接续、权限撤销/登记/耐久性、正式Basic装配的存取/备份/遗忘、交接身份与回执、临时缓冲配额与落盘。3个包报告耗时分别6.690、2.051、1.354秒；这是测试包耗时，不是完整命令耗时或用户等待。运行：

   `go test -p 1 -count=1 -timeout 90s -json ./internal/boundedstore ./internal/assembly ./internal/resourcebudget -run '^(TestDeploymentResumesEveryDurableBoundary|TestDeploymentLegacySemanticFormatsAndBackupIsolation|TestCompactPostingsUpgradeAndResume|TestSelectedControlRevocationEnrollmentAndDurability|TestBoundedRuntimeControlChangesBackupAndReopen|TestBoundedHandoffKeepsIdentityAndReceipts|TestBufferedFileSpillPreservesOffsetsAndQuota|TestBufferedFileBudgetFallbackAndFailure)$'`

已有A全仓测试日志核查未见失败；不将A的运行表述为B重新执行。详细诊断假设、检查点见`probe-plan.md`。

## 性能与质量证据能支持什么

### 资源与磁盘

- 当前composition的固定20文档/20查询温态实测：进程树峰值210.52 MiB，private commit峰值167.42 MiB，非模型峰值49.58 MiB；低于270 MiB总上限与56 MiB非模型预算。
- 显式模型预热、4线程、无竞争探针条件下，文档平均311.70毫秒/项，查询p95为547毫秒，分别满足535/600毫秒阈值。这些是本地固定工作负载指标，**不包含外部智能语义组织，也不等于真实用户保存一题的全部等待**。
- 冷启动3次为2563、2859、2016毫秒；空资料库会跳过无意义的嵌入。冷首批文档697.65毫秒/项单独保留，不能冒称温态成绩。
- 8.39 MB长输入证据来自此前`92371fe9…`版本，且与诊断写入探针竞争；其耗时不能作为最终版本无竞争验收值。原文、依据和双形式保真及当时内存结果保留为限定证据。
- 48份真实资料物理库由8,749,056降至6,209,536字节，减少约29.03%，原文/组织/向量/词频摘要保持一致。派生编码比1.03不是整个SQLite文件除以原文的比例，不可混用。80/160份合成样本只支持相应规模的增长检查。
- B未重复资源压力或本地模型测量；不以本轮小型测试外推大库容量与最终500题可用性。

### 答题与最终回放

- 新答题与判分实际发生在`4e7a236fbf8a57434fe88a777a98a7664cec51f9ffc7216c76425cd5d9180094`：固定14题11/14、平均完整等待108.2869秒；固定24题24/24、平均完整等待71.1420秒，均无未完成题。不是当前`3face7…`重新答题的成绩，也不能当作原任务13/14且约60秒目标已完成。
- 当前版本的确定性回放覆盖38个案例、407次实际产品调用，结果全部相等，新增AI调用0；已直接核查归档summary与回放实现。游标不透明值重新绑定并执行接续；瞬态basis、generation等身份字段不做字面相等比较，其他结果字段比较。
- 这支持最终物理修改在已记录工具路径上的等价性，不等于对最终版本重新进行外部模型端到端作答及判分。14题既有失败保留原归因，未用题目专用规则修补；本轮不自动重跑付费模型或扩大题集。

## 交接要求

1. A集中处理U4-B1与U4-B2并自验，保存最简修复、新composition和验证依据；不得提前以局部修复插入多轮审查。
2. 当前正式证据的`unit_four_closed`及执行文档关闭表述不能覆盖本轮已确认缺陷；A负责同步真实阶段，并在修复版复审通过后关闭。
3. 复用已有保真、资源与质量证据并保留原测量身份；针对修改补必要验证，准确区分最终工具等价回放与此前模型成绩。
4. B本轮已完成，不再追加试验。修复版完整交付后，再按约定一次性复审。
