package boundedstore

import (
 "context"
 "errors"
 "os"
 "path/filepath"
 "testing"

 "github.com/HJSunDev/ownward/internal/assetlog"
 "github.com/HJSunDev/ownward/internal/contract"
 "github.com/HJSunDev/ownward/internal/informationcontrol"
)

func TestReview4MissingActivatedTargetCannotRollback(t *testing.T){
 ctx:=context.Background();root:=t.TempDir();legacyFixture(t,root)
 interrupted:=errors.New("review stop after activation")
 o:=deploymentOptions();o.checkpoint=func(phase string)error{if phase=="activated"{return interrupted};return nil}
 s,e:=OpenDeployment(ctx,root,o);if s!=nil{s.Close()};if !errors.Is(e,interrupted){t.Fatal("fixture did not reach activation",e)}
 var state migrationState;if e=readSmallJSON(filepath.Join(root,"migration.json"),&state);e!=nil{t.Fatal(e)}
 target:=filepath.Join(root,"stores",state.ID,"ownward.sqlite")
 if e=os.Rename(target,target+".unavailable");e!=nil{t.Fatal(e)}
 cancelError:=CancelDeployment(ctx,root)
 old,oldError:=assetlog.Open(filepath.Join(root,"assets"));if old!=nil{old.Close()}
 t.Logf("cancel_error=%v legacy_open_error=%v",cancelError,oldError)
 if cancelError==nil||oldError==nil{t.Error("an activated but unavailable target allowed rollback to the old authority")}
}

func TestReview4DelegatedManagerCanStartPreparedHandoff(t *testing.T){
 ctx:=context.Background();s,e:=Open(ctx,filepath.Join(t.TempDir(),"store.sqlite"),deploymentOptions().Options);if e!=nil{t.Fatal(e)};defer s.Close()
 a,e:=s.OpenControlAuthority(ctx,contract.ControlState{Schema:contract.ControlStateSchema,Revision:1,ActiveComposition:"composition",ActiveKernelGeneration:"kernel"});if e!=nil{t.Fatal(e)}
 c:=informationcontrol.New(a);owner,e:=c.InitializeOwner("owner");if e!=nil{t.Fatal(e)}
 ownerCtx:=informationcontrol.Authenticate(ctx,owner)
 p,token,e:=c.Enroll(ownerCtx,"delegated manager");if e!=nil{t.Fatal(e)}
 if e=c.SetPermissions(ownerCtx,p.ID,[]contract.Permission{contract.ReadPermission,contract.ManagePermission});e!=nil{t.Fatal(e)}
 manager:=informationcontrol.Authenticate(ctx,token)
 target:=contract.Location{ServiceID:"destination",SystemID:c.SystemID(),Endpoint:"https://example.test",Certificate:"test",Composition:"composition"}
 if _,e=c.PrepareHandoff(manager,"transfer",target);e!=nil{t.Fatal("manager could not prepare fixture",e)}
 direct:=c.HandoffManager(manager,"transfer")
 viaRuntimeState:=informationcontrol.CheckHandoffManager(manager,c.State(),"transfer")
 t.Logf("scoped_manager_check=%v production_start_state_check=%v",direct,viaRuntimeState)
 if direct!=nil{t.Fatal("positive authorization control failed",direct)}
 if viaRuntimeState!=nil{t.Error("the production start check rejects a currently authorized delegated manager")}
}
