Unit three final accepted source and independent review, 2026-09-17.
Base commit: 12dc34158b562488bc8b44a05966cb39a3324a44.
Final composition: 2e543a63555bfb235296273ede2d3de10c4b5526f04ad210c5780e64cae8e401.
Restore in a separate checkout of the base commit and overlay review/final-source/. It contains every final code change against that base and the closing documents. Verify the 345 source SHA256 entries in review/round2-source-hashes.json.
Final checks: go test -p 2 ./... -timeout=240s; go vet -p 2 ./...; go run ./cmd/ownward-composition verify.
review/a/ contains repair evidence and final repository checks. review/b/ contains both complete reviews and independent tests. Raw overlay paths identify the original local test environment; to replay them, extract the review files under .tmp/bounded-unit-three-review-20260917/ and replace the original workspace prefix with the reproduction checkout path.
The original source/ and verification/ entries remain the initial self-tested version. Its synthetic maintenance measurements belong to composition ea977db7cec47705f49ec41415d684ed6d82b3c2d5bbf24e23851b2306419fd4, not to the repaired version. There is no new whole-product RSS or user-latency measurement.
Unit three is closed. Existing user data migration and production activation remain unit four.