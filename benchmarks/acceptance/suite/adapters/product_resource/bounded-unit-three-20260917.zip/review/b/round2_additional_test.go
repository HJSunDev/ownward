package boundedstore

import (
 "context"
 "os"
 "path/filepath"
 "strings"
 "testing"
 "time"

 "github.com/HJSunDev/ownward/internal/derived"
 "github.com/HJSunDev/ownward/internal/domain"
 "github.com/HJSunDev/ownward/internal/resourcebudget"
 "github.com/HJSunDev/ownward/internal/semantics"
)

func TestReview3Round2LatePackAfterForgetBarrier(t *testing.T) {
 s:=retrievalStore(t);stopMaintenance(s)
 ctx,cancel:=context.WithTimeout(context.Background(),8*time.Second);defer cancel()
 if e:=s.CreateGeneration(ctx,"g","space");e!=nil{t.Fatal(e)}
 for i,id:=range []string{"a","b"}{
  putRetrievalAsset(t,s,domain.Information{ID:id,Revision:1,Content:"source "+id})
  vector:=make([]float32,512);vector[i]=1
  putRecord(t,s,derived.Record{AssetID:id,AssetRevision:1,Status:"ready",InputsKnown:true,EmbeddingSpace:"space",Embedding:vector,Analysis:semantics.Analysis{Summary:"source "+id}})
 }
 if e:=s.ActivateGeneration(ctx,"g","");e!=nil{t.Fatal(e)}
 drainTest(t,s)
 if e:=s.StageForget(ctx,"race-forget",[]ForgetTarget{{"a",1}});e!=nil{t.Fatal(e)}
 if e:=s.writeMu.acquire(ctx,controlWork);e!=nil{t.Fatal(e)}
 held:=true;defer func(){if held{s.writeMu.Unlock()}}()
 packed:=make(chan error,1)
 go func(){_,e:=s.PackVectors(ctx,"space",true);packed<-e}()
 waitQueued:=func(class workClass){
  t.Helper();deadline:=time.Now().Add(3*time.Second)
  for {s.writeMu.mu.Lock();ready:=s.writeMu.waiting[class]>0;s.writeMu.mu.Unlock();if ready{return};if time.Now().After(deadline){t.Fatal("fixture waiter did not reach gate",class)};time.Sleep(time.Millisecond)}
 }
 waitQueued(ordinaryWork)
 forgotten:=make(chan error,1)
 go func(){forgotten<-s.CommitForget(ctx,"race-forget")}()
 waitQueued(controlWork)
 s.writeMu.Unlock();held=false
 if e:=<-forgotten;e!=nil{t.Fatal(e)}
 packError:=<-packed
 if packError==nil||!strings.Contains(packError.Error(),"构块期间资料已变化"){t.Fatalf("late pack must reject stale input, got %v",packError)}
 drainTest(t,s)
 state,e:=s.ForgetState(ctx,"race-forget");if e!=nil{t.Fatal(e)}
 blocks:=countTest(t,s,"SELECT count(*) FROM vector_blocks")
 pages:=countTest(t,s,"SELECT count(*) FROM vector_filter_pages")
 vectors:=countTest(t,s,"SELECT count(*) FROM vectors")
 if state!="complete"||blocks!=0||pages!=0||vectors!=1{t.Fatalf("state=%s blocks=%d pages=%d vectors=%d",state,blocks,pages,vectors)}
 if got:=readTest(t,s,"b");got!="source b"{t.Fatal("surviving source changed",got)}
 query:=make([]float32,512);query[1]=1
 hits,_,e:=s.VectorSearch(ctx,"g","space",query,nil,10);if e!=nil{t.Fatal(e)}
 if len(hits)!=1||hits[0].ID!="b"{t.Fatal("surviving vector search",hits)}
 t.Logf("late_pack_rejected=true forget=%s blocks=%d pages=%d surviving_vectors=%d surviving_hit=%s",state,blocks,pages,vectors,hits[0].ID)
}

func TestReview3Round2RestoreMixedTargetsTwice(t *testing.T){
 s:=retrievalStore(t);ctx:=context.Background()
 if e:=s.PublishAccess(ctx,AccessHeader{System:"mixed-target-system",Revision:1},0,nil);e!=nil{t.Fatal(e)}
 for _,id:=range []string{"a","b","c","d"}{putRetrievalAsset(t,s,domain.Information{ID:id,Revision:1,Content:"source "+id})}
 if e:=s.StageForget(ctx,"first",[]ForgetTarget{{"a",1}});e!=nil{t.Fatal(e)}
 if e:=s.StageForget(ctx,"second",[]ForgetTarget{{"c",1}});e!=nil{t.Fatal(e)}
 snapshot,e:=s.Snapshot(ctx);if e!=nil{t.Fatal(e)}
 raw,e:=os.ReadFile(snapshot.Path);if e!=nil{t.Fatal(e)}
 external:=filepath.Join(t.TempDir(),"mixed-old.sqlite");if e=os.WriteFile(external,raw,0600);e!=nil{t.Fatal(e)}
 if e=s.StageForget(ctx,"first",[]ForgetTarget{{"b",1}});e!=nil{t.Fatal(e)}
 if e=s.CommitForget(ctx,"first");e!=nil{t.Fatal(e)}
 if e=s.CommitForget(ctx,"second");e!=nil{t.Fatal(e)}
 drainTest(t,s)
 for i:=0;i<2;i++{
  budget,_:=resourcebudget.New(16*resourcebudget.MiB,resourcebudget.MiB)
  restored,e:=s.RestoreSnapshot(ctx,StorageSnapshot{Path:external,SHA256:snapshot.SHA256},filepath.Join(t.TempDir(),"restored.sqlite"),Options{Budget:budget});if e!=nil{t.Fatal(e)}
  func(){defer restored.Close()
   live:=countTest(t,restored,"SELECT count(*) FROM live_assets")
   documents:=countTest(t,restored,"SELECT documents FROM lexical_stats")
   terms:=countTest(t,restored,"SELECT terms FROM lexical_stats")
   actual:=countTest(t,restored,"SELECT coalesce(sum(d.length),0) FROM lexical_documents d JOIN live_assets a ON a.payload=d.payload")
   if live!=1||documents!=live||terms!=actual{t.Errorf("restore=%d live=%d documents=%d terms=%d actual=%d",i,live,documents,terms,actual)}
   if got:=readTest(t,restored,"d");got!="source d"{t.Error("surviving source",got)}
   t.Logf("restore=%d live=%d documents=%d terms=%d actual=%d",i+1,live,documents,terms,actual)
  }()
 }
}
