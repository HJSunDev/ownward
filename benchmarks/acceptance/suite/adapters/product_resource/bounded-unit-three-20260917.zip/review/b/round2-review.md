# 有界存储单元三：第二轮独立复审

**结论：通过。首轮 5 项缺陷全部关闭；对修复及其直接影响的完整复审结束，未发现剩余阻塞项。B 本轮结束，A 可按既定范围完成单元三证据与状态收尾。**

## 固定版本

- composition：`2e543a63555bfb235296273ede2d3de10c4b5526f04ad210c5780e64cae8e401`
- 基线提交：`12dc34158b562488bc8b44a05966cb39a3324a44`
- 清单：`../round2-source-hashes.json`；审查前后均 **345/345 匹配**，无缺失、无变动。证据：`round2-initial-source-check.json`、`round2-final-source-check.json`。
- 相对首轮，仅 `backup.go`、`maintenance.go`、`organization.go`、`scheduler.go`、`vectors.go`、新增 `maintenance_regression_test.go` 和 composition 清单变化。五个实现文件已逐项对比首轮归档源码，直接调用、事务、回收队列及取消路径已复核。
- 当前协作规则与单元三边界保持有效；未重启旧任务，未进入单元四。

## 五项修复的结论

| 首轮发现 | 机制与验证结果 | 结论 |
| --- | --- | --- |
| U3-B1 / P1 遗忘后归块材料残留 | 删除组织成员前登记受影响块清理。原精确向量中仍有效的成员进入增量区，旧块/筛选页清除；小于普通重排阈值的共享块也处理。正式测试覆盖单成员、共享块、未归块、重启接续及剩余结果分数/顺序一致。新增发布检查拒绝构块期间变化的代际、成员或块状态。B 确定性交错探针确认：构块已取得旧数据，遗忘控制事务在首次落盘前插队，迟到构块被拒绝，随后遗忘完成，旧块与页均为 0，未遗忘向量及原文仍可用。 | 关闭 |
| U3-B2 / P2 合法管理上下文恢复失败 | 源实例继续执行管理授权及控制修订检查；只在目标内部维护移除源访问租约和源快照作用域，保留取消和预算。合法管理恢复成功，原文一致，目标旧凭据仍被拒绝；未放宽公开访问检查。 | 关闭 |
| U3-B3 / P2 永久失效候选不回收 | 在核对候选身份后，将永久失效拒绝与退休/回收登记放在同一事务；取消与暂时错误不退休有效候选。验证拒绝对象跨重启回收后版本、负载、队列均为 0，成功版本不变；已取消的有效候选保留并可重试成功。 | 关闭 |
| U3-B4 / P2 控制操作破坏轮换 | 控制仍优先，但不覆盖普通/维护的上次轮换类别。两个方向的控制插队测试及取消退出检查通过，无新增队列状态或资源占用。 | 关闭 |
| U3-B5 / P2 旧快照暂存遗忘导致统计错误 | 覆盖删除屏障前先扣除旧快照中已有、仍可见的暂存目标；后续新增目标逐项扣减，已隐藏目标不重复扣。单目标正式测试及 B 的混合目标、多个操作、两次恢复均通过；每次恢复 `live=1, documents=1, terms=3, actual=3`，剩余原文一致。 | 关闭 |

## 独立验证与复用证据

B 在固定最终源码执行 **1 次** Go 命令：7 项正式回归加 2 项独立补充测试，共 **9 项顶层测试全部通过**，含 4 个子案例；无失败、无重跑、无无效夹具。测试包耗时 **5.453 秒**，仅为本地合成存储测试运行耗时，不是用户保存、模型处理或完整产品等待时间，也不包含命令编译启动开销。

```text
go test -overlay .tmp/bounded-unit-three-review-20260917/b/round2-overlay.json -p 1 -count=1 -timeout 45s -json ./internal/boundedstore -run '^(TestReview3Round2|TestMaintenance(SharedVectorForgetAcrossRestart|CancelledOrganizationRemainsRetryable|ControlPreservesBothSchedulerTurns|ForgetRemovesPackedVectorMaterial|AuthenticatedSnapshotRestore|RejectedOrganizationGetsReclaimed|RestoreStagedForgetKeepsLexicalStatistics)$)'
```

实验前机制假设、区分证据、成本与检查点：`round2-probe-plan.md`。原始结果：`round2-tests.jsonl`。新增测试：`round2_additional_test.go`。overlay 只增加虚拟测试文件，未改实现；交错使用已有写入门及排队状态，不在源码插桩。

已读取并复用 A 的 `fix-probes.jsonl`、`regressions.log`、`bounded-tests.log`、`full-tests.log`、`vet.log`、`verify.json`。A 的最终全包 69.865 秒、全仓回归通过（其中 boundedstore 82.161 秒），以及 vet、composition 通过属于 A 的自验证据，B 未冒称独立重跑。原始探针回放日志中有 6 个顶层测试和 1 个包通过事件，不能把包事件计为第 7 项测试；这不影响本轮 B 已独立通过 9 项测试的结论。

## 范围、资源与剩余工作

- 第一轮已审的其他实现与本轮身份相同，其有效结论继续保留；本轮未出现需要扩大到全仓重复测试的新失败。
- 修复复用既有维护队列、原向量和精确检索路径，未增加模型步骤。构块仍采用既有有界工作区；新增 SQL 检查和恢复统计没有引入无界 Go 材料集合。通过结论不宣称未实测的普遍时延上限。
- 本轮外部 AI 调用 0、题集运行 0、语义资料准备 0；没有新完整产品 RSS 实测，不重标单元二旧资源测量。270 MiB 总上限及至少 8 MiB 余量仍适用，生产启用及相应整体接入验收归既定单元四范围。
- 首轮临时文件占用探针的通过结果保留；未独立确认的静态疑点不升级为阻塞，也不借此追加无边界的恢复实验。
- 所有 B 测试已退出，测试资源已释放。B 未修改正式文件、暂存区、提交历史或远端，未启动子代理或自动任务。
- A 下一步仅按既定职责保存该版本的实现、复现资料和本报告，更新单元三完成状态，然后停止本单元；不因本报告自动启动单元四、旧资料迁移、题集或新的性能优化。
