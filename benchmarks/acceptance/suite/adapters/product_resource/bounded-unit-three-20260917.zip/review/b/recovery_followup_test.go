package boundedstore

import (
 "context"
 "os"
 "path/filepath"
 "runtime"
 "testing"
 "time"

 "github.com/HJSunDev/ownward/internal/domain"
 "github.com/HJSunDev/ownward/internal/resourcebudget"
)

func TestReview3RestoreStagedForgetKeepsLexicalStatistics(t *testing.T) {
 s:=retrievalStore(t);ctx:=context.Background()
 if e:=s.PublishAccess(ctx,AccessHeader{System:"staged-forget-system",Revision:1},0,nil);e!=nil{t.Fatal(e)}
 for _,id:=range []string{"a","b"}{putRetrievalAsset(t,s,domain.Information{ID:id,Revision:1,Content:"source "+id})}
 if e:=s.StageForget(ctx,"staged-then-committed",[]ForgetTarget{{"a",1}});e!=nil{t.Fatal(e)}
 snapshot,e:=s.Snapshot(ctx);if e!=nil{t.Fatal(e)}
 raw,e:=os.ReadFile(snapshot.Path);if e!=nil{t.Fatal(e)}
 external:=filepath.Join(t.TempDir(),"old-staged.sqlite");if e=os.WriteFile(external,raw,0600);e!=nil{t.Fatal(e)}
 if e=s.CommitForget(ctx,"staged-then-committed");e!=nil{t.Fatal(e)}
 drainTest(t,s)
 b,_:=resourcebudget.New(16*resourcebudget.MiB,resourcebudget.MiB)
 restored,e:=s.RestoreSnapshot(ctx,StorageSnapshot{Path:external,SHA256:snapshot.SHA256},filepath.Join(t.TempDir(),"restored.sqlite"),Options{Budget:b});if e!=nil{t.Fatal(e)};defer restored.Close()
 live:=countTest(t,restored,"SELECT count(*) FROM live_assets")
 stats:=countTest(t,restored,"SELECT documents FROM lexical_stats")
 terms:=countTest(t,restored,"SELECT terms FROM lexical_stats")
 actualTerms:=countTest(t,restored,"SELECT coalesce(sum(d.length),0) FROM lexical_documents d JOIN live_assets a ON a.payload=d.payload")
 t.Logf("restored_live_assets=%d lexical_documents_stat=%d actual_terms=%d terms_stat=%d",live,stats,actualTerms,terms)
 if live!=1||stats!=live||terms!=actualTerms{t.Error("restoring a snapshot with staged forget targets corrupts retrieval corpus statistics")}
}

func TestReview3CleanupResumesAfterTransientCopyLock(t *testing.T) {
 if runtime.GOOS!="windows"{t.Skip("Windows sharing violation fixture")}
 s:=retrievalStore(t);ctx:=context.Background()
 if e:=s.PublishAccess(ctx,AccessHeader{System:"retry-system",Revision:1},0,nil);e!=nil{t.Fatal(e)}
 putRetrievalAsset(t,s,domain.Information{ID:"a",Revision:1,Content:"temporary sharing lock"})
 snapshot,e:=s.Snapshot(ctx);if e!=nil{t.Fatal(e)}
 held,e:=os.Open(snapshot.Path);if e!=nil{t.Fatal(e)};defer held.Close()
 if e=s.StageForget(ctx,"forget-locked-copy",[]ForgetTarget{{"a",1}});e!=nil{t.Fatal(e)}
 if e=s.CommitForget(ctx,"forget-locked-copy");e!=nil{t.Fatal(e)}
 deadline:=time.Now().Add(2*time.Second)
 var observed error
 for time.Now().Before(deadline){s.maintenanceMu.Lock();observed=s.maintenanceErr;s.maintenanceMu.Unlock();if observed!=nil&&len(s.maintenanceWake)==0{break};time.Sleep(time.Millisecond)}
 if observed==nil{t.Fatal("fixture did not produce a transient cleanup failure")}
 if e=held.Close();e!=nil{t.Fatal(e)}
 // No new user mutation is issued after the external sharing lock disappears.
 time.Sleep(100*time.Millisecond)
 s.maintenanceMu.Lock();remaining:=s.maintenanceErr;s.maintenanceMu.Unlock()
 state,e:=s.ForgetState(ctx,"forget-locked-copy");if e!=nil{t.Fatal(e)}
 queued:=len(s.maintenanceWake)
 t.Logf("external_lock_released=true pending_wakes=%d state_without_new_write=%s maintenance_error_persisted=%v wal_bytes=%d",queued,state,remaining!=nil,s.walBytes())
 drainTest(t,s)
 final,e:=s.ForgetState(ctx,"forget-locked-copy");if e!=nil{t.Fatal(e)}
 t.Logf("explicit_manual_drain_state=%s",final)
 if state=="cleaning"&&remaining!=nil&&queued==0&&final=="complete"{t.Error("worker has no retry trigger after a recoverable failure clears; explicit manual drain was required")}
}
