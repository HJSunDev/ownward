# 有界存储单元三：首轮独立审查

结论：本轮完整审查已结束，需集中修复后复审。确认 5 项本单元缺陷：1 项 P1、4 项 P2。不得以现有自验通过关闭单元三。

## 版本与范围

- composition：`ea977db7cec47705f49ec41415d684ed6d82b3c2d5bbf24e23851b2306419fd4`
- 基线提交：`12dc34158b562488bc8b44a05966cb39a3324a44`
- A 清单：`../round1-source-hashes.json`；B 审查前、后均 344/344 匹配，无缺失或变动，见 `initial-source-check.json`、`final-source-check.json`。
- A 复现包 SHA256 已核对：`653e81fff3164bb531ee3ff650bb1d40c5e5ebbc15adf34b3cfa68f6cf7004e4`。
- 依据：当前协作规则、产品需求、架构第 6～7 节、单元三执行边界和遗忘合同。覆盖维护与回收、发布交错、遗忘及防复活、WAL/公平调度、快照恢复、凭据、取消与资源释放、格式及 SQLite 驱动变更。
- B 未修改正式源码或权威文档，未操作 Git，未调用外部 AI，未准备语义资料，未运行题集，未启动子代理或自动任务。所有复现为本地合成数据和 Go overlay。测试运行均已结束。
- 不要求本轮完成单元四的旧资料迁移、用户界面接入或生产启用；受保护的部署快照也不按普通资产导出判断。

## U3-B1 · P1 · 遗忘显示完成后，归块向量及筛选数据仍残留

位置：`internal/boundedstore/maintenance.go:259`，关联 `maintenance_vectors.go:12`、`forget.go:165`。

用户遗忘已完成语义组织并归块的资料后，原向量行会被删除，但向量块头和筛选页未随之清理。组织回收直接删除 `vector_members`，没有持久化登记受影响块的清理；后续向量维护仅处理队列中的任务，最终仍可把遗忘标为 `complete`。

独立证据：`followup-results.jsonl` / `TestReview3ForgetRemovesPackedVectorMaterial`。单资料、单个 512 维向量，归块后先排空旧任务，再遗忘并排空维护：`forget_state=complete, raw_vectors=0, blocks=1, filter_pages=2`。残留块的 Center、Lo 可以逐维精确重建被遗忘的**归一化检索向量**；并非声称重建原文或未归一化输入。

修复要求：在删除成员关系前可靠登记并完成受影响块的清理；共享块须保留未遗忘成员并消除已遗忘成员的派生信息，空块应删除。普通低占用率重排阈值不能替代遗忘清理条件，遗忘完成必须等待相关工作完成。验证需覆盖归块/未归块、共享块以及中断接续，保持即时不可用与剩余资料可检索。

## U3-B2 · P2 · 合法管理上下文无法完成快照恢复

位置：`internal/boundedstore/backup.go:359`，关联该文件第 286 行的目标凭据失效处理。

已经通过源实例管理权限校验的调用者可以生成快照，却不能用同一合法上下文完成恢复。恢复先使目标旧凭据失效、递增删除代际，再把含**源实例访问租约**的上下文传给目标 `DrainMaintenance`；目标读路径以自己的状态重新检查该租约，返回 `ErrAccess`。

独立证据：`probe-results.jsonl` / `TestReview3AuthenticatedSnapshotRestore`。真实走 `BeginAccess(..., ManagePermission)` 后恢复报 `ErrAccess`；同一快照经既有可信内部上下文恢复成功，原文一致，旧凭据仍被拒绝。这区分了快照损坏与跨实例授权上下文错误。这里要求已有后端接口正确处理合法管理调用，不要求提前建设单元四界面。

修复要求：保留源端授权及恢复期间的有效性检查，目标内部恢复维护使用正确作用域的上下文。不得通过恢复旧凭据或放宽公开访问检查解决。

## U3-B3 · P2 · 永久失效的组织候选不能在正常运行中回收

位置：`internal/boundedstore/organization.go:444`，关联 `maintenance.go:139`。

已有后端支持两个同基线候选先后发布；第一个成功后，第二个因 CAS 失效被永久拒绝。拒绝路径只返回错误，没有结束候选所有权或登记回收，而正常维护仅回收较旧运行代际的 staging。失败候选因而留在当前代际的 ready 状态，直到后续其他代际变化或重启才有机会回收。

独立证据：`probe-results.jsonl` / `TestReview3RejectedOrganizationGetsReclaimed`。第二次发布返回“派生结果已被替换”，排空维护后仍有 `rejected_versions=1, retained_body_bytes=145188, reclaim_jobs=0`，成功发布的当前版本保持有效。此交错也是 A 自验覆盖的后端发布情形；不声称当前 `BeginForeground` 会让同一实例的所有公开产品调用并行。

修复要求：区分永久失效和可恢复的暂时失败，在现有所有权生命周期中可靠结束并回收永久失效候选；保留有效未提交候选、当前版本和允许重试的候选。验证失败对象被正常维护回收、成功对象不受影响及中断后可接续。

## U3-B4 · P2 · 控制操作打断普通写入与维护的轮换

位置：`internal/boundedstore/scheduler.go:80`，关联第 72、75 行。

当普通写入和维护都等待时，控制操作应优先，但不应抹掉两者上次轮到谁的记录。当前所有类别都覆盖 `g.last`。维护执行后插入一次控制操作，会再次优先维护，跳过已等待的普通写入；同样的交错可反复延迟普通工作。

独立证据：`followup-results.jsonl` / `TestReview3ControlsDoNotResetMaintenanceFairness`。先令维护占用门，再确认普通、维护、控制三类均已入队，释放后实际顺序为 `[control, maintenance, ordinary]`，预期应为 `[control, ordinary, maintenance]`。测试证明的是一次有界的错误轮换；无限饥饿是机制风险，未冒充真实用户长等待测量。

修复要求：控制优先的同时独立保留普通/维护的轮换历史，继续保证取消正确退出队列。验证带控制插队的双向轮换与取消。

## U3-B5 · P2 · 恢复带暂存遗忘记录的快照会留下错误检索统计

位置：`internal/boundedstore/backup.go:302`、`backup.go:318`。

快照允许在遗忘仅暂存、尚未提交时生成。若该遗忘随后在当前实例提交，再恢复这份旧快照，恢复覆盖删除账本时先将旧暂存操作改成 `cleaning`，其已存在的 targets 立即从 `live_assets` 隐藏；之后按 `live_assets` 扣减统计便扣不到这条资料。资料虽然正确遗忘，检索使用的文档总量和词项总量仍包含它。

独立证据：`recovery-followup-results.jsonl` / `TestReview3RestoreStagedForgetKeepsLexicalStatistics`。两条资料，暂存遗忘一条后快照，在源实例提交并完成清理，再恢复旧快照：`restored_live_assets=1, lexical_documents_stat=2, actual_terms=3, terms_stat=6`。结果影响恢复后相关性计算，不是原文复活。

修复要求：覆盖删除账本与统计变更应考虑目标快照原有的操作/目标状态，按正确可见性且仅扣减一次。验证旧快照不含暂存目标、已含暂存目标及多次恢复的统计一致性，不引入无界扫描或破坏防复活。

## 已保留的正向证据与结论边界

- 恢复对照确认原文完整、目标旧凭据无效；竞争发布的成功版本未被破坏。现有删除屏障、可见性过滤、分批回收和版本拒绝机制应保留。
- 读取了锁与事务、工作区准入、读取消、检查点以及驱动变更。SQLite 1.40.1 在取消时关闭已构造 rows 的改动可在本地固定依赖中核对；A 的全仓测试、7 项维护恢复专项、vet 和 composition 校验作为该版本已有自验证据复用，B 未重复冒充执行。
- `TestReview3CleanupResumesAfterTransientCopyLock` 通过：临时 Windows 文件占用解除后，在未新增用户写入的观测中遗忘已自动完成、错误已消除。**不据此报告后台重试缺陷，也不由一次通过证明全部恢复条件。** TRUNCATE busy 后的空闲完成路径仅有静态疑点，未取得独立失败证据，不列为第六项缺陷。
- A 的 40 次合成修订耗时 6.1785479 秒、WAL 峰值 8,597,824 字节，以及固定长读/控制案例的 WAL 31,798,736 字节、最大观测事务增长 607,096 字节，只证明相应工作负载；不是用户单次保存平均耗时，也不是普遍最大值。
- 本轮没有新的完整产品 RSS 或外部模型耗时测量。270 MiB 总内存与至少 8 MiB 独立余量仍是约束，不把单元二旧测量重标为本版本新测量。

## 复现、成本与审查纠偏

实验前假设、区分证据和成本记录于 `probe-plan.md`。Go 从仓库根执行，临时目录统一放本现场 `b/temp`；overlay 只增加虚拟测试文件。

| 原始输出 | overlay / run | 有效结论 |
| --- | --- | --- |
| `probe-results.jsonl` | `overlay.json` / `^TestReview3`，包超时 90 秒 | B2、B3 失败复现；初始向量夹具未设置 EmbeddingSpace，向量案例无效 |
| `vector-forget-results.jsonl` | `overlay.json` / `^TestReview3ForgetRemovesPackedVectorMaterial$`，包超时 30 秒 | 修正向量空间后证实残留；此时逐维比较器仍使用未归一化输入 |
| `followup-results.jsonl` | `overlay-followup.json` / `^TestReview3(ControlsDoNotResetMaintenanceFairness\|ForgetRemovesPackedVectorMaterial)$`，包超时 30 秒 | B1 的最终信息残留证据及 B4 失败复现 |
| `recovery-followup-results.jsonl` | `overlay-recovery.json` / `^TestReview3(RestoreStagedForgetKeepsLexicalStatistics\|CleanupResumesAfterTransientCopyLock)$`，包超时 30 秒 | B5 失败复现；临时文件占用案例通过 |

命令形式：`go test -overlay <overlay 路径> -p 1 -count=1 -timeout <上述超时> -json ./internal/boundedstore -run <上述表达式>`。包返回非零来自预期揭示的缺陷断言，不能据此称正式现有测试回归。

向量夹具的两次纠正均保留原输出，旧夹具分别存于 `review_probes_initial_test.go.txt`、`review_probes_pre_normalization_test.go.txt`；只重跑受影响的向量案例，没有重复 B2/B3 或重跑全仓。整个回合是 4 次本地 Go 命令，未隐藏无效夹具成本，未挑选通过重跑。初末身份校验时间为 09:19:31、09:37:17（北京时间），属于审查工作经过时间，不是产品运行耗时。

## 交接

A 收到本报告后集中处理 5 项问题，自验并保存新的整体版本身份，一次性交付 B 完整复审。保留现有通过的能力和证据；不启动题集、语义材料准备或单元四工作。本轮 B 测试已全部退出，正式源码保持冻结身份，资源交回 A。
