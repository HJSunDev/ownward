# 单元三首轮最小诊断

固定版本 ea977db7cec47705f49ec41415d684ed6d82b3c2d5bbf24e23851b2306419fd4，344项初始身份匹配。

1. 遗忘是否遗漏已归块的向量：正常发布并归块1个真实格式512维确定性向量，先排空既有队列，再遗忘并排空。观察完成状态、向量/块/筛选页；单成员块的中心与下界若仍等于原向量，是可区分的受控派生残留证据。预期应清除，保留即影响遗忘完成结论。
2. 恢复是否误带源授权上下文：同一快照分别经已认证管理上下文和已有可信内部上下文恢复；观察正常恢复与旧凭据拒绝。用于区分恢复材料问题与跨实例授权上下文问题，不改授权代码或放宽凭据合同。
3. 永久失败组织发布是否接入正常回收：两个同版本候选，先后发布令第二个永久失效；正常排空维护后检查失败负载和队列，保留当前成功版本。用于核实失败构建生命周期，不要求回收尚未提交的有效候选。

成本：只运行本地Go overlay测试，3个有区分力的定向案例；无外部AI、真实模型或新资料准备。测试上下文有界，整包90秒超时；一旦有具体失败先定位，不扩大题集。原源码冻结，所有复现放B现场。
Additional discriminator: a control transaction must take priority without erasing which ordinary/maintenance class last received its turn. Start with maintenance active, queue one writer of each class, then release; inspect the resulting bounded sequence. No sleeps outside bounded readiness checks, <= 2 s context.
The first vector residue probe compared the retained header with the unnormalized input; product PackVectors uses normalized retrieval vectors. Correct only the comparator to the actual existing normalization function and rerun the vector case once to establish the exact retained information; the original completion/residue failure already stands. Preserve both prior outputs and probe source versions.
A's static notes identify remaining recovery scenarios. Verify only the two directly discriminating cases: (1) a snapshot taken after StageForget but before CommitForget must restore current deletion without retaining the forgotten asset in lexical statistics; (2) a controlled snapshot temporarily held open by a Windows reader should resume cleanup when the lock closes without a new user mutation. For the latter, observe the worker's persisted error and empty wake channel, then use one explicit Drain as a positive control; do not interpret the 100 ms observation as a product latency SLA. Cost: two synthetic local fixtures, <= 30 s package timeout, no model or full suites. TRUNCATE-busy idle completion remains a static concern unless independently reproduced; do not label it separately confirmed.
