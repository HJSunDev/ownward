package boundedstore

import (
 "context"
 "testing"
 "time"
)

func TestReview3ControlsDoNotResetMaintenanceFairness(t *testing.T) {
 ctx,cancel:=context.WithTimeout(context.Background(),2*time.Second);defer cancel()
 var gate writeGate
 if e:=gate.acquire(ctx,maintenanceWork);e!=nil{t.Fatal(e)}
 acquired:=make(chan workClass,3)
 releases:=map[workClass]chan struct{}{ordinaryWork:make(chan struct{}),maintenanceWork:make(chan struct{}),controlWork:make(chan struct{})}
 completed:=make(chan struct{},3)
 for _,class:=range []workClass{ordinaryWork,maintenanceWork,controlWork}{
  go func(class workClass){defer func(){completed<-struct{}{}}();if e:=gate.acquire(ctx,class);e!=nil{return};acquired<-class;select{case <-releases[class]:case <-ctx.Done():};gate.Unlock()}(class)
 }
 wait:=time.NewTicker(time.Millisecond);defer wait.Stop()
 queued:=false
 for !queued{gate.mu.Lock();queued=gate.waiting[ordinaryWork]==1&&gate.waiting[maintenanceWork]==1&&gate.waiting[controlWork]==1;gate.mu.Unlock();if !queued{select{case <-wait.C:case <-ctx.Done():gate.Unlock();t.Fatal("waiters did not queue")}}}
 gate.Unlock()
 var order []workClass
 for range 3{select{case class:=<-acquired:order=append(order,class);close(releases[class]);case <-ctx.Done():t.Fatal("scheduler failed to progress")}}
 for range 3{<-completed}
 t.Logf("previous=maintenance, queued=ordinary+maintenance+control, actual=%v (0=control 1=maintenance 2=ordinary)",order)
 if order[0]!=controlWork{t.Error("control lost priority")}
 if order[1]!=ordinaryWork{t.Error("control reset alternation: maintenance received another turn before the waiting ordinary writer")}
}
