package boundedstore

import (
 "context"
 "encoding/json"
 "errors"
 "path/filepath"
 "strings"
 "testing"
 "time"

 "github.com/HJSunDev/ownward/internal/contract"
 "github.com/HJSunDev/ownward/internal/derived"
 "github.com/HJSunDev/ownward/internal/domain"
 "github.com/HJSunDev/ownward/internal/resourcebudget"
 "github.com/HJSunDev/ownward/internal/semantics"
)

func TestReview3ForgetRemovesPackedVectorMaterial(t *testing.T) {
 s:=retrievalStore(t);stopMaintenance(s);ctx:=context.Background()
 if e:=s.CreateGeneration(ctx,"g","space");e!=nil{t.Fatal(e)}
 putRetrievalAsset(t,s,domain.Information{ID:"a",Revision:1,Content:"one source to forget"})
 vector:=make([]float32,512);for i:=range vector{vector[i]=float32(i+1)/1024}
 putRecord(t,s,derived.Record{AssetID:"a",AssetRevision:1,Status:"ready",InputsKnown:true,EmbeddingSpace:"space",Embedding:vector,Analysis:semantics.Analysis{Summary:"one source"}})
 if e:=s.ActivateGeneration(ctx,"g","");e!=nil{t.Fatal(e)}
 if n,e:=s.PackVectors(ctx,"space",true);e!=nil||n!=1{t.Fatal(n,e)}
 drainTest(t,s)
 if n:=countTest(t,s,"SELECT count(*) FROM derived_reclaim");n!=0{t.Fatal("baseline queue not drained",n)}
 if e:=s.StageForget(ctx,"forget-vector",[]ForgetTarget{{"a",1}});e!=nil{t.Fatal(e)}
 if e:=s.CommitForget(ctx,"forget-vector");e!=nil{t.Fatal(e)}
 drainTest(t,s)
 state,e:=s.ForgetState(ctx,"forget-vector");if e!=nil{t.Fatal(e)}
 blocks:=countTest(t,s,"SELECT count(*) FROM vector_blocks")
 pages:=countTest(t,s,"SELECT count(*) FROM vector_filter_pages")
 vectors:=countTest(t,s,"SELECT count(*) FROM vectors")
 reconstructs:=false
 if blocks>0 {
  var data []byte
  if e=s.view(ctx,func(q queryer)error{return q.QueryRowContext(ctx,"SELECT header FROM vector_blocks LIMIT 1").Scan(&data)});e!=nil{t.Fatal(e)}
  var header vectorHeader;if e=json.Unmarshal(data,&header);e!=nil{t.Fatal(e)}
  reconstructs=true;for i,x:=range normalizeVector(vector){reconstructs=reconstructs&&header.Center[i]==float64(x)&&header.Lo[i]==float64(x)}
 }
 t.Logf("forget_state=%s raw_vectors=%d blocks=%d filter_pages=%d retained_header_exactly_reconstructs_vector=%v",state,vectors,blocks,pages,reconstructs)
 if state=="complete"&&(blocks!=0||pages!=0){t.Errorf("forget reported complete with packed derived material still present")}
}

func TestReview3AuthenticatedSnapshotRestore(t *testing.T) {
 s:=retrievalStore(t);ctx:=context.Background()
 principal:=contract.Principal{ID:"review-owner",Revision:1,CredentialDigest:strings.Repeat("b",64),Permissions:[]contract.Permission{contract.ReadPermission,contract.MaintainPermission,contract.ManagePermission}}
 if e:=s.PublishAccess(ctx,AccessHeader{System:"review-system",Revision:1},0,[]contract.Principal{principal});e!=nil{t.Fatal(e)}
 putRetrievalAsset(t,s,domain.Information{ID:"a",Revision:1,Content:"restore retained source"})
 authenticated,e:=s.BeginAccess(contract.WithAuthenticationDigest(ctx,principal.CredentialDigest),principal.CredentialDigest,contract.ManagePermission);if e!=nil{t.Fatal(e)}
 snapshot,e:=s.Snapshot(authenticated);if e!=nil{t.Fatal(e)}
 restoreCtx,cancel:=context.WithTimeout(authenticated,4*time.Second);defer cancel()
 b,_:=resourcebudget.New(16*resourcebudget.MiB,resourcebudget.MiB)
 restored,e:=s.RestoreSnapshot(restoreCtx,snapshot,filepath.Join(t.TempDir(),"authenticated.sqlite"),Options{Budget:b})
 if restored!=nil{restored.Close()}
 t.Logf("authenticated_restore_error=%v is_access_error=%v",e,errors.Is(e,ErrAccess))
 if e!=nil{t.Errorf("valid source manager could not complete restore: %v",e)}
 controlBudget,_:=resourcebudget.New(16*resourcebudget.MiB,resourcebudget.MiB)
 control,e:=s.RestoreSnapshot(ctx,snapshot,filepath.Join(t.TempDir(),"trusted-control.sqlite"),Options{Budget:controlBudget})
 if e!=nil{t.Fatal("trusted-context control also failed",e)};defer control.Close()
 if got:=readTest(t,control,"a");got!="restore retained source"{t.Fatal("control source mismatch")}
 if _,e=control.BeginAccess(ctx,principal.CredentialDigest,contract.ReadPermission);!errors.Is(e,ErrAccess){t.Fatal("old credential must stay invalid",e)}
 t.Log("same snapshot succeeds via trusted context and old credentials remain invalid")
}

func TestReview3RejectedOrganizationGetsReclaimed(t *testing.T) {
 s:=retrievalStore(t);stopMaintenance(s);ctx:=context.Background()
 if e:=s.CreateGeneration(ctx,"g","space");e!=nil{t.Fatal(e)}
 putRetrievalAsset(t,s,domain.Information{ID:"a",Revision:1,Content:"current source"})
 raw,_:=json.Marshal(derived.Record{AssetID:"a",AssetRevision:1,Status:"ready",InputsKnown:true,Analysis:semantics.Analysis{Summary:strings.Repeat("retained abandoned candidate ",5000)}})
 first,e:=s.StageOrganization(ctx,"g",StringSource(raw));if e!=nil{t.Fatal(e)}
 second,e:=s.StageOrganization(ctx,"g",StringSource(raw));if e!=nil{t.Fatal(e)}
 if e=s.PublishOrganization(ctx,first);e!=nil{t.Fatal(e)}
 rejection:=s.PublishOrganization(ctx,second);if rejection==nil{t.Fatal("rival was not rejected")}
 drainTest(t,s)
 left:=countTest(t,s,"SELECT count(*) FROM organizations WHERE id=?",second.ID)
 bytes:=countTest(t,s,"SELECT coalesce(sum(length(bytes)),0) FROM organization_chunks WHERE organization=?",second.ID)
 queue:=countTest(t,s,"SELECT count(*) FROM derived_reclaim WHERE id=?",second.ID)
 t.Logf("rejection=%v rejected_versions=%d retained_body_bytes=%d reclaim_jobs=%d",rejection,left,bytes,queue)
 if left!=0{t.Errorf("permanently rejected candidate was not reclaimed during normal maintenance")}
 current,e:=s.CurrentOrganization(ctx,"g","a");if e!=nil||current.ID!=first.ID{t.Fatal("current winner damaged",e)}
}


