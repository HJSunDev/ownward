Base: 12dc34158b562488bc8b44a05966cb39a3324a44
Restore in a separate checkout of that base, overlay source/ preserving relative paths, and verify source-sha256.json. No files are deleted by this overlay. Run go test -p 2 ./... -timeout=240s, go vet -p 2 ./..., and go run ./cmd/ownward-composition verify.
Final maintenance measurements were rerun after adding the retired-generation assertion; production sources were unchanged from the full repository run.
unit3-bounded-tests.log records the initial SQLite 1.39.1 cancellation handle leak. All final verification logs use 1.40.1.
No remote AI, semantic material preparation, question-suite result, fresh complete-product RSS, or existing-user migration acceptance is claimed.
