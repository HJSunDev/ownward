import ast,pathlib,struct,subprocess,os,psutil
root=pathlib.Path(__file__).resolve().parent
source=root/'source/llama.cpp-9d77fa172'; build=root/'runtime-build'
zig=next((root/'toolchain').glob('*/zig.exe'))
ns={'struct':struct}; tree=ast.parse((root/'build_runtime.py').read_text())
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='exports'],type_ignores=[]),'exports','exec'),ns)
names=[n for n in ns['exports'](build/'llama.dll') if n.startswith('llama_')]
deffile=build/'llama.def';deffile.write_text('LIBRARY llama.dll\nEXPORTS\n'+'\n'.join(names)+'\n')
env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(root/'zig-cache'))
psutil.Process().cpu_affinity([0,1])
def run(args):
 p=subprocess.run(args,env=env,creationflags=subprocess.CREATE_NO_WINDOW,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 print(p.stdout.decode(errors='replace'),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
run([str(zig),'dlltool','-m','i386:x86-64','-D','llama.dll','-d',str(deffile),'-l',str(build/'libllama.dll.a')])
args=[str(zig),'c++','-target','x86_64-windows-gnu','-std=c++17','-O2','-DLLAMA_SHARED','-DGGML_SHARED']
for d in ['include','ggml/include','vendor/cpp-httplib','vendor/nlohmann']:args+=['-I',str(source/d)]
args += [str(root/'embedding_host.cpp'),str(source/'vendor/cpp-httplib/httplib.cpp'),str(build/'libllama.dll.a'),str(build/'libggml.dll.a'),str(build/'libggml-base.dll.a'),'-lws2_32','-static-libstdc++','-o',str(root/'embedding-host.exe')]
run(args)
print('host build complete',flush=True)
