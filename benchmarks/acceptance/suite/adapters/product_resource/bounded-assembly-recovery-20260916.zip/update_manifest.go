//go:build ignore

package main
import("encoding/json";"os";"github.com/HJSunDev/ownward/internal/embedding")
func main(){p:=os.Args[1];b,e:=os.ReadFile(p);if e!=nil{panic(e)};var m embedding.Manifest;if e=json.Unmarshal(b,&m);e!=nil{panic(e)};m.Space.ID,e=embedding.ComputeSpaceID(m);if e!=nil{panic(e)};m.Legal.LegalMaterialsID,e=embedding.ComputeLegalMaterialsID(m);if e!=nil{panic(e)};b,e=json.MarshalIndent(m,"","  ");if e!=nil{panic(e)};if e=os.WriteFile(p,append(b,'\n'),0600);e!=nil{panic(e)}}
