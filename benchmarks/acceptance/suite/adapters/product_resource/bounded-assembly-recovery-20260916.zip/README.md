# Embedding allocation feasibility evidence — 2026-09-16

This is an isolated pre-implementation probe, not the production runtime or the complete bounded storage system. Root source: `158f73de243d09168c514fa927fc89ec7548a4bc`.

## Changes and controls

- `allocation.patch`: avoid allocating logits for the pinned EmbeddingGemma embedding-only graph. That graph does not produce logits. Model weights, precision, prefixes, 512-token context/batch, 768→512 projection, normalization and GGML compute DLLs stay unchanged.
- `embeddingprobe/process_windows.go`: launch without a console using `DETACHED_PROCESS`, retaining pipes and the Windows lifetime job. The probe also detaches the connector. This is separate from the allocation fix.
- `probe-model-factory.patch`: restrict the isolated build to EmbeddingGemma to avoid compiling unrelated models. This is NOT required by the allocation fix and is not a proposed production change.
- `embedding_host.cpp`: identical C-ABI HTTP wrapper in both controls and the patched run. It is a verification harness, not a replacement for the production server. The official server is MSVC-built; this machine's portable compiler cannot replace its internal C++ ABI with a GNU ABI DLL.
- The official DLL, same-compiler unpatched DLL and fixed DLL all returned the same 39 projected float32 vectors as the unmodified production server, checked by SHA-256. The same-compiler pair differs only in `has_logits` initialization.
- The service is a minimal MCP server plus modernc SQLite v1.39.1 (SQLite 3.50.4), three connections, 4 MiB configured page caches, and a touched/held 5 MiB workspace. The latter represents capacity, not implemented retrieval/control operations. The connector uses copied production sources with only main/service discovery redirected to the isolated server.

## Reproduce

Extract this archive to `.tmp/bounded-assembly-recovery-20260916` in the source checkout. Go 1.25.5, Python with psutil and Windows x64 are required. The production model bundle used by the probe is at `.tmp/work-package-3/release-final/bin/embedding`; if that local build is absent, provide an identical verified bundle at that path. `bundle-manifest-original.json` fixes its model, runtime and legal file hashes.

1. Download `https://codeload.github.com/ggml-org/llama.cpp/tar.gz/9d77fa172` to `llama-source.tar.gz` and extract to `source/llama.cpp-9d77fa172`. SHA-256: `b83890db3d902d4c49d5ee638bade9967011beca56bbd803173689f615c2a9c3`.
2. Download `https://ziglang.org/download/0.14.1/zig-x86_64-windows-0.14.1.zip` and extract under `toolchain/`. SHA-256: `554f5378228923ffd558eac35e21af020c73789d87afeabf4bfd16f2e6feed2c`.
3. From the probe directory: `go build -o recovery.exe main.go` and `go build -o connector.exe ./connector`. Build only these targets; other Go helpers are not production entry points.
4. Run `python build_runtime.py`, `python build_host.py`, `python package_hosts.py`, then `python build_control.py`. Packaging recalculates manifest hashes and space identity, without disabling validation or modifying the original bundle.
5. From this directory run `python recovery_monitor.py compiler-control-workspace-checked`, then `python recovery_monitor.py patched-workspace-checked`. The monitor also accepts `control-workspace-checked` to use the official DLL in the same wrapper. Runs are sequential, with two model threads. The monitor reads this directory from its own location.
6. Compare all six `vector_sha256` values and `database_checks.passed`; inspect each run's `exit_code`, sampled process tree RSS, model peak working set and private committed memory. An observer process exit of zero alone does not mean the probe passed.

The archive includes original production-server output hashes and the three controlled runs. No API keys, user corpus, model, toolchain or executable binaries are included. The repository summary records archive integrity.

## Acceptance boundary

The unused output allocation has a causal fix and the isolated corrected assembly fits the 270 MiB bound with an additional 8 MiB margin. This does not certify the unbuilt production assembly. Production integration must rebuild a consistent runtime distribution, regenerate artifact identity, and repeat the whole-process check; the C-ABI wrapper and model-factory reduction must not silently become the product. Full streaming ingress/egress, retrieval I/O and maintenance under load still require their planned pre-implementation checks.
