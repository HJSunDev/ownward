import json,pathlib,subprocess,time,psutil,os,sys
root=pathlib.Path(__file__).resolve().parent
repo=root.parent.parent
mode=sys.argv[1]
binary='baseline.exe' if mode.startswith('baseline') else ('native.exe' if mode.startswith('native') else 'recovery.exe')
bundle=repo/'.tmp/work-package-3/release-final/bin/embedding'
if mode.startswith('patched'):bundle=root/'patched-bundle'
if mode.startswith('control'):bundle=root/'control-bundle'
if mode.startswith('compiler-control'):bundle=root/'compiler-control-bundle'
env=dict(os.environ,GOMAXPROCS='2')
if 'workspace' in mode:env['PROBE_WORKSPACE_MIB']='5'
if 'checked' in mode:env['PROBE_DATABASE_CHECKS']='1'
if 'gc' in mode:env.update(GOGC='25',GOMEMLIMIT='16MiB')
flags=subprocess.DETACHED_PROCESS|subprocess.CREATE_NEW_PROCESS_GROUP if mode!='baseline-no-window' else subprocess.CREATE_NO_WINDOW
p=subprocess.Popen([str(root/binary),str(bundle),str(root/'probe.sqlite'),str(root/'connector.exe')],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,creationflags=flags)
samples=[];start=time.monotonic()
try:
 while p.poll() is None:
  members=[]
  try:
   proc=psutil.Process(p.pid)
   for child in [proc,*proc.children(recursive=True)]:
    try:
     m=child.memory_info();members.append({'pid':child.pid,'ppid':child.ppid(),'name':child.name(),'rss':m.rss,'peak_rss':getattr(m,'peak_wset',None),'private':getattr(m,'private',None),'created':child.create_time()})
    except psutil.Error:pass
  except psutil.Error:pass
  samples.append({'s':time.monotonic()-start,'rss':sum(x['rss'] for x in members),'processes':members})
  if time.monotonic()-start>60:raise TimeoutError('bounded probe exceeded 60s')
  time.sleep(.02)
 stdout,stderr=p.communicate()
 out={'mode':mode,'exit_code':p.returncode,'elapsed_s':time.monotonic()-start,'stdout':stdout.decode(errors='replace'),'stderr':stderr.decode(errors='replace'),'peak':max(samples,key=lambda x:x['rss']) if samples else {},'samples':samples}
 (root/(mode+'.json')).write_text(json.dumps(out,indent=2),encoding='utf-8')
 print(json.dumps({k:v for k,v in out.items() if k!='samples'}))
finally:
 if p.poll() is None:
  for c in psutil.Process(p.pid).children(recursive=True):c.kill()
  p.kill();p.wait()
