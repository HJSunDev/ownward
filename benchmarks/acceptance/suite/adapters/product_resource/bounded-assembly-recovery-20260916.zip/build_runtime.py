import concurrent.futures,hashlib,json,os,pathlib,struct,subprocess,time,threading
root=pathlib.Path(__file__).resolve().parent
repo=root.parent.parent
source=root/'source/llama.cpp-9d77fa172'
zig=next((root/'toolchain').glob('*/zig.exe'))
runtime=repo/'.tmp/work-package-3/release-final/bin/embedding/runtime'
build=root/'runtime-build';build.mkdir(exist_ok=True)
env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(root/'zig-cache'))
flags=subprocess.CREATE_NO_WINDOW
def run(args,log):
 p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=env,creationflags=flags)
 log.write_bytes(p.stdout)
 if p.returncode:raise RuntimeError(f'{log.name}: '+p.stdout.decode(errors='replace')[-3000:])
 return p
def exports(path):
 data=path.read_bytes();pe=struct.unpack_from('<I',data,60)[0];sections=struct.unpack_from('<H',data,pe+6)[0];opt=pe+24;size=struct.unpack_from('<H',data,pe+20)[0]
 def offset(rva):
  for i in range(sections):
   at=opt+size+40*i;vs,va,rs,rp=struct.unpack_from('<IIII',data,at+8)
   if va<=rva<va+max(vs,rs):return rp+rva-va
  return rva
 er=struct.unpack_from('<I',data,opt+112)[0];eo=offset(er);count=struct.unpack_from('<I',data,eo+24)[0];nr=struct.unpack_from('<I',data,eo+32)[0]
 out=[]
 for i in range(count):
  at=offset(struct.unpack_from('<I',data,offset(nr)+4*i)[0]);end=data.index(b'\0',at);out.append(data[at:end].decode())
 return out
for name in ['ggml','ggml-base']:
 deffile=build/(name+'.def');deffile.write_text('LIBRARY '+name+'.dll\nEXPORTS\n'+'\n'.join(exports(runtime/(name+'.dll')))+'\n')
 out=build/('lib'+name+'.dll.a')
 if not out.exists():run([str(zig),'dlltool','-m','i386:x86-64','-D',name+'.dll','-d',str(deffile),'-l',str(out)],build/(name+'-import.log'))
p=source/'src/llama-context.cpp'
text=p.read_text(encoding='utf-8')
old='bool has_logits     = true;'
new='bool has_logits     = !(cparams.embeddings && model.arch == LLM_ARCH_GEMMA_EMBEDDING);'
if old in text:
 assert text.count(old)==1
 p.write_text(text.replace(old,new),encoding='utf-8')
# The isolated probe accepts only the already-pinned EmbeddingGemma model.
# Keep this build reduction separate from the allocator fix in the evidence.
model=source/'src/llama-model.cpp';text=model.read_text(encoding='utf-8')
start=text.index('static llama_model * llama_model_mapping(');brace=text.index('{',start);depth=1;end=brace+1
while depth:
 depth+=(text[end]=='{')-(text[end]=='}');end+=1
body='''{
    if (arch == LLM_ARCH_GEMMA_EMBEDDING) return new llama_model_gemma_embedding(params);
    throw std::runtime_error("isolated probe supports only the pinned EmbeddingGemma model");
}'''
if text[brace:end]!=body:model.write_text(text[:brace]+body+text[end:],encoding='utf-8')
sources=sorted((source/'src').glob('*.cpp'))+[source/'src/models/gemma-embedding.cpp']
base=[str(zig),'c++','-target','x86_64-windows-gnu','-std=c++17','-O2','-DNDEBUG','-DLLAMA_BUILD','-DLLAMA_SHARED','-DGGML_SHARED','-DGGML_BACKEND_DL','-DLLAMA_VERSION="b10488-ownward-embedding-buffer1"','-DLLAMA_COMMIT="9d77fa172"']
for p in [source/'include',source/'src',source/'ggml/include',source/'ggml/src']:base+=['-I',str(p)]
started=time.monotonic();stop=threading.Event()
def compile(p):
 if stop.is_set():return None
 obj=build/(('models-' if p.parent.name=='models' else '')+p.stem+'.o')
 if not obj.exists() or p.stat().st_mtime>obj.stat().st_mtime:
  try:run(base+['-c',str(p),'-o',str(obj)],obj.with_suffix('.log'))
  except BaseException:stop.set();raise
 return obj
objects=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 futures=[pool.submit(compile,p) for p in sources]
 for i,f in enumerate(concurrent.futures.as_completed(futures),1):
  obj=f.result()
  if obj is not None:objects.append(obj)
  if i==1 or i%12==0 or i==len(sources):print(json.dumps({'compiled':i,'total':len(sources),'seconds':round(time.monotonic()-started,1)}),flush=True)
response=build/'link.rsp'
args=['-target','x86_64-windows-gnu','-shared','-O2','-static-libstdc++','-o',str(build/'llama.dll')]+[str(x) for x in objects]+[str(build/'libggml.dll.a'),str(build/'libggml-base.dll.a')]
response.write_text(' '.join('"'+a.replace('\\','/')+'"' for a in args),encoding='utf-8')
run([str(zig),'c++','@'+str(response)],build/'link.log')
print(json.dumps({'built':str(build/'llama.dll'),'bytes':(build/'llama.dll').stat().st_size,'seconds':round(time.monotonic()-started,1)}),flush=True)
