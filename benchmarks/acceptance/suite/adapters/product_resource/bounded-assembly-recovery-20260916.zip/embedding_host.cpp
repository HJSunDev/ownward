// Isolated C-ABI embedding host for allocator verification; not a product server.
#include "llama.h"
#include "ggml-backend.h"
#include "httplib.h"
#include "json.hpp"
#include <cmath>
#include <cstring>
#include <vector>
#include <string>
#include <stdexcept>
using json=nlohmann::ordered_json;
int main(int argc,char**argv){
 std::string path,host="127.0.0.1";int port=0,threads=2;
 for(int i=1;i<argc;i++){std::string a=argv[i];if(a=="-m")path=argv[++i];else if(a=="--host")host=argv[++i];else if(a=="--port")port=std::stoi(argv[++i]);else if(a=="--threads")threads=std::stoi(argv[++i]);}
 if(path.empty()||port<=0)return 2;
 llama_log_set([](ggml_log_level,const char*,void*){},nullptr);
 ggml_backend_load_all();llama_backend_init();
 auto mp=llama_model_default_params();mp.n_gpu_layers=0;
 auto*model=llama_model_load_from_file(path.c_str(),mp);if(!model)return 3;
 auto cp=llama_context_default_params();cp.n_ctx=512;cp.n_batch=512;cp.n_ubatch=512;cp.n_seq_max=1;cp.n_threads=threads;cp.n_threads_batch=threads;cp.embeddings=true;cp.pooling_type=LLAMA_POOLING_TYPE_MEAN;
 auto*ctx=llama_init_from_model(model,cp);if(!ctx)return 4;
 const auto*vocab=llama_model_get_vocab(model);
 httplib::Server server;server.new_task_queue=[](){return new httplib::ThreadPool(1);};server.set_payload_max_length(1024*1024);
 server.Get("/health",[](const httplib::Request&,httplib::Response&r){r.set_content("{\"status\":\"ok\"}","application/json");});
 server.Post("/v1/embeddings",[&](const httplib::Request&r,httplib::Response&response){try{
  auto in=json::parse(r.body);auto inputs=in.at("input").get<std::vector<std::string>>();if(inputs.size()>32)throw std::runtime_error("batch too large");json data=json::array();int index=0;
  for(const auto&text:inputs){
   std::vector<llama_token> tokens(513);int n=llama_tokenize(vocab,text.data(),int(text.size()),tokens.data(),int(tokens.size()),true,true);
   if(n<1||n>512)throw std::runtime_error("input outside context");
   auto batch=llama_batch_init(n,0,1);batch.n_tokens=n;
   for(int i=0;i<n;i++){batch.token[i]=tokens[i];batch.pos[i]=i;batch.n_seq_id[i]=1;batch.seq_id[i][0]=0;batch.logits[i]=true;}
   auto memory=llama_get_memory(ctx);if(memory)llama_memory_clear(memory,true);
   int rc=llama_decode(ctx,batch);llama_batch_free(batch);if(rc!=0)throw std::runtime_error("embedding evaluation failed");
   float*raw=llama_get_embeddings_seq(ctx,0);if(!raw)throw std::runtime_error("missing pooled embedding");
   int dimensions=llama_model_n_embd(model);std::vector<float> out(dimensions);double sum=0;for(int i=0;i<dimensions;i++)sum+=raw[i]*raw[i];sum=std::sqrt(sum);const float norm=sum>0?1.0/sum:0.0f;for(int i=0;i<dimensions;i++)out[i]=raw[i]*norm;
   data.push_back({{"index",index++},{"embedding",out}});
  }
  response.set_content(json({{"data",data}}).dump(),"application/json");
 }catch(const std::exception&e){response.status=400;response.set_content(json({{"error",e.what()}}).dump(),"application/json");}});
 bool ok=server.listen(host,port);llama_free(ctx);llama_model_free(model);llama_backend_free();return ok?0:5;
}
