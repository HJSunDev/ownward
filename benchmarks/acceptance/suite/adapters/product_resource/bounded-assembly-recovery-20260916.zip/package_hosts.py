import pathlib,os,shutil,json,hashlib,subprocess
root=pathlib.Path(__file__).resolve().parent;repo=root.parent.parent
original=repo/'.tmp/work-package-3/release-final/bin/embedding'
host=root/'embedding-host.exe'
for kind in ['control','patched']:
 target=root/(kind+'-bundle');target.mkdir(exist_ok=True)
 for p in original.rglob('*'):
  if not p.is_file():continue
  rel=p.relative_to(original);out=target/rel;out.parent.mkdir(parents=True,exist_ok=True)
  if rel.as_posix() in ['manifest.json','runtime/llama.dll','runtime/llama-server.exe']:continue
  if not out.exists():os.link(p,out)
 dll=original/'runtime/llama.dll' if kind=='control' else root/'runtime-build/llama.dll'
 for src,name in [(host,'llama-server.exe'),(dll,'llama.dll')]:
  out=target/'runtime'/name
  if out.exists():out.unlink()
  shutil.copy2(src,out)
 m=json.loads((original/'manifest.json').read_text(encoding='utf-8'))
 m['capability']+='-c-api-'+kind+'-probe'
 for name in ['llama-server.exe','llama.dll']:m['runtime']['files']['runtime/'+name]=hashlib.sha256((target/'runtime'/name).read_bytes()).hexdigest()
 if kind=='patched':m['runtime']['source_archive_sha256']=hashlib.sha256((root/'llama-source.tar.gz').read_bytes()).hexdigest()
 (target/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 subprocess.run(['go','run','update_manifest.go',str(target/'manifest.json')],cwd=root,check=True)
 print(kind,flush=True)
