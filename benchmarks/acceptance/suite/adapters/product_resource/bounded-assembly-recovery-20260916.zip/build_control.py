import pathlib,os,subprocess,shutil,json,hashlib,psutil
root=pathlib.Path(__file__).resolve().parent;source=root/'source/llama.cpp-9d77fa172';build=root/'runtime-build'
zig=next((root/'toolchain').glob('*/zig.exe'));env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(root/'zig-cache'))
psutil.Process().cpu_affinity([0,1])
fixed=source/'src/llama-context.cpp';probe=root/'llama-context-control.cpp'
text=fixed.read_text();new='bool has_logits     = !(cparams.embeddings && model.arch == LLM_ARCH_GEMMA_EMBEDDING);'
assert text.count(new)==1;probe.write_text(text.replace(new,'bool has_logits     = true;'),encoding='utf-8')
def run(args):
 p=subprocess.run(args,env=env,creationflags=subprocess.CREATE_NO_WINDOW,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 print(p.stdout.decode(errors='replace'),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
args=[str(zig),'c++','-target','x86_64-windows-gnu','-std=c++17','-O2','-DNDEBUG','-DLLAMA_BUILD','-DLLAMA_SHARED','-DGGML_SHARED','-DGGML_BACKEND_DL','-DLLAMA_VERSION="b10488-ownward-embedding-buffer1"','-DLLAMA_COMMIT="9d77fa172"']
for p in [source/'include',source/'src',source/'ggml/include',source/'ggml/src']:args+=['-I',str(p)]
run(args+['-c',str(probe),'-o',str(build/'llama-context-control.o')])
old=(build/'link.rsp').read_text();new=old.replace('llama-context.o','llama-context-control.o').replace('/llama.dll"','/llama-control.dll"')
assert new!=old;(build/'link-control.rsp').write_text(new)
run([str(zig),'c++','@'+str(build/'link-control.rsp')])
target=root/'compiler-control-bundle';target.mkdir(exist_ok=True)
for p in (root/'control-bundle').rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(root/'control-bundle');out=target/rel;out.parent.mkdir(parents=True,exist_ok=True)
 if rel.as_posix() in ['manifest.json','runtime/llama.dll']:continue
 if not out.exists():os.link(p,out)
out=target/'runtime/llama.dll'
if out.exists():out.unlink()
shutil.copy2(build/'llama-control.dll',out)
m=json.loads((root/'control-bundle/manifest.json').read_text());m['capability']+='-same-compiler';m['runtime']['files']['runtime/llama.dll']=hashlib.sha256(out.read_bytes()).hexdigest()
m['runtime']['source_archive_sha256']=hashlib.sha256((root/'llama-source.tar.gz').read_bytes()).hexdigest()
(target/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
subprocess.run(['go','run','update_manifest.go',str(target/'manifest.json')],cwd=root,check=True)
print('same compiler control complete',flush=True)
