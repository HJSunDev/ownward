package main

import (
 "bufio"
 "context"
 "crypto/sha256"
 "encoding/binary"
 "math"
 "runtime"
 "strconv"
 "io"
 "net"
 "net/http"
 "os/exec"
 "path/filepath"
 "github.com/modelcontextprotocol/go-sdk/mcp"
 "database/sql"
 "encoding/json"
 "fmt"
 "os"
 "strings"
 "syscall"
 "time"

 embedding "github.com/HJSunDev/ownward/probes/bounded/embeddingprobe"
 _ "modernc.org/sqlite"
)

func check(err error) { if err!=nil { panic(err) } }
func event(name string, values map[string]any) { values["stage"]=name; values["at"]=time.Now().Format(time.RFC3339Nano); check(json.NewEncoder(os.Stdout).Encode(values)) }
func main(){
 ctx:=context.Background()
 db,e:=sql.Open("sqlite",os.Args[2]);check(e);defer db.Close();db.SetMaxOpenConns(3)
 var cs []*sql.Conn
 for i:=0;i<3;i++ { c,e:=db.Conn(ctx);check(e);cs=append(cs,c);defer c.Close();cache:=1024;if i==0{cache=2048};for _,s:=range []string{"PRAGMA page_size=16384","PRAGMA auto_vacuum=INCREMENTAL","PRAGMA journal_mode=WAL","PRAGMA synchronous=FULL","PRAGMA mmap_size=0","PRAGMA temp_store=FILE",fmt.Sprintf("PRAGMA cache_size=-%d",cache)} { _,e=c.ExecContext(ctx,s);check(e) } }
 _,e=cs[0].ExecContext(ctx,"CREATE TABLE IF NOT EXISTS samples(id INTEGER PRIMARY KEY, data BLOB)");check(e)
 for i:=0;i<40;i++ { _,e=cs[0].ExecContext(ctx,"INSERT OR REPLACE INTO samples VALUES(?,zeroblob(65536))",i);check(e) }
 event("sqlite_ready",map[string]any{"connections":3})
 if os.Getenv("PROBE_DATABASE_CHECKS")=="1" { verifyDatabase(ctx,cs) }
 var workspace []byte
 if n,_:=strconv.Atoi(os.Getenv("PROBE_WORKSPACE_MIB"));n>0 { workspace=make([]byte,n<<20);for i:=range workspace{workspace[i]=byte(i)};event("workspace_ready",map[string]any{"bytes":len(workspace)}) }
 if len(os.Args)>3 {
  srv:=mcp.NewServer(&mcp.Implementation{Name:"bounded-probe",Version:"1"},nil)
  handler:=mcp.NewStreamableHTTPHandler(func(*http.Request)*mcp.Server{return srv},&mcp.StreamableHTTPOptions{JSONResponse:true})
  listener,e:=net.Listen("tcp","127.0.0.1:0");check(e)
  server:=&http.Server{Handler:http.HandlerFunc(func(w http.ResponseWriter,r *http.Request){if strings.HasSuffix(r.URL.Path,"identity"){w.Header().Set("Content-Type","application/json");_,_=io.WriteString(w,`{"system_id":"isolated-feasibility"}`);return};handler.ServeHTTP(w,r)})}
  go server.Serve(listener);defer server.Close()
  connector:=exec.Command(os.Args[3],"http://"+listener.Addr().String(),filepath.Dir(os.Args[2]))
  connector.SysProcAttr=&syscall.SysProcAttr{HideWindow:true,CreationFlags:0x00000008}
  connector.Env=append(os.Environ(),"APPDATA="+filepath.Join(filepath.Dir(os.Args[2]),"isolated-appdata"))
  input,e:=connector.StdinPipe();check(e);output,e:=connector.StdoutPipe();check(e);connector.Stderr=os.Stderr
  check(connector.Start());defer func(){input.Close();connector.Wait()}()
  _,e=io.WriteString(input,`{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-06-18","capabilities":{},"clientInfo":{"name":"isolated-probe","version":"1"}}}`+"\n");check(e)
  line,e:=bufio.NewReader(output).ReadBytes('\n');check(e);var reply map[string]any;check(json.Unmarshal(line,&reply));if reply["error"]!=nil{panic(string(line))}
  event("connector_ready",map[string]any{"pid":connector.Process.Pid})
 }

 m,e:=embedding.OpenManaged(os.Args[1]);check(e);defer m.Close()
 batch:=make([]string,32);for i:=range batch{batch[i]=fmt.Sprintf("fact %02d",i)}
 for _,s:=range []struct{name string;docs []string}{
  {"short_query",nil},
  {"long_query",nil},
  {"document",[]string{strings.Repeat("A project record describes source evidence, participants, dates, conditions and decisions. ",3)}},
  {"chinese_document",[]string{strings.Repeat("项目资料需要保留来源和适用条件。",6)}},
  {"batch_documents",[]string{"A project record describes source evidence and conditions.", "The person changed plans and recorded the reason and relevant dates.", "A separate source provides supporting observations for the same project."}},
  {"batch32",batch},
 }{
  event(s.name+"_start",map[string]any{});t:=time.Now();n:=0;hash:=sha256.New();var bits [4]byte
  writeVector:=func(v []float32){for _,f:=range v{binary.LittleEndian.PutUint32(bits[:],math.Float32bits(f));hash.Write(bits[:])}}
  if s.docs==nil { query:="Which source explains the project conditions?";if s.name=="long_query"{query=strings.Repeat("reason ",450)};v,e:=m.EmbedQuery(ctx,query);check(e);n=len(v);writeVector(v) } else { v,e:=m.EmbedDocuments(ctx,s.docs);check(e);n=len(v);for _,a:=range v{writeVector(a)} }
  var stats runtime.MemStats;runtime.ReadMemStats(&stats)
  event(s.name+"_end",map[string]any{"elapsed_ms":time.Since(t).Seconds()*1000,"count":n,"vector_sha256":fmt.Sprintf("%x",hash.Sum(nil)),"heap_alloc":stats.HeapAlloc,"heap_sys":stats.HeapSys,"sys":stats.Sys});time.Sleep(250*time.Millisecond)
 }
 runtime.KeepAlive(workspace)
 event("complete",map[string]any{});time.Sleep(500*time.Millisecond)
}

func verifyDatabase(ctx context.Context,cs []*sql.Conn){
 start:=time.Now();_,e:=cs[0].ExecContext(ctx,"CREATE TABLE IF NOT EXISTS proof(id INTEGER PRIMARY KEY,content TEXT)");check(e)
 _,e=cs[0].ExecContext(ctx,"DELETE FROM proof");check(e)
 _,e=cs[0].ExecContext(ctx,"BEGIN IMMEDIATE");check(e)
 raw:=strings.Repeat("长期资料需要保真：中文、引号\"、换行\n以及反斜线\\。",500)
 _,e=cs[0].ExecContext(ctx,"INSERT INTO proof VALUES(1,?)",raw);check(e)
 _,e=cs[0].ExecContext(ctx,"ROLLBACK");check(e)
 var count int;check(cs[1].QueryRowContext(ctx,"SELECT count(*) FROM proof").Scan(&count));if count!=0{panic("rollback lost")}
 _,e=cs[0].ExecContext(ctx,"INSERT INTO proof VALUES(1,?)",raw);check(e)
 _,e=cs[1].ExecContext(ctx,"BEGIN");check(e)
 var got string;check(cs[1].QueryRowContext(ctx,"SELECT content FROM proof WHERE id=1").Scan(&got));if got!=raw{panic("content changed")}
 _,e=cs[0].ExecContext(ctx,"UPDATE proof SET content=? WHERE id=1",raw+"updated");check(e)
 check(cs[1].QueryRowContext(ctx,"SELECT content FROM proof WHERE id=1").Scan(&got));if got!=raw{panic("snapshot changed")}
 _,e=cs[1].ExecContext(ctx,"COMMIT");check(e)
 check(cs[1].QueryRowContext(ctx,"SELECT content FROM proof WHERE id=1").Scan(&got));if got!=raw+"updated"{panic("commit missing")}
 for _,c:=range cs[1:] {rows,e:=c.QueryContext(ctx,"SELECT data FROM samples ORDER BY id");check(e);n:=0;for rows.Next(){var body []byte;check(rows.Scan(&body));if len(body)!=65536{panic("payload size changed")};for _,b:=range body{if b!=0{panic("payload changed")}};n++};check(rows.Err());check(rows.Close());if n!=40{panic("row count changed")}}
 var busy,log,done int;check(cs[0].QueryRowContext(ctx,"PRAGMA wal_checkpoint(TRUNCATE)").Scan(&busy,&log,&done));if busy!=0{panic("checkpoint busy")}
 check(cs[0].QueryRowContext(ctx,"PRAGMA integrity_check").Scan(&got));if got!="ok"{panic(got)}
 event("database_checks",map[string]any{"passed":true,"read_bytes":2*40*65536,"elapsed_ms":time.Since(start).Seconds()*1000})
}
